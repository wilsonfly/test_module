#include <stdio.h>
#include <hi_type.h>
#include <pthread.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <assert.h>
#include <linux/fb.h>
#include <sys/mman.h>
#include <sys/ioctl.h>
#include <unistd.h>
#include <pthread.h>
#include <sys/time.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <sys/time.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <errno.h>
#include <string.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <pthread.h>
#include <assert.h>
#include <linux/fb.h>
#include <sys/mman.h>
#include <sys/ioctl.h>
#include <fcntl.h>
#include <unistd.h>
#include <sys/sendfile.h>
#include <dirent.h>
#include <sys/wait.h>

#include "hi_unf_common.h"
#include "hi_unf_demux.h"
#include "hi_unf_ecs.h" 
#include "hi_adp_mpi.h"
#include "hi_adp_tuner.h"

//#ifdef bool
//#undef bool
//#define bool int
//#endif

#include <netinet/in.h>
#include <netinet/ip.h>
#include <sys/socket.h>
#include "config.h"
#include "stdafx.h"
#include "swmpefilter_priv.h"

#define PAT_TABLEID 0
#define TUNER_PORT  0
#define TS_PORT     0
#define READ_DATA_LEN 188*10

#define MAX_BUFFER_SIZE 30*1024*1024
#define MAX_CHANNEL_NUM 64 
#define MAX_PATH_LEN 128

#ifndef HANDLE
#define HANDLE HI_HANDLE
#endif

//频道信息
typedef struct channelinfo{
	//频道IP
	uint32_t ip;
	//频道端口
	uint16_t port;
	//频道名
	uint8_t channelname[128];
	//频道ID
	uint8_t channelid[128];
}channelinfo_t;

static channelinfo_t m_channels[MAX_CHANNEL_NUM] = 
{
};
static HANDLE m_tsfragment[MAX_CHANNEL_NUM];
//MPE Filter对象
typedef struct mpefilter{
	//数据回调处理函数指针
//=	data_output data_callback;
	//用户参数
	uint32_t wparam;
	//数据读取线程ID
	HI_HANDLE pthrdread;
	//数据处理线程ID
	HI_HANDLE pthrd;
	//section 过滤器
	HI_HANDLE psecfilter;
	//tuner 句柄
	HI_HANDLE ptuner;
	//网络信息
	struct{
		uint32_t ip;
		uint16_t port;
		bool started;
	}netinfo[MAX_CHANNEL_NUM];
	//缓冲区
	uint8_t* databuf;
	//数据缓冲队列
	dataqueue_t* datastream;
	//数据输入类型
	union{
		//网络
		int skt;
		//DVB
		HI_HANDLE filter;
		//文件
		FILE* fp;
	}fddata;
	//节目数统计
	int program_count;
	bool isexit;             
}mpefilter_t;


HI_U32 g_TunerFreq;
HI_U32 g_TunerSrate;
HI_U32 g_TunerQam;
HI_HANDLE m_hmpe;
HI_HANDLE hChannel = NULL;
static char config_file[] = "config.txt";
static int m_channel_count = 0;
static HI_U8 g_match[DMX_FILTER_MAX_DEPTH];
static HI_U8 g_mask[DMX_FILTER_MAX_DEPTH];
static HI_U8 g_Negate[DMX_FILTER_MAX_DEPTH];
static int mpesection_proc( uint8_t* buf, int size, uint32_t wparam );
static inline int get_netidx( uint32_t ip, uint32_t port, mpefilter_t* mf);
HI_HANDLE sw_mpefilter_open( char* url );
static int create_path( char* fullpath );
static int sw_recutil_createpath( char *path );
static bool mpefiler_data_proc( uint32_t wparam, uint32_t lparam );
static int data_callback_proc( int idx, unsigned char *buf, unsigned int size, unsigned long lParam );
static bool read_file_proc( uint32_t wparam, uint32_t lparam );
HI_HANDLE tuner_init( uint32_t freq,uint32_t rate,uint32_t qam );
static int load_config( void );
int sw_mpefilter_set_infobyidx( HANDLE hmpe ,int idx,unsigned long ip, unsigned short port );

//HI_S32 SectionRecvFunc(HI_HANDLE Chandle)
static bool dvb_recv_proc( uint32_t wparam, uint32_t lparam )
{
	 HI_U32 ret;
	 HI_U32 i,j,k;
	 HI_U32 u32AcquireNum = 100;
	 HI_U32 pu32AcquiredNum;
	 HI_UNF_DMX_DATA_S pstBuf[100];

	 FILE* fp = NULL;
	 int n = 0;
	 int count = 0;

	 HI_HANDLE Chandle = (HI_HANDLE)lparam;
//	 fp = fopen("/tmp/tsfile.ts","wb");
	 printf("receive start!\n");
	 while(1)
	 {
		 count++;
		 if(HI_SUCCESS != (ret=HI_UNF_DMX_AcquireBuf(Chandle,u32AcquireNum,&pu32AcquiredNum,pstBuf,5000)))
		 {
			 printf("call HI_UNF_DMX_AcquireBuf failed!ret:%d\n",ret);
			 usleep(10 * 1000);
			 continue;
		 }
	//	printf("pu32QcquiredNum:%d\n",pu32AcquiredNum);
		 if( pu32AcquiredNum == 0 )
		 {
			 printf("@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@\n");
			 usleep(10*1000);
			 continue;
		 }
	//	 printf("size:%d\n",pu32AcquiredNum);
	//	 printf("size:%d\n",pstBuf[0].u32Size);
	//	 n = fwrite(pstBuf[0].pu8Data,1,pstBuf[0].u32Size,fp);
	//	 printf("write:%d\n",n);

#if 1
		for(i=0;i<pu32AcquiredNum;i++)
		{
			mpesection_proc(pstBuf[i].pu8Data,pstBuf[i].u32Size,m_hmpe);
#if 0
			n = fwrite(pstBuf[i].pu8Data,1,pstBuf[i].u32Size,fp);
			if(count % 10 == 0)
				printf("i:%d,write:%d\n",i,n);
#endif
#if 0
			for(j=0;j<pstBuf[i].u32Size;j++)
			{
				printf("%02x ",pstBuf[i].pu8Data[j]);
			}
			printf("\n");
#endif
		}
#endif
		ret = HI_UNF_DMX_ReleaseBuf(Chandle,pu32AcquiredNum,pstBuf);

		if( pu32AcquiredNum < 20 )
		{
		//	printf("in, pu32QcquiredNum:%d\n",pu32AcquiredNum);
			usleep(10000);
		}
		else
		{
		//	printf("out,pu32QcquiredNum:%d\n",pu32AcquiredNum);
		}

		if (HI_SUCCESS != ret)
        {
            printf("call HI_UNF_DMX_ReleaseBuf failed!\n");
        }
	 }
     printf("receive over!\n");
	 return HI_SUCCESS;
}

#define SUPPORT_DVB
HI_S32 main(HI_S32 argc,HI_CHAR *argv[])
{
	HI_S32 ret;
	/* start to recv section data, and meanwhile print received section */
	//	SectionRecvFunc(hChannel);
	char url[256] = "dvb://freq=123&&srate=6875&&qam=64&&mpeid=7238";
//	char url[256] = "file:///home/king/7238.ts&&mpepid=7238";
//	char url[256] = "file:///mnt/7238.ts&&mpepid=7238";


	m_hmpe = sw_mpefilter_open(url);
	load_config();
	
	while( getchar() != 'q' )
		;
	ret = HI_UNF_DMX_CloseChannel(hChannel);
	if (HI_SUCCESS != ret)
	{
		printf("call HI_UNF_DMX_CloseChannel failed!\n");
	}	

}

//#define true 0
static FILE *m_dumpfile = NULL;
static unsigned short m_dumpport = 0;
static unsigned int m_ip = 0;
static int mpesection_proc( uint8_t* buf, int size, uint32_t wparam )
{
//	printf("======in filter_callback_proc,size:%d,\n",size);
	int i = 0,j = 0;//,n = 0;
	struct iphdr  *ipheader;
//	struct udphdr *udpheader;
	uint8_t LLC_SNAP_flag;
	unsigned long int src_ip;
	unsigned long int dst_ip;
	char src_s[16];
	char dst_s[16];
	uint16_t src_port;
	uint16_t dst_port;
	int ret = 0;
	int idx = 0;

	mpefilter_t* mf = (mpefilter_t*)wparam;
//	info_t* mf = (info_t*)wparam; //change back to user
//	hFilter = hFilter; //index actually
	i = 5;//LLC_SNAP_flag
	LLC_SNAP_flag = buf[i] & 0x02;
	LLC_SNAP_flag = LLC_SNAP_flag >> 1;
	if(LLC_SNAP_flag != 0)
		return true;

	i = 12;//ip,20 bytes
	//	printf("%02X,%02X\n",buf[i],buf[i+1]);
	ipheader =(struct iphdr *)&buf[i];
	//	printf("src_ip:%x,dst_ip:%x\n",ipheader->saddr,ipheader->daddr);
	src_ip = ipheader->saddr;
	dst_ip = ipheader->daddr;
	inet_ntop(AF_INET,&src_ip,src_s,sizeof(src_s));
	inet_ntop(AF_INET,&dst_ip,dst_s,sizeof(dst_s));
//	printf("src_s:%s,dst_s:%s,protocol:%d\n",src_s,dst_s,ipheader->protocol);

	i = 32;//src port,2 bytes
	//	printf("%02X,%02X\n",buf[i],buf[i+1]);
	src_port = buf[i];
	src_port = (src_port << 8) + buf[i+1];

	i = 34;//dst port,2 bytes,followed by other 4 bytes
	dst_port = buf[i];
	dst_port = (dst_port << 8) + buf[i+1];
//	printf("dst_port:%d\n",dst_port);

	i = 40;//sync bytes

#if 0
	if( m_dumpport == 0 )
	{
		m_dumpport =5111;// dst_port;//5080;//dst_port;
		m_ip = dst_ip;
		m_dumpfile = fopen("/tmp/test.ts","wb");
		printf("======open /tmp/test.ts\n");
	}
	if( m_dumpport >0 && m_dumpport == dst_port/* && m_ip == dst_ip*/ )
	{
		printf("===================get the same ip/port\n");
		int i  = 0, n = 0;
		uint8_t* data = buf+40;
		for( ;i<size-44; i++ )
	    {
	        if( *(data+i) == 0x47 )
	        {
	            for( n=i; n<size-44; n += 188 )
	            {
	                if( *(data+n) != 0x47 )
	                {
	                    //printf("write 0x%x,0x%x,0x%x,0x%x .n = %d\n",data[n],data[n+1],data[n+2],data[n+3],n);
	                    break;
	                }
	            }
	            break;
	        }
	    }
		//if( buf[40] != 0x47 )
		//	printf("@@@@write 0x%x,0x%x,0x%x,0x%x\n",buf[40],buf[41],buf[42],buf[43]);
		ret = fwrite(buf+40,1,size-44,m_dumpfile);
//		printf("[%s]write %d,%d,size %d,ret:%d\n",__FUNCTION__,size-44,htons(m_dumpport),size,ret );
	}
	return 0;
#endif


	idx = get_netidx( dst_ip,dst_port,mf);
//	printf("get_netidx:%d\n",idx);
	if( idx>=0 && mf->datastream && mf->netinfo[idx].started )
	{
		unsigned char *databuf = NULL;
		unsigned int datasize = 0 ;
		buf += 40;
		size -= 40;
		while( size > 4 )
		{
			datasize = size-4;
			dataqueue_get_writebuf(mf->datastream,0,&databuf,&datasize);
			if( datasize>size-4 )
				datasize = size-4;
			if( databuf )
			{
				//不做分析处理，原封不动将私有数据部分放进dataqueue
				memcpy(databuf,(char*)buf,datasize);
				size -= datasize;
			}
			else
			{
				printf("########################queue maybe full\n");
			//=	usleep(200000);   //////////////////////no
				continue;
			}
			dataqueue_write_complete(mf->datastream,idx,0,databuf,datasize,0);	
		}
	}

	return 0;
}
static inline int get_netidx( uint32_t ip, uint32_t port, mpefilter_t* mf)
{
	int i = 0;
	for( ;i<MAX_CHANNEL_NUM;i++)
	{
		if( port == mf->netinfo[i].port && ip == mf->netinfo[i].ip )
		{
			return i;
		}
	}
	return -1;
}
HI_HANDLE sw_mpefilter_open( char* url )
{
	printf("====[%s] begin\n",__FUNCTION__);
	int i = 0,ret = 0;
	char* p = NULL;
	uint16_t pid = 7238;
	uint8_t match[16] = {0x3e},mask[16] = {0xff},mask_len = 1;

	mpefilter_t* mf = NULL;
	mf = malloc(sizeof(mpefilter_t));
	if( mf == NULL )
		return NULL;
	p = strstr( url,"&&mpepid=");
	if( p )
	{
		pid = atoi( p+strlen("&&mpepid="));
		*p = '\0';
	}
	memset( mf, 0, sizeof(mpefilter_t));
	mf->isexit = false;
	mf->databuf = malloc(MAX_BUFFER_SIZE);
	if( mf->databuf )
	{
		memset( mf->databuf,0,MAX_BUFFER_SIZE );
		mf->datastream = dataqueue_create(mf->databuf,MAX_BUFFER_SIZE);
		dataqueue_set_block( mf->datastream,false ); 
	}
#if 0
	mf->psecfilter = mpesection_create( pid,mpesection_proc,(unsigned long)mf);
	if( mf->psecfilter == NULL )
		goto failopen;
//	mpesection_set_filter( mf->psecfilter,match,mask,mask_len);
#endif
	//根据相应的url,启动数据接收
	if( strstr( url,"dvb://" ))
	{
#ifdef SUPPORT_DVB
		char* p;
		uint32_t freq,srate,qam;

		p = strstr( url,"&&freq=");
		if( p )
			freq = atoi( p+strlen("&&freq="));
		p = strstr( url,"&&srate=");
		if( p )
			srate = atoi( p+strlen("&&srate="));
		p = strstr( url,"&&qam=");
		if( p )
			qam = atoi( p+strlen("&&qam="));

		freq = 123;
		printf("freq:%d,srate:%d,qam:%d\n",freq,srate,qam);
		hChannel = tuner_init( freq,srate,qam );
		if( hChannel == NULL )
		{
			printf("====tuner_init failed\n");
			return -1;
		}
		mf->pthrdread = sw_thrd_open( "dvb_recv_proc", 60, 0, 64*1024, dvb_recv_proc, (unsigned long)mf, (unsigned long)hChannel );
		sw_thrd_resume( mf->pthrdread );
#if 0
//base on main_pvr
		ptuner = sw_tuner_init( 0, TNR_TYPE_DVBC_HI3130);
		if( ptuner == NULL )
		{
			printf("====[%s]open dvb tuner<%d> failed.\n",__FUNCTION__, 0);
			return -1;
		}
		else
		{
			sw_tuner_set_callback( ptuner, sw_dvb_porting_tuner_status_callback, 0 );
		}

		sw_tuner_set_channel( ptuner, freq, rate, qam );

		mf->pthrdread = sw_thrd_open( "dvb_recv_proc", 60, 0, 64*1024, dvb_recv_proc, (unsigned long)mf, 0 );
		sw_thrd_resume( mf->pthrdread );
#endif
#endif
		
	}
	else if( strstr( url,"udp://" ))
	{
		
	}
	else if( strstr( url,"file://" ))
	{
#if 0
		mf->fddata.fp = fopen(url+strlen("file://"),"rb");
		if( mf->fddata.fp == NULL )
		{
			printf("[sw_mpefilter_open] open file %s failed\n",url+strlen("file://"));
			goto failopen;
		}
		mf->pthrdread = sw_thrd_open( "read_file_proc", 60, 0, 64*1024, read_file_proc, (unsigned long)mf, 0 );
		sw_thrd_resume( mf->pthrdread );
#endif
	}
	else
		printf("====[%s]invalid url\n",__FUNCTION__);

	//启动数据处理线程
	mf->pthrd = sw_thrd_open( "data_proc", 60, 0, 64*1024, mpefiler_data_proc, (unsigned long)mf, 0 );
	sw_thrd_resume( mf->pthrd );

	printf("====[%s] ok\n",__FUNCTION__);
	return mf;

failopen:
	if( mf->datastream ) dataqueue_destory(mf->datastream);
	if( mf->databuf ) free(mf->databuf);
//	if( mf->psecfilter ) mpesection_destroy(mf->psecfilter);
	free( mf );
	return NULL;
}

//启动数据处理线程
static bool mpefiler_data_proc( uint32_t wparam, uint32_t lparam )
{
//	printf("====[%s] begin\n",__FUNCTION__);
	mpefilter_t* mf = (mpefilter_t*)wparam;
	uint8_t *buf = NULL;
	uint32_t size = 0;
	if( mf->isexit )
		return false;
	dataqueue_get_readbuf(mf->datastream, &buf, &size);
	if( size <= 0 )
	{
		sw_thrd_delay(40);
		return true;
	}
//	mf->data_callback( dq_media_id(buf),buf+dq_payload_offset(buf),dq_payload_size(buf),mf->wparam );
	data_callback_proc( dq_media_id(buf),buf+dq_payload_offset(buf),dq_payload_size(buf),mf->wparam );
	dataqueue_read_complete( mf->datastream, buf );
	return true;
}

static int data_callback_proc( int idx, unsigned char *buf, unsigned int size, unsigned long lParam )
{
//	printf("=====[%s] begin,idx:%d\n",__FUNCTION__,idx);
	char path[128];
	char outputpath[256];
	if( size % 188 )
	{
		printf("idx:%d,not ts\n",idx);
//		return 0;
	}
	if( idx >= MAX_CHANNEL_NUM )
	{
		return 0;
	}
	if( m_tsfragment[idx] == NULL )
	{
#if 0
		sprintf( path,"/tmp/server-root/live/%s",m_channels[idx].channelname );
		create_path( path );
		sprintf( outputpath,"%s/%s",path,m_channels[idx].channelid );
#else
		sprintf( path,"/tmp/server-root/EPG/live/%s",m_channels[idx].channelid );
		create_path( path );
		sprintf( outputpath,"%s/%s",path,m_channels[idx].channelname );
#endif
		m_tsfragment[idx] = sw_tsfragment_open( outputpath, outputpath, 5, 5 ,true );
	}
	if( m_tsfragment[idx] )
		sw_tsfragment_ondata( m_tsfragment[idx],buf,size );
}


static int create_path( char* fullpath )
{
	char path[64];
	char* p = NULL;
	char* tmp = NULL;
	strncpy(path,fullpath,sizeof(path));
//	p = strrchr(path,'/');
//	*(p) = '\0';//remove the filename,get directory 

#if 0
	if( access(path, F_OK) )
	{
		if( sw_recutil_createpath(path) != 0 )
		{
			printf("===========createpath failed\n");
			return -1;
		}
		printf("create path:%s\n",path);
	}
#else
	//////////////////////////////mkdir -p
	if( access(path, F_OK) == 0 )
		return 0;
	if( path[0] == '/' )
		p = path + 1; //pass the root dir '/'
	else
		p = path;
	while( p < path+strlen(path) )
	{
		if (tmp = strchr(p,'/'))
			*(tmp) = '\0'; //有则置零截断
		if( access(path, F_OK) )
		{
			if( sw_recutil_createpath(path) != 0 )
			{
				printf("===========createpath failed\n");
				return -1;
			}
			printf("create path:%s\n",path);
		}
		if( tmp == NULL)
			return 0;
		p = tmp + 1;
		strncpy(path,fullpath,sizeof(path));
	}
#endif
	//////////////////////////////
	return 0;
}

/** 
 * @brief 创建指定目录
 * @param path 
 * @return 
 */
static int sw_recutil_createpath( char *path )
{
	DIR *dir = NULL;
	char buf[MAX_PATH_LEN];
	int ret = -1;

	if( !path )
	{
		printf( "[%s]Path is null\n", __FUNCTION__ );
		return -1;
	}

	memset(buf, 0, sizeof(buf));
	strncpy(buf, path, sizeof(buf)-1);
	if( '/'!=*(char*)(path+strlen(path)-1) )
		strcat(buf, "/");

	dir = opendir( buf );
	if( !dir )
	{
		ret = mkdir( buf, S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
		printf( "[%s]mkdir %s ret = %d\n", __FUNCTION__, buf, ret );
	}
	/*closedir( dir );*/
	return ret;
}

HI_HANDLE tuner_init( uint32_t freq,uint32_t rate,uint32_t qam )
{
	printf("====[%s] begin\n",__FUNCTION__);
	HI_S32 ret;
	HI_UNF_DMX_CHAN_ATTR_S stChnAttr;
	HI_UNF_DMX_FILTER_ATTR_S stFilterAttr;
	HI_HANDLE hChannel;
	HI_HANDLE hFilter1;

	g_TunerFreq = freq;
	g_TunerSrate = rate;
	g_TunerQam = qam;

	HI_SYS_Init();
	HI_SYS_PreAV(NULL);
	ret = HIADP_Tuner_Init();
    if (HI_SUCCESS != ret)
    {
        printf("call HIADP_Demux_Init failed.\n");
        goto TUNER_DEINIT;
    }

    ret = HIADP_Tuner_Connect(TUNER_USE,g_TunerFreq,g_TunerSrate,g_TunerQam);
    if (HI_SUCCESS != ret)
    {
        printf("call HIADP_Tuner_Connect failed.\n");
        goto TUNER_DEINIT;
    }
    
	ret |= HI_UNF_DMX_Init();
    ret |= HI_UNF_DMX_AttachTSPort(0,TS_PORT);
	if (HI_SUCCESS != ret)
	{
		printf("call HIADP_Demux_Init failed!\n");
		goto TUNER_DEINIT;
	}
	
	ret = HI_UNF_DMX_GetChannelDefaultAttr(&stChnAttr);
	if (HI_SUCCESS != ret)
	{
		printf("call HI_UNF_DMX_GetChannelDefaultAttr failed!\n");
		goto DMX_DEINIT;
	}
	stChnAttr.enChannelType = HI_UNF_DMX_CHAN_TYPE_SEC;
//	stChnAttr.enChannelType = HI_UNF_DMX_CHAN_TYPE_POST;
	stChnAttr.enCRCMode = HI_UNF_DMX_CHAN_CRC_MODE_FORBID;
//	stChnAttr.u32BufSize = 16 * 1024;
	stChnAttr.u32BufSize = 3*1024*1024;
	ret = HI_UNF_DMX_CreateChannel(0,&stChnAttr,&hChannel);
	if (HI_SUCCESS != ret)
	{
		printf("call HI_UNF_DMX_CreateChannel failed!\n");
		goto DMX_DEINIT;
	}

#if 1
    /* set filter attr */
    memset(&g_mask,0,DMX_FILTER_MAX_DEPTH);
    memset(&g_match,0,DMX_FILTER_MAX_DEPTH);
    memset(&g_Negate,0,DMX_FILTER_MAX_DEPTH);
    stFilterAttr.u32FilterDepth = 1;
    g_match[0] = 0x3e;//0x47;//0x3e;//PAT_TABLEID;
	memcpy(stFilterAttr.au8Mask,g_mask,DMX_FILTER_MAX_DEPTH);
	memcpy(stFilterAttr.au8Match,g_match,DMX_FILTER_MAX_DEPTH);
	memcpy(stFilterAttr.au8Negate,g_Negate,DMX_FILTER_MAX_DEPTH);
	ret = HI_UNF_DMX_CreateFilter(0,&stFilterAttr,&hFilter1);
	if (HI_SUCCESS != ret)
	{
		printf("call HI_UNF_DMX_CreateFilter failed!\n");
		goto CHN_DESTROY;
	}
	ret = HI_UNF_DMX_AttachFilter(hFilter1,hChannel);
	if (HI_SUCCESS != ret)
	{
		printf("call HI_UNF_DMX_AttachFilter failed!\n");
        HI_UNF_DMX_DestroyFilter(hFilter1);
		goto CHN_DESTROY;
	}
#endif
	ret = HI_UNF_DMX_SetChannelPID(hChannel,7238/*PAT_TSPID*/);
	ret |= HI_UNF_DMX_OpenChannel(hChannel);
	if (HI_SUCCESS != ret)
	{
		printf("call HI_UNF_DMX_OpenChannel failed!\n");
		goto FILTER1_DESTROY;
	}
	printf("====[%s] ok \n",__FUNCTION__);
	return hChannel;

FILTER1_DESTROY:
	HI_UNF_DMX_DetachFilter(hFilter1,hChannel);
	HI_UNF_DMX_DestroyFilter(hFilter1);
CHN_DESTROY:
	HI_UNF_DMX_DestroyChannel(hChannel);
DMX_DEINIT:	
    HI_UNF_DMX_DetachTSPort(0);
    HI_UNF_DMX_DeInit();
TUNER_DEINIT:	
	HIADP_Tuner_DeInit();
	HI_SYS_DeInit();
	return NULL;
}
//读取文件线程处理函数
static bool read_file_proc( uint32_t wparam, uint32_t lparam )
{
#if 1
	mpefilter_t* mf = (mpefilter_t*)wparam;
	uint8_t tsdata[1316];
	int len = 0;

//	if( mf->isexit )
//		return false;
	while( !feof(mf->fddata.fp) )
	{
		if( mf->isexit )
			return false;
		len = fread( tsdata,1,sizeof(tsdata),mf->fddata.fp );
		if( len <=0 )
			break;
		mpesection_ontsdata( mf->psecfilter,tsdata,len);
	}
	fseek(mf->fddata.fp,0L,SEEK_SET);
	return true;
#endif
}
static int load_config( void )
{
	printf("====[%s] begin\n",__FUNCTION__);
	FILE* fp = NULL;
	char buf[1024*2];
	char* p = NULL;
	char ip_tmp[32];
	int port_tmp;
	int i = 0;
	int n = 0;

	fp = fopen(config_file,"rt+");
	if( fp == NULL )
	{
		printf("open config file failed\n");
		return -1;
	}
	while( !feof(fp) )
	{
		if( fgets(buf,256,fp) == NULL)
			break;
		p = buf;
		p = strstr(buf,"ip=");
		if( p == NULL || buf[0] == '#' )
		{
			printf("====pass one line\n");
			continue;
		}
		sscanf(p+strlen("ip="),"%[1-9.]",ip_tmp);
		m_channels[i].ip = inet_addr(ip_tmp);	

		p = strstr(buf,"port=");
		sscanf(p+strlen("port="),"%d",&port_tmp);
		m_channels[i].port = port_tmp;

		p = strstr(buf,"chname=");
		sscanf(p+strlen("chname="),"%[^,]",m_channels[i].channelname);
	//	printf("chname:%s\n",m_channels[i].channelname);

		p = strstr(buf,"chid=");
//		sscanf(p+strlen("chid="),"%[0-9a-zA-Z]",m_channels[i].channelid);//for '-'
		sscanf(p+strlen("chid="),"%s",m_channels[i].channelid);
#if 0
		for( n=0;n<32;n++ )
			printf("%c",m_channels[i].channelid[n]);
		printf("\n");
#endif
		sw_mpefilter_set_infobyidx( m_hmpe,i,m_channels[i].ip,m_channels[i].port );

		i++;
	}
	m_channel_count = i;
	fclose(fp);

	printf("====[%s] ok\n",__FUNCTION__);
	return 0;
}
int sw_mpefilter_set_infobyidx( HANDLE hmpe ,int idx,unsigned long ip, unsigned short port )
{
	mpefilter_t* mf = (mpefilter_t*)hmpe;
	if( idx>= MAX_CHANNEL_NUM )
		return -1;
	mf->netinfo[idx].port = port;
	mf->netinfo[idx].ip = ip;
	mf->netinfo[idx].started = true;
	printf("new channel add,idx:%d %d.%d.%d.%d:%d\n",
			idx,ip&0xff,(ip>>8)&0xff,(ip>>16)&0xff,(ip>>24)&0xff,port);
	return 0;
}


