#ifndef __SWLOG_H__
#define __SWLOG_H__
#define sw_log_debug printf
#define sw_log_info printf
#define sw_log_warn printf
#define sw_log_error printf
#endif
