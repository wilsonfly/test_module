#include <stdbool.h>
#ifndef BCMINDEXERPRIV_H
#define BCMINDEXERPRIV_H

/*******************************
*
* BNAV_Entry
*
******/

/* defines and typedefs used internally by both bcmplayer and bcmindexer */

#define BNAV_set_frameType( pEntry, frameType ) \
		((pEntry)->words[0] &= 0x00fffffful, \
		(pEntry)->words[0] |= ((unsigned long)(frameType) << 24))
#define BNAV_get_frameType( pEntry ) \
	((eSCType)((pEntry)->words[0] >> 24))
#define BNAV_set_seqHdrStartOffset( pEntry, seqHdrStartOffset ) \
		((pEntry)->words[0] &= 0xff000000ul, \
		(pEntry)->words[0] |= ((seqHdrStartOffset) & 0x00fffffful))
#define BNAV_get_seqHdrStartOffset( pEntry ) \
	((unsigned long)((pEntry)->words[0] & 0xffffff))

#define BNAV_set_seqHdrSize( pEntry, seqHdrSize ) \
		((pEntry)->words[1] &= 0x0000fffful, \
		(pEntry)->words[1] |= ((unsigned long)(seqHdrSize) << 16))
#define BNAV_get_seqHdrSize( pEntry ) \
	((unsigned short)(((pEntry)->words[1] >> 16) & 0xffff))
#define BNAV_set_refFrameOffset( pEntry, refFrameOffset ) \
		((pEntry)->words[1] &= 0xffff00fful, \
		(pEntry)->words[1] |= ((unsigned long)(refFrameOffset) << 8))
#define BNAV_get_refFrameOffset( pEntry ) \
		((unsigned char)(((pEntry)->words[1] >> 8) & 0xff))

#define BNAV_set_version( pEntry, version ) \
		((pEntry)->words[1] &= 0xffffff0ful, \
		(pEntry)->words[1] |= (unsigned long)(((version) & 0xf) << 4))
#define BNAV_get_version( pEntry ) \
		((unsigned char)((pEntry)->words[1] & 0xf0)>>4)

/* NOTE: Lower 4 bits of [1] available */

#define BNAV_set_frameOffsetHi( pEntry, frameOffsetHi ) \
		((pEntry)->words[2] = (frameOffsetHi))
#define BNAV_get_frameOffsetHi( pEntry ) \
		((pEntry)->words[2])
#define BNAV_set_frameOffsetLo( pEntry, frameOffsetLo ) \
		((pEntry)->words[3] = (frameOffsetLo))
#define BNAV_get_frameOffsetLo( pEntry ) \
	((pEntry)->words[3])
#define BNAV_set_framePts( pEntry, framePts ) \
	((pEntry)->words[4] = (framePts))
#define BNAV_get_framePts( pEntry ) \
	((pEntry)->words[4])
/**
* Maximum frameSize is 256 MB (28 bits). This should
* be large enough for the largest HD I-frame possible.
**/
#define BNAV_set_frameSize( pEntry, frameSize ) \
	((pEntry)->words[5] &= 0xf0000000ul, \
	(pEntry)->words[5] |= ((unsigned long)(frameSize) & 0x0ffffffful))
#define BNAV_get_frameSize( pEntry ) \
	((pEntry)->words[5] & 0x0ffffffful)

/* NOTE: Upper 4 bits of [5] available */

#define BNAV_set_timestamp( pEntry, timestamp) \
	((pEntry)->words[6] = (timestamp))
#define BNAV_get_timestamp( pEntry ) \
	((pEntry)->words[6])

/**
* 12 bits for packed vchip information. See BNAV_pack_vchip and
* BNAV_unpack_vchip.
**/
#define BNAV_set_packed_vchip( pEntry, vchipdata) \
	((pEntry)->words[7] &= 0xfffff000ul, \
	(pEntry)->words[7] |= (unsigned long)((vchipdata) & 0xfff))
#define BNAV_get_packed_vchip( pEntry ) \
	((unsigned short)((pEntry)->words[7] & 0xfff))

/* NOTE: Upper 20 bits of [7] available */


/*******************************
*
* BNAV_AVC_Entry
*
******/
/* SPS is sequence parameter set. 24 bits allows 16 MB offset in stream. */
#define BNAV_set_SPS_Offset( pEntry, seqHdrStartOffset ) \
		((pEntry)->words[8] &= 0xff000000ul, \
		(pEntry)->words[8] |= ((seqHdrStartOffset) & 0x00fffffful))
#define BNAV_get_SPS_Offset( pEntry ) \
	((unsigned long)((pEntry)->words[8] & 0xffffff))

/* 16 bits allows 64 KB for SPS, which is far more than enough. */
#define BNAV_set_SPS_Size( pEntry, seqHdrStartOffset ) \
		((pEntry)->words[9] &= 0xffff0000ul, \
		(pEntry)->words[9] |= ((seqHdrStartOffset) & 0x0000fffful))
#define BNAV_get_SPS_Size( pEntry ) \
	((unsigned long)((pEntry)->words[9] & 0xffff))

#define BNAV_set_RandomAccessIndicator( pEntry, randomAccessIndicator) \
                (((BNAV_AVC_Entry*)pEntry)->words[10] &= 0xfffffffeul, \
                 ((BNAV_AVC_Entry*)pEntry)->words[10] |= ((randomAccessIndicator) & 0x00000001ul))
#define BNAV_get_RandomAccessIndicator( pEntry ) \
        ((unsigned long)(((BNAV_AVC_Entry*)pEntry)->words[10] & 0x1))


/* Convert eSCType to a string */
extern const char *BNAV_frameTypeStr[];

typedef enum
{
	eSCTypeSeqHdr,			/* Sequence header */
	eSCTypeIFrame,			/* I-frame */
	eSCTypePFrame,			/* P-frame */
	eSCTypeBFrame,			/* B-frame */
	eSCTypeGOPHdr,			/* GOP header */
	eSCTypeRPFrame, 		/* Reference picture frame */
	eSCTypeUnknown			/* Unknown or "don't care" frame type */
} eSCType;

/**
* Convert 12 bit vchip data to 16 bit vchip data.
**/
unsigned short BNAV_unpack_vchip(unsigned short packed_vchip);

/**
* Convert 16 bit vchip data to 12 bit vchip data, checking the 16 bit
* data for bits 6 and 14. If bits 6 and 14 are both 1, the vchip data
* is valid and BNAV_pack_vchip returns 0 and the packed value is
* written to *packed_vchip. Otherwise it returns -1 and *packed_vchip is left unchanged.
*/
int BNAV_pack_vchip(unsigned short unpacked_vchip, unsigned short *packed_vchip);

struct BNAV_Indexer_HandleImpl
{
	BNAV_Indexer_Settings settings;

	unsigned long	TransRecordByteCount;	/* Running counter of number of bytes
											   recorded */
	unsigned long	TransRecordByteCountHi; /* Running counter of number of bytes recorded (hi word) */

	unsigned long	TransByteOffset;		/* Running count of number of bytes
											   processed in cur packet */

	char			seqHdrFlag; 			/* Flag indicating if MPEG2 sequence header information was found.	*/
	char			isISlice;				/* Flag indicating that we found an
											   I-slice or I-frame */
	char			isHits; 				/* Flag indicating we're dealing with a
											   HITS-stream */
	char			hitFirstISlice; 		/* Flag indicating that we've hit the
											   first I-slice */
	unsigned long	seqHdrSize; 			/* Number of bytes in the sequence
											   header */
	unsigned long	seqHdrStartOffset;		/* Sequence header offset (in bytes) relative to frame offset */
	unsigned long	picStart;				/* Offset of start of picture */
	unsigned long	picEnd; 				/* Offset of end of picture */
	unsigned char	rfo;					/* Reference frame offset counter */

	BNAV_Entry		curEntry;				/* The current MPEG2 structure that is being populated */
	BNAV_AVC_Entry	avcEntry;				/* The current AVC structure that is being populated. */

	unsigned long	next_pts;				/* pts buffer for next picture frame */
    bool random_access_indicator;
	long			starttime;				/* base timestamp for calculating NAV timestamp */
	long			lasttime;				/* last timestamp written to NAV entry */
	int 			prev_I_rfo; 			/* This contains the rfo for the previous
												I frame, until the next P frame is detected.
												This value is added to the rfo of the open gop
												B frames. */
	unsigned short	vchip;					/* Current packed vchip state */

	struct {
#define MAX_GOP_SIZE 50
		BNAV_Entry		entry[MAX_GOP_SIZE];
		int total_entries;
	} reverse;

	/* this information is used to report BNAV_Indexer_GetPosition consistently */
	int 			totalEntriesWritten;
	BNAV_Entry		lastEntryWritten;
	int allowOpenGopBs;

	/* define structures for AVC indexing */
#define TOTAL_PPS_ID 256
#define TOTAL_SPS_ID 32
	struct {
		int current_sps, current_pps; /* if -1, then no SPS or PPS being captured */
		int is_reference_picture; /* if true, then this picture has at least one slice that is referenced by another slice.
			this picture is not dropppable. */
		struct {
			unsigned long offset;
			unsigned long size;
			int sps_id;
		} pps[TOTAL_PPS_ID];
		struct {
			unsigned long offset;
			unsigned long size;
		} sps[TOTAL_SPS_ID];
		unsigned long current_sei;
		bool current_sei_valid;
	} avc;

	/* instead of complicated wraparound logic, I buffer a minimum amount before
	processing PES payload. MIN_PES_PAYLOAD includes the startcode byte itself. */
	#define MIN_PES_PAYLOAD 5
	struct {
		unsigned char buf[MIN_PES_PAYLOAD + 2];
		int bufsize;
		int sccount;
		uint64_t offset;

		bool vc1_interlace;
		uint64_t sequence_offset;
		int sequence_size;
		uint64_t entrypoint_offset;
		int entrypoint_size;
	} pes;
	/*liuwenyao增加*/
	unsigned long	last_pts;				/* pts buffer for last picture frame */
};

int BNAV_P_FeedPES_VC1(BNAV_Indexer_Handle handle, uint8_t *p_bfr, unsigned size);

int BNAV_Indexer_completeFrameAux(BNAV_Indexer_Handle handle,
	void *data, /* data points to either a BNAV_Entry or a BNAV_AVC_Entry. */
	int size  /* size of data */
	);

#endif
