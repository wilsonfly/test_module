
#ifndef __SW_HTTPFILTER_H__
#define __SW_HTTPFILTER_H__

#ifdef __cplusplus
extern "C" {
#endif

int sw_httpstream_init( unsigned long ip,  unsigned short port );
HANDLE sw_httpstream_open( char* channelname );

#ifdef __cplusplus
}
#endif

#endif //__SW_HTTPFILTER_H__
