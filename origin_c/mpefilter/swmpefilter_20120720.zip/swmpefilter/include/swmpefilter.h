/** 
 * @file  swmpefilter.h
 * @brief DVB MPE[Multiprotocol encapsulation多协议封装] 数据过滤模块
 * @author Hujinshui/Sunhuasheng
 * @date 2011-10-28
 * @version 1.0.0.0
 */

#ifndef __SW_MPEFILTER_H__
#define __SW_MPEFILTER_H__
#include "hi_type.h"
#include "hi_unf_demux.h"
#include "swmpefilter_priv.h"

#ifdef __cplusplus
extern "C" {
#endif

	/**
	 * @brief	数据回调处理函数  
	 * @param 	idx 数据的索引号,可以通过get_info_fromidx来确定
	 * 该数据的来源[ip/port]
	 * @param   data 输出数据
	 * @param   size 数据大小
	 * @param   wparam 用户数据参数
	 * @return  0成功,否则错误码
	 */
	typedef int (*data_output)( int idx, unsigned char* data, unsigned int size, unsigned long wparam );

	/**
	 * @brief	模块初始化  
	 * @return  0成功,否则错误码
	 */
	int sw_mpefilter_init( );

	/** 
	 * @brief	模块退出 
	 * @return  无
	 */
	void sw_mpefilter_exit();

	/** 
	 * @brief 根据url信息,打开一过滤器
	 * @url信息如下
	 *    @dvb://tunerid=xxx&&freq=xxx&symbol=xxx&&qam=xxx&&mpepid=xxx
	 *	  @file:///xx/xx/filename&&mpepid=xxx
	 *	  @udp://ip:port&&mpepid=xxx
	 * @return 过滤句柄.
	 */
	HANDLE sw_mpefilter_open( char* url );

	/** 
	 * @brief 关闭过滤器
	 * @return 无.
	 */
	void sw_mpefilter_close( HANDLE hmpe );

	/** 
	 * @brief 设置数据回调处理函数
	 * @param hmpe 过滤器句柄
	 * @param callback 数据回调处理函数
	 * @param wparam 用户参数
	 * @return 0成功,否则错误码
	 */
	int sw_mpefilter_set_datacallback( HANDLE hmpe, data_output callback, unsigned long wparam);

	/** 
	 * @brief 查询有多少路数据
	 × @param hmpe 过滤器句柄
	 * @return 数目
	 */
	int sw_mpefilter_get_counts( HANDLE hmpe );

	/** 
	 * @brief 根据idx来查询数据的来源信息
	 * @param hmpe 过滤器句柄
	 * @param hmpe idx
	 * @param ip[output]
	 * @param port[output]
	 * @return 0成功,否则错误码
	 */
	int sw_mpefilter_get_info_fromidx( HANDLE hmpe ,int idx,unsigned long *ip, unsigned short *port );

	/** 
	 * @brief 根据idx来数据的来源信息
	 * @param hmpe 过滤器句柄
	 * @param hmpe idx
	 * @param ip[output]
	 * @param port[output]
	 * @return 0成功,否则错误码
	 */
	int sw_mpefilter_set_infobyidx( HANDLE hmpe ,int idx,unsigned long ip, unsigned short port );

	/** 
	 * @brief 根据IP port来获取索引号
	 * @param hmpe 过滤器句柄
	 * @param ip
	 * @param port
	 * @return 索引号
	 */
	int sw_mpefilter_get_idx_fromip( HANDLE hmpe ,unsigned long ip, unsigned short port ); 

	/** 
	 * @brief 启动数据索引为idx的过滤
	 * @param hmpe 
	 * @param idx 对应要启动的索引号
	 * @return 0成功,否则错误码
	 */
	int sw_mpefilter_start( HANDLE hmpe ,int idx );

	/** 
	 * @brief 停止数据索引为idx的过滤
	 * @param hmpe 
	 * @param idx 对应要停止的索引号
	 * @return 0成功,否则错误码
	 */
	int sw_mpefilter_stop( HANDLE hmpe ,int idx );


#ifdef __cplusplus
}
#endif

#define MAX_CHANNEL_NUM 128
#define MAX_PATH_LEN 128
#define MAX_BUFFER_SIZE 50*1024*1024
#define URL_SIZE 64

//MPE Filter对象
typedef struct mpefilter{
	//数据回调处理函数指针
	data_output data_callback;
	//用户参数
	uint32_t wparam;
	//数据读取线程ID
	HANDLE pthrdread;
	//数据处理线程ID
	HANDLE pthrd;
#ifdef soft_mpesection
	//section 过滤器
	HANDLE psecfilter;
#endif
	//tuner 句柄
	HANDLE ptuner;
	//网络信息
	struct{
		uint32_t ip;
		uint16_t port;
		bool started;
	}netinfo[MAX_CHANNEL_NUM];
	//缓冲区
	uint8_t* databuf;
	//数据缓冲队列
	dataqueue_t* datastream;
	//数据输入类型
	struct{
		//网络
		int skt;
		//DVB
		struct{
			HI_HANDLE handle;
			HI_HANDLE channel;
		}filter;
		//文件
		FILE* fp;
	}fddata;
	//节目数统计
	int program_count;
	bool isexit;             
}mpefilter_t;

#endif //__SW_MPEFILTER_H__


