
#ifndef _DATAQUEUE_H_
#define _DATAQUEUE_H_

#ifdef __cplusplus
extern "C"
{
#endif

typedef struct dataqueue
{
    int size;
    uint8_t *real_buf;
    uint8_t *buf;
    uint8_t *buf_end;
    uint8_t *head;
    uint8_t *tail;
    uint8_t *new_begin;
    uint8_t *read_pos; 
    bool block; //�ռ䲻��ʱ�Ƿ�ȴ���Ĭ��Ϊ�ȴ�
    HANDLE queueevent;
}dataqueue_t;

#define DATABLOCK_HEADER_LEN       48 //��ý���ڴ��ͷ��Ϣ����

#define dq_block_size(buf)        (*(int32_t *) buf)
#define dq_media_id(buf)          (*(uint8_t *)(buf +  4))
#define dq_media_event(buf)       (*(uint16_t*)(buf +  6))
#define dq_payload_offset(buf)    (*(uint32_t*)(buf +  8))
#define dq_payload_size(buf)      (*(uint32_t*)(buf + 12))
#define dq_pcr(buf)               (*(uint64_t*)(buf + 16))
#define dq_pts(buf)               (*(uint64_t*)(buf + 24))

dataqueue_t* dataqueue_create( uint8_t* buf,int size );

void dataqueue_destory( dataqueue_t *sqobj );

int dataqueue_record_newbegin( dataqueue_t *sqobj );

int dataqueue_reset(dataqueue_t *sqobj);

int dataqueue_get_writebuf(dataqueue_t *sqobj, int type_id, uint8_t **buf, uint32_t *size);

int dataqueue_write_complete(dataqueue_t *sqobj, int type_id, uint32_t timestamp, uint8_t *buf, int size, int skip);

int dataqueue_get_readbuf(dataqueue_t *sqobj, uint8_t **buf, uint32_t *size);

int dataqueue_read_complete(dataqueue_t *sqobj, uint8_t *buf);

void dataqueue_set_block(dataqueue_t *sqobj, bool block);

int dataqueue_get_data_size(dataqueue_t *sqobj);

int dataqueue_get_size(dataqueue_t *sqobj);

#ifdef __cplusplus
}
#endif

#endif // _DATAQUEUE_H_
