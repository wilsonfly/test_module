/**
\file
\brief �뵥����ص�����
\copyright Shenzhen Hisilicon Co., Ltd.
\date 2008-2018
\version draft
\author x57522
\date 2010-8-9
*/

#ifndef __COMMON_BOARDCFG_H__
#define __COMMON_BOARDCFG_H__

/* add include here */


#ifdef __cplusplus
extern "C" {
#endif

/***************************** Macro Definition ******************************/
/* CHIP_TYPE */
//#define CHIP_TYPE_hi3716mv100 
//#define CHIP_TYPE_hi3720v100
//#define CHIP_TYPE_hi3716hv100
//#define CHIP_TYPE_hi3716cv100

/* BOARD_TYPE */
//#define BOARD_TYPE_hi3716mstb
//#define BOARD_TYPE_hi3716mdmo 
//#define BOARD_TYPE_hi3716lstb
//#define BOARD_TYPE_hi3716hdmo
#define BOARD_TYPE_hi3716cdmo

#if  defined (BOARD_TYPE_hi3716mstb) || defined (BOARD_TYPE_hi3716mdmo) || defined (BOARD_TYPE_hi3716lstb) || defined (BOARD_TYPE_hi3716lstbverc) || defined (BOARD_TYPE_hi3716mstbverc) 
/* TUNER */
#define TUNER_USE    0
#define TUNER_TYPE   HI_UNF_TUNER_DEV_TYPE_TDA18250
#define DEMOD_TYPE   HI_UNF_DEMOD_DEV_TYPE_3130I
#define I2C_CHANNEL  HI_UNF_I2C_CHANNEL_QAM
/* DAC */
#define DACMODE0 HI_UNF_DISP_DAC_MODE_HD_Y
#define DACMODE1 HI_UNF_DISP_DAC_MODE_HD_PR
#define DACMODE2 HI_UNF_DISP_DAC_MODE_HD_PB
#define DACMODE3 HI_UNF_DISP_DAC_MODE_SVIDEO_C
#define DACMODE4 HI_UNF_DISP_DAC_MODE_SVIDEO_Y
#define DACMODE5 HI_UNF_DISP_DAC_MODE_CVBS
/* SIO */
#elif defined (BOARD_TYPE_hi3716mtst)
/* TUNER */
#define TUNER_USE    0
#define TUNER_TYPE   HI_UNF_TUNER_DEV_TYPE_TDA18250
#define DEMOD_TYPE   HI_UNF_DEMOD_DEV_TYPE_3130I
#define I2C_CHANNEL  HI_UNF_I2C_CHANNEL_QAM
/* DAC */
#define DACMODE0 HI_UNF_DISP_DAC_MODE_HD_Y
#define DACMODE1 HI_UNF_DISP_DAC_MODE_HD_PR
#define DACMODE2 HI_UNF_DISP_DAC_MODE_HD_PB
#define DACMODE3 HI_UNF_DISP_DAC_MODE_SVIDEO_C
#define DACMODE4 HI_UNF_DISP_DAC_MODE_SVIDEO_Y
#define DACMODE5 HI_UNF_DISP_DAC_MODE_CVBS
/* SIO */
#elif defined (BOARD_TYPE_hi3716hdmo) || defined (BOARD_TYPE_hi3716hdmoverb) || defined (BOARD_TYPE_hi3716cdmoverb) || defined (BOARD_TYPE_hi3716ctst)
/* TUNER */
#define TUNER_USE    0
#define TUNER_TYPE   HI_UNF_TUNER_DEV_TYPE_TDA18250
#define DEMOD_TYPE   HI_UNF_DEMOD_DEV_TYPE_3130I
#define I2C_CHANNEL  HI_UNF_I2C_CHANNEL_QAM
/* DAC */
#define DACMODE0 HI_UNF_DISP_DAC_MODE_HD_PR
#define DACMODE1 HI_UNF_DISP_DAC_MODE_HD_Y
#define DACMODE2 HI_UNF_DISP_DAC_MODE_HD_PB
#define DACMODE3 HI_UNF_DISP_DAC_MODE_SVIDEO_C
#define DACMODE4 HI_UNF_DISP_DAC_MODE_SVIDEO_Y
#define DACMODE5 HI_UNF_DISP_DAC_MODE_CVBS
/* SIO */
#elif defined (BOARD_TYPE_hi3716cdmo) 
/* TUNER */
#define TUNER_USE    0
#define TUNER_TYPE   HI_UNF_TUNER_DEV_TYPE_TDA18250
#define DEMOD_TYPE   HI_UNF_DEMOD_DEV_TYPE_3130I
#define I2C_CHANNEL  HI_UNF_I2C_CHANNEL_QAM
/* DAC */
#define DACMODE0 HI_UNF_DISP_DAC_MODE_HD_PR
#define DACMODE1 HI_UNF_DISP_DAC_MODE_HD_Y
#define DACMODE2 HI_UNF_DISP_DAC_MODE_HD_PB
#define DACMODE3 HI_UNF_DISP_DAC_MODE_SVIDEO_C
#define DACMODE4 HI_UNF_DISP_DAC_MODE_SVIDEO_Y
#define DACMODE5 HI_UNF_DISP_DAC_MODE_CVBS
/* SIO */
#elif defined (BOARD_TYPE_hi3720tst1)
/* TUNER */
#define TUNER_USE    0
#define TUNER_TYPE   HI_UNF_TUNER_DEV_TYPE_TDA18250
#define DEMOD_TYPE   HI_UNF_DEMOD_DEV_TYPE_3130I
#define I2C_CHANNEL  HI_UNF_I2C_CHANNEL_QAM
/* DAC */
#define DACMODE0 HI_UNF_DISP_DAC_MODE_HD_PR
#define DACMODE1 HI_UNF_DISP_DAC_MODE_HD_Y
#define DACMODE2 HI_UNF_DISP_DAC_MODE_HD_PB
#define DACMODE3 HI_UNF_DISP_DAC_MODE_SVIDEO_C
#define DACMODE4 HI_UNF_DISP_DAC_MODE_SVIDEO_Y
#define DACMODE5 HI_UNF_DISP_DAC_MODE_CVBS
/* SIO */
#elif defined (BOARD_TYPE_fpga)
/* TUNER */
#define TUNER_USE    1
#define TUNER_TYPE   HI_UNF_TUNER_DEV_TYPE_1026
#define DEMOD_TYPE   HI_UNF_DEMOD_DEV_TYPE_PHILIP
#define I2C_CHANNEL  HI_UNF_I2C_CHANNEL_0
/* DAC */
#define DACMODE0 HI_UNF_DISP_DAC_MODE_HD_PR
#define DACMODE1 HI_UNF_DISP_DAC_MODE_HD_Y
#define DACMODE2 HI_UNF_DISP_DAC_MODE_HD_PB
#define DACMODE3 HI_UNF_DISP_DAC_MODE_SVIDEO_C
#define DACMODE4 HI_UNF_DISP_DAC_MODE_SVIDEO_Y
#define DACMODE5 HI_UNF_DISP_DAC_MODE_CVBS
/* SIO */
#else
    #error YOU MUST DEFINE  BOARD_TYPE!
#endif

/*************************** Structure Definition ****************************/



/********************** Global Variable declaration **************************/



/******************************* API declaration *****************************/



#ifdef __cplusplus
}
#endif
#endif /* __COMMON_BOARDCFG_H__ */
