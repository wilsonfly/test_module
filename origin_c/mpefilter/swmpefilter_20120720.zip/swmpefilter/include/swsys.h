#ifndef SWSYS_H
#define SWSYS_H

#ifdef __cplusplus
extern  "C" 
{
#endif

extern HANDLE g_hSysReg ;

bool sw_sys_init();


void sw_sys_exit();


int sw_sys_reboot(unsigned long param);


int sw_sys_shutdown(unsigned long param);

int sw_sys_set_mac( char *mac );

int sw_sys_get_connstatus();

int sw_sys_set_kernelog_enable(bool enable);


void sw_sys_highmem_print();

uint64_t sw_sys_get_tick();


void sw_sys_dump_enet(void);

/** 
 * ���þ�����·
 * 
 * @param bMute 
 */	
void sw_sys_set_mute_circuit(bool bMute);
	

#ifdef __cplusplus
}
#endif

#endif
