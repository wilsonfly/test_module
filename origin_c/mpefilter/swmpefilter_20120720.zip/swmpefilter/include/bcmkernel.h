#ifndef BCMKERNEL_H__
#define BCMKERNEL_H__

#include <stdlib.h>
#include <stdio.h>
#include <string.h>

#define bcmKNIfree(mem) free(mem)
#define bcmKNImalloc(size) malloc(size)
#define bcmKNIprintf printf
#define DBGMSG printf

#endif

