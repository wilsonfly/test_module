#ifndef BCMSCT_INDEX_H__
#define BCMSCT_INDEX_H__

#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

/**
* Summary:
* Data structure for 4 word start code table (SCT) index entry. 
*
* Description:
* In practice, you don't need to know anything about the interals of this structure. Just read data
* from the Start Code Detect (SCD) hardware in chunks equal to sizeof(BSCT_Entry). 
* Bcmindexer will parse it and produce the Broadcom index.
**/
typedef struct
{
	uint32_t startCodeBytes;		/* 31:24 Start Code, 23:8 Two Bytes after SC, 7:0 Byte offset into trans packet */
	uint32_t recordByteCount;	/* Byte offset from start of record to start of trans packet */
	uint32_t recordByteCountHi;	/* 31:24 MSB Record Offset, 23:0 reserved */
	uint32_t flags;				/* various flags */
} BSCT_Entry;

/**
Summary:
Structure on a 6 word SCT entry.
**/
typedef struct BSCT_SixWord_Entry
{
	uint32_t word0;				/* 31:24 SC_ENTRY_TYPE, 23:0 reserved */
	uint32_t word1;				/* 31:0 reserved */
	uint32_t startCodeBytes;		/* 31:24 Start Code, 23:8 Two Bytes after SC, 7:0 Byte offset into trans packet */
	uint32_t recordByteCount;	/* Byte offset from start of record to start of trans packet */
	uint32_t recordByteCountHi;	/* 31:24 MSB Record Offset, 
		23:0 additional ES payload data, bytes 2, 3 and 4 */
	uint32_t flags;				/* 31:24 flags, 
		23:0 additional ES payload data, bytes 5, 6 and 7 */
} BSCT_SixWord_Entry;

#ifdef __cplusplus
}
#endif

#endif /* BCMSCT_INDEX_H__ */
