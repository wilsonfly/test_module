 /* Copyright by sunniwell,All rights reserved.
 *
 * ��������ʽ�����ӿ�
 * @version %I% %G%
 * @author chenkai
 */
#ifndef __TSPARSER_H__
#define __TSPARSER_H__

#define MAX_AV_PIDS 		16

typedef struct subtitle_descriptor
{
    char language[4]; 
    uint16_t pid; 
    uint16_t com_page_id; 
    uint16_t anc_page_id; 
}subt_dscr; 

typedef struct tsparser_t
{
	uint8_t  pat_section[1024];
	uint16_t pat_section_length;
	uint16_t pat_section_cur;
	uint8_t  pat_section_continuity;
	uint8_t  pmt_section[1024];
	uint16_t pmt_section_length;
	uint16_t pmt_section_cur;
	uint8_t  pmt_section_continuity;
	uint16_t pmt_pid;
	uint16_t pcr_pid;
	uint16_t video_num;
	uint16_t video_pid[MAX_AV_PIDS];
	uint16_t video_type[MAX_AV_PIDS];
	uint16_t audio_num;
	uint16_t audio_pid[MAX_AV_PIDS];
	uint16_t audio_type[MAX_AV_PIDS];
	uint16_t ecm_num;
	uint16_t ecm_pid;//ECM PID
	uint16_t ca_system_id;//ECM PID
	bool ecm_pid_changed;//ECM PID�Ƿ�ı�
	uint8_t globaldesc[32];
	uint8_t globaldesclen;
	uint32_t videopid;
	uint8_t	videodesc[32];
	uint8_t	videodesclen;
	uint32_t audiopid;
	uint8_t	audiodesc[32];
	uint8_t	audiodesclen;
	uint16_t sub_num;
	subt_dscr subtitles[MAX_AV_PIDS];
	unsigned char pat[188];
	unsigned char pmt[188];
}tsparser_t;

/* open a ts parser */
int tsparser_open(tsparser_t* parser);

/* close a ts parser */
void tsparser_close(tsparser_t* parser);

/* send data to parser */
int tsparser_on_data(tsparser_t* parser,uint8_t* buf,int size);

#endif /*__SWTSPARSER_H__*/
