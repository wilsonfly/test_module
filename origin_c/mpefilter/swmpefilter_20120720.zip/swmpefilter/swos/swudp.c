/************************************************************
* AUTHOR: huanghuaming
* CONTENT: UDP�����ӿ�
* NOTE:	
* HISTORY:
		[2004-4-28] huanghuaming created
***********************************************************/
#include "stdafx.h"
#include "swudp.h"
#include "swlog.h"


/* ����socket */
int sw_udp_socket()
{
	return socket( AF_INET, SOCK_DGRAM, IPPROTO_UDP );
}

/* ����socket */
void sw_udp_close( int skt )
{
	if( skt != -1 )
		close( skt );
}

/* �󶨽��յ�ַ�Ͷ˿� */
int sw_udp_bind( int skt, unsigned long ip, unsigned short port )
{
	struct sockaddr_in local;

	/* �󶨱��ص�ַ�Ͷ˿� */
	memset( &local, 0, sizeof(local) );
	local.sin_family = AF_INET;
	local.sin_addr.s_addr = ip;
	local.sin_port = port;
	if( bind ( skt, (struct sockaddr *)&local,	sizeof(local)) < 0 )
		return -1;

	return 0;
}

/* ����ಥ�� */
int sw_udp_join( int skt, unsigned long ip )
{
	int ttl = 127;
	bool fFlag = true;
	struct ip_mreq mreq;

	/* ����ಥ�� */
	if( IS_MULTICAST_IP(ip) )
	{
		memset( &mreq, 0, sizeof(mreq) );
		mreq.imr_multiaddr.s_addr = ip;
		mreq.imr_interface.s_addr = INADDR_ANY;

 		if( setsockopt( skt, IPPROTO_IP, IP_ADD_MEMBERSHIP, (char*)&mreq, sizeof(mreq) ) < 0 )
		{
			sw_log_debug("cannot add to multicast\n" );
			return -1;
		}
		if( setsockopt( skt, IPPROTO_IP, IP_MULTICAST_TTL, (char*)&ttl, sizeof(ttl) ) == SOCKET_ERROR)
		{
			sw_log_debug("cannot set multicast args. \n" );
		}
		if( setsockopt(skt, IPPROTO_IP, IP_MULTICAST_LOOP, (char *)&fFlag, sizeof(fFlag)) == SOCKET_ERROR)
		{
			sw_log_debug("cannot set multicast ttl args. \n" );
		}
	}

	return 0;
}

/* �˳��鲥�� */
int sw_udp_drop( int skt, unsigned long ip )
{
	/* ���������ַ���鲥��ַ��Χ�ڣ����˳������鲥 */
	if( IS_MULTICAST_IP(ip) )
	{
		struct ip_mreq mreq;
		memset( &mreq, 0, sizeof(mreq) );
		mreq.imr_multiaddr.s_addr = ip;
		mreq.imr_interface.s_addr = INADDR_ANY;
		setsockopt( skt, IPPROTO_IP, IP_DROP_MEMBERSHIP, (char*)&mreq, sizeof(mreq) );
	}

	return  0;
}

/* �������� */
int sw_udp_send( int skt, unsigned long ip, unsigned short port, char *buf, int size )
{
	struct sockaddr_in sn;
	unsigned int slen = sizeof(sn);

	memset( &sn, 0, sizeof(sn) );
	slen = sizeof(sn);
	sn.sin_family = AF_INET;
	sn.sin_addr.s_addr = ip;
	sn.sin_port=  port;

	return sendto( skt, buf, size, 0, (struct sockaddr *)&sn, slen );
}

/* �������� */
int sw_udp_recv( int skt, unsigned long *ip, unsigned short *port, char *buf, int size )
{
	struct sockaddr_in from;
	unsigned int slen = sizeof( from );

	memset( &from, 0, sizeof(from) );
	slen = recvfrom( skt, buf, size, 0, (struct sockaddr *)&from, (socklen_t*)&slen );

	if( ip )
	  *ip = from.sin_addr.s_addr;
	if( port )
		*port = from.sin_port;

	return slen;
}

/* ���� */
int sw_udp_ioctl( int skt, int type, unsigned long *val )
{
	return ioctl( skt, (long)type, val );
}

/* ���״̬ */
int sw_udp_select( int skt, fd_set *readfds, fd_set *writefds, fd_set *exceptfds, int timeout )
{
	struct timeval tv;

	if( readfds )
	{
		FD_ZERO( readfds );
		FD_SET( (unsigned int)skt, readfds );
	}
	if( writefds )
	{
		FD_ZERO( writefds );
		FD_SET( (unsigned int)skt, writefds );
	}
	if( exceptfds )
	{
		FD_ZERO( exceptfds );
		FD_SET( (unsigned int)skt, exceptfds );
	}
	if( 0 <= timeout )
	{
		tv.tv_sec = timeout/1000;
		tv.tv_usec = (timeout%1000)*1000;
		return select( skt+1, readfds, writefds, exceptfds, &tv );
	}
	else
		return select( skt+1, readfds, writefds, exceptfds, NULL );
}
