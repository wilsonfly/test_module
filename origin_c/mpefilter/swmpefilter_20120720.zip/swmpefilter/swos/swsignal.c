/************************************************************
* AUTHOR: lijian / huanghuaming / chenkai
* CONTENT: �ź��������ӿ�
* NOTE:	
* HISTORY:
* [2005-9-16] created
***********************************************************/
#include "stdafx.h"
#include "swmem.h"
#include "swsignal.h"


/* �����ź���,0=SUCCESS,-1=FAILED */
typedef struct sw_signal_t
{
  sem_t sem;
  int max_val;
}sw_signal_t;

#define swos_malloc malloc
#define swos_free free

HANDLE  sw_signal_create(int defval, int maxval )
{
	sw_signal_t* h = (sw_signal_t*)swos_malloc( sizeof(sw_signal_t) );
	if( h == NULL )
		return NULL;
	sem_init( &(h->sem), 0, defval );
	h->max_val = maxval;
	return h;
}

/* ���� */
void sw_signal_destroy( HANDLE sem )
{
	if( sem == NULL )
		return;
	
	sem_destroy( (sem_t*)sem );
	swos_free( sem );
}

/* �ȴ� */
int sw_signal_wait( HANDLE sem, int timeout )
{
	struct timespec tv;
	int ret = 0;	
	if( sem == NULL )
		return 0;
WAIT:	
	if( timeout <0 )
		ret = sem_wait( (sem_t*)sem );
	else
	{
		clock_gettime(CLOCK_REALTIME, &tv);
		tv.tv_nsec += (timeout%1000)*1000000; 
		if( tv.tv_nsec>= 1000000000 )
		{
			tv.tv_sec +=1;
			tv.tv_nsec-=1000000000;
		}
		tv.tv_sec += timeout/1000;
		ret =sem_timedwait( (sem_t*)sem, (const struct timespec *)&tv );
	}
	if( ret )
	{
		if( errno == EINTR )
		{
			printf("system interrupted call, wait again\n");
			goto WAIT;
		}
		return -1;
	}
	return 0;
}

/* �ͷ� */
void sw_signal_give( HANDLE sem )
{
	int val;
	if( sem == NULL )
		return;
	sem_getvalue((sem_t*)sem, &val);
	if( val < ((sw_signal_t*)sem)->max_val )
		sem_post( (sem_t*)sem );

	
}

void sw_signal_reset( HANDLE sem)
{
	sw_signal_give(sem);
	
}
