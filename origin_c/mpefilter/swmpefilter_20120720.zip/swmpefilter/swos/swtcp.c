/************************************************************
* AUTHOR: lijian / huanghuaming / chenkai
* CONTENT: TCP�����ӿ�
* NOTE:	
* HISTORY:
		[2005-9-16] created
***********************************************************/
#include "stdafx.h"
#include "swtcp.h"

/* ����socket */
int sw_tcp_socket()
{
  return socket( AF_INET, SOCK_STREAM, IPPROTO_TCP );
}

/* ����socket */
void sw_tcp_close( int skt )
{
	if( skt != -1 )
		close( skt );
}

/* ����Զ��,timeout��λms */
int sw_tcp_connect( int skt, unsigned long ip, unsigned short port )
{
	struct sockaddr_in addr;

	memset( &addr, 0, sizeof(addr) );
	addr.sin_family = AF_INET;
	addr.sin_addr.s_addr = ip;
	addr.sin_port = port;

	/* ��ʼ���� */
	return connect( skt, (struct sockaddr *)&addr, sizeof(addr) );
}

/* �󶨽��յ�ַ�Ͷ˿�, severʹ��bind()�뱾���󶨣�clientʹ��connect()��Զ���������� */
int sw_tcp_bind( int skt, unsigned long ip, unsigned short port )
{
	struct sockaddr_in addr;
	addr.sin_family = AF_INET;
	addr.sin_addr.s_addr = ip;
	addr.sin_port = port;
	return bind( skt, (struct sockaddr*)&addr, sizeof(addr) );
}

/* ��ʼ����, maxΪ���Ҷ��г��ȣ�������Ϊ5 */
int sw_tcp_listen( int skt, int max )
{
	return listen( skt, max );
}

/* �ȴ�Զ������ */
int sw_tcp_accept( int skt, unsigned long *ip, unsigned short *port )
{
	struct sockaddr_in from;
	unsigned int slen = sizeof(from);

	/*�ȴ�CLIENT������*/
	skt = accept( skt, (struct sockaddr *)&from, (socklen_t*)&slen );
	if( 0 <= skt )
	{
		if( ip )
			*ip = from.sin_addr.s_addr;
		if( port )
			*port = from.sin_port;
	}
	return skt;
}

/* �������� */
int sw_tcp_send( int skt, char *buf, int size )
{
	return send( skt, buf, size, 0 );
}

/* �������� */
int sw_tcp_recv( int skt, char *buf, int size )
{
	return recv( skt, buf, size, 0 );
}

/* ���� */
int sw_tcp_ioctl( int skt, int type, unsigned long *val )
{
	return ioctl( skt, (long)type, val );
}

/* ���״̬ */
int sw_tcp_select( int skt, fd_set *readfds, fd_set *writefds, fd_set *exceptfds, int timeout )
{
	struct timeval tv;

	if( readfds )
	{
		FD_ZERO( readfds );
		FD_SET( (unsigned int)skt, readfds );
	}
	if( writefds )
	{
		FD_ZERO( writefds );
		FD_SET(  (unsigned int)skt, writefds );
	}
	if( exceptfds )
	{
		FD_ZERO( exceptfds );
		FD_SET( (unsigned int)skt, exceptfds );
	}
	if( 0 <= timeout )
	{
		tv.tv_sec = timeout/1000;
		tv.tv_usec = (timeout%1000)*1000;
		return select( skt+1, readfds, writefds, exceptfds, &tv );
	}
	else
		return select( skt+1, readfds, writefds, exceptfds, NULL );
}
