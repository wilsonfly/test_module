/************************************************************
* AUTHOR: lijian / huanghuaming / chenkai
* CONTENT: �̺߳����ӿ�
* NOTE:	
* HISTORY:
* [2005-9-16] created
***********************************************************/
#include "stdafx.h"
#include "swmem.h"
#include "swthrd.h"
#include "swlog.h"
#include "swmutex.h"
#include "swsys.h"
#include <sys/times.h>
#include <sys/syscall.h>
#include "swcfglib.h"
#define MAX_THRD_NUM	64
#define swos_malloc malloc
#define swos_free free

typedef struct
{
	/* �߳�ID */
	pthread_t m_tid;
	/* �߳����Զ��� */
	pthread_attr_t m_attr;
	/* ���߳�PID */
	pid_t m_ppid;
	/* �߳�PID */
	pid_t m_pid;
	/*�̵߳��Ȳ���*/
	int m_policy;
	/* �̵߳����ȼ� */
	int m_priority;
	/* �źŵ� */
	sem_t m_sem;
	/* �̻߳ص����� */
	PThreadHandler m_pHandler;
	/* �ص��������� */
	unsigned long m_wParam;
	unsigned long m_lParam;	
	
	/* �Ƿ���ͣ */
	int bPause;
	/* ��ʾ��ǰ�߳��Ƿ��˳� */
	int m_bExit;
	/* �������� */
	char name[32];
}SThrdInfo;

static SThrdInfo *m_all[MAX_THRD_NUM];
static int m_ref = -1;
static HANDLE m_mutex = NULL;
static int m_global_policy = -1;

static void* SemaThreadHandler( void* lpParam );

/* ���̣߳��򿪺�����ͣ״̬ */
HANDLE sw_thrd_open( char *name, unsigned char priority, int policy, int stack_size, 
					PThreadHandler pHandler, unsigned long wParam, unsigned long lParam )
{
	int i, rc;
	pthread_attr_t *pAttr = NULL;
	SThrdInfo *info = NULL;
	struct sched_param param;

	int max_priority;
	int min_priority;

	if( m_ref < 0 )
	{
		memset( m_all, 0, sizeof(m_all) );
		m_ref = 0;
		m_mutex = sw_mutex_create();


	}
	
	if(m_mutex)
		sw_mutex_lock(m_mutex);
	
	/* ����Լ��˳����߳�, �ͷ���Դ */
	if(m_ref > MAX_THRD_NUM - 2)
	{
		
		for( i=0; i<MAX_THRD_NUM; i++ )
		{
			if(m_all[i] &&  m_all[i]->m_tid  != 0 && m_all[i]->m_pHandler == NULL)
			{
				sw_log_debug("Release self-exit thread<%s>\n", m_all[i]->name);
				
				pthread_attr_destroy( &m_all[i]->m_attr );
				sem_destroy( &m_all[i]->m_sem );
				memset(m_all[i], 0, sizeof(SThrdInfo));
			
				swos_free(m_all[i]);
				m_all[i] = NULL;
			
				m_ref--;
			}
		}
	}
	
	if(m_ref >= MAX_THRD_NUM)
	{
		sw_log_error("Thread num reach max!!\n");
		sw_mutex_unlock(m_mutex);
		return NULL;
		
	}
	info = swos_malloc(sizeof(SThrdInfo));
	
	if( info == NULL )
	{
		sw_log_debug("error: sw_thrd_open() failed\n" );
		if(m_mutex)
			sw_mutex_unlock(m_mutex);
	
		return NULL;
	}
	
	memset( info, 0, sizeof(SThrdInfo) );
	info->m_pHandler = pHandler;
	info->m_wParam = wParam;
	info->m_lParam = lParam;
	info->m_policy = policy;
	info->m_priority = (int)priority;
	info->bPause = 1;

	if(m_global_policy != -1)
	{
		info->m_policy = m_global_policy;
	}
	
	strncpy( info->name, name, sizeof( info->name )-1 );
	
	if(info->m_policy < SW_SCHED_NORMAL || info->m_policy > SW_SCHED_RR)
		info->m_policy = SW_SCHED_NORMAL;
	
	/* ��ʼ���߳����Զ��� */
	pAttr = &(info->m_attr);
	pthread_attr_init( pAttr );

	//�����̶߳�ջ��С
	if( stack_size < 65536 )
		stack_size = 65536;
	rc = pthread_attr_setstacksize(pAttr, stack_size);
	if(rc != 0)
	{
		unsigned int defsize = 0;
		pthread_attr_getstacksize(pAttr, &defsize);
		sw_log_error("sw_thrd_open [%s]: set stack size failed! %d, using default size %d\n", name, stack_size, defsize);
	}
	
	pthread_attr_setdetachstate(pAttr, PTHREAD_CREATE_DETACHED);
	/*���õ��Ȳ���*/
	pthread_attr_setschedpolicy( pAttr, info->m_policy /* SCHED_RR */ );

	/*��linuxϵͳ��, �߳����ȼ�ȡֵ��ΧΪ1~99, 1���, 99���*/
	param.sched_priority = 1;
	max_priority = sched_get_priority_max(info->m_policy);
	min_priority = sched_get_priority_min(info->m_policy);

	priority = max_priority - (priority * (max_priority - min_priority)) / 255;
	param.sched_priority = priority;
	/* �����źŵ� */
	if( sem_init( &(info->m_sem), 0, 0 ) == -1 )
	{
		if( pAttr )
			pthread_attr_destroy( pAttr );
		goto ERROR_EXIT;
	}
	/* ��ʼ�����߳� */
	if( pthread_create( &(info->m_tid), pAttr, SemaThreadHandler, (void*)info ) != 0 )
	{
		if( pAttr )
			pthread_attr_destroy( pAttr );
		sem_destroy( &(info->m_sem) );
		goto ERROR_EXIT;
	}
	//�߳�����ʱ�������ȼ�
	pthread_setschedparam(info->m_tid, info->m_policy, &param );

	/* �����߳̾�� */
	for( i=0; i<MAX_THRD_NUM; i++ )
	{
		if( m_all[i] == NULL)
		{
			m_all[i] = info;
			m_ref++;
			break;
			
		}
	}
	sw_log_debug("Thread-<%s : %d : %x> opened\n", info->name,i,(void*)info );

	if(m_mutex)
		sw_mutex_unlock(m_mutex);
	return info;

ERROR_EXIT:
	info->m_pHandler = NULL;
	info->m_tid  = 0;
	if(m_mutex)
		sw_mutex_unlock(m_mutex);
	sw_log_debug( "error: sw_thrd_open() failed !\n");
	return NULL;
}

/* �ر��߳� */
void sw_thrd_close( HANDLE hThrd, int ms )
{
	int i = 0,status = 0;
	void *result;
	int pthread_kill_err;

	SThrdInfo *info = (SThrdInfo *)hThrd;
	if( info == NULL )
		return;

	info->m_bExit = 1;
	sem_post( &(info->m_sem) );

	sw_log_debug("Thread-<%s : %d : %x> closing [%d]...\n", info->name,i,(void*)info, ms);

	/* �ȴ��߳��Լ��˳� */
	while(info->m_pHandler && ms > 0)
	{
		usleep(10*1000);
		ms -= 10;
	}

	if(m_mutex)
		sw_mutex_lock(m_mutex);

	for( i=0; i<MAX_THRD_NUM; i++ )
	{
		if( info == m_all[i])
			break;
	}

	if( MAX_THRD_NUM <= i )
	{
		if(m_mutex)
			sw_mutex_unlock(m_mutex);	
		return;
	}


	if(info->m_pHandler)
	{
		pthread_kill_err = pthread_kill(info->m_tid,SIGQUIT);
        if(pthread_kill_err == ESRCH)
            printf( "Thread<%s> is canneled or not exist!!!\n",info->name);
        else if(pthread_kill_err == EINVAL)
            printf("The signal is illegal value!!!\n");
        else
            printf("Thread<%s> is killed!!!\n",info->name);
#if 0				
		/* ǿ���˳� */
		if ( !pthread_cancel(info->m_tid) )
		{
			sw_log_debug( "Thread<%s> is canneled!!!\n",  info->name);
		}
		else
		{
			status = pthread_join(info->m_tid, &result);
			if (status == 0)
			{
				if (result == PTHREAD_CANCELED)
				{
					sw_log_debug("Thread canceled!!!\n");//����߳��Ǳ�ȡ���ģ��ش�ӡ��
				}
				else
				{
					sw_log_debug ("result:%d\n", (int)result);
		
				}

			}
		}
#endif		
	}
	

	pthread_attr_destroy( &info->m_attr );
	sem_destroy( &info->m_sem );
	memset( info, 0, sizeof(*info) );
	m_all[i] = NULL;
	swos_free(info);
	
	m_ref--;

	if(m_mutex)
		sw_mutex_unlock(m_mutex);
}

/* �Ƿ�� */
unsigned int sw_thrd_is_openned( HANDLE hThrd )
{
	SThrdInfo *info = (SThrdInfo *)hThrd;
	if( info == NULL )
		return false;
	return info->m_tid != 0;
}

/* �����߳����ȼ�  */
void sw_thrd_set_priority( HANDLE hThrd, unsigned char priority )
{
	struct sched_param param;
	SThrdInfo *info = (SThrdInfo *)hThrd;
	if( info == NULL )
		return ;

	info->m_priority = (int)priority;
	priority = sched_get_priority_max(info->m_policy) - (priority * (sched_get_priority_max(info->m_policy) - sched_get_priority_min(info->m_policy))) / 255;
	param.sched_priority = priority;
	pthread_setschedparam(info->m_tid, SCHED_RR, &param );
		

}

/** 
 * @brief ȡ���߳����ȼ�,priority�ķ�ΧΪ[0,255],0��ʾ���ȼ����,255���
 * 
 * @param hThrd �߳̾�� 
 * 
 * @return ��ǰ�̵߳����ȼ�
 */
unsigned char sw_thrd_get_priority( HANDLE hThrd )
{
	SThrdInfo *info = (SThrdInfo *)hThrd;
	return info->m_priority;
	
}


/* ��ͣ */
void sw_thrd_pause( HANDLE hThrd )
{
	SThrdInfo *info = (SThrdInfo *)hThrd;
	if( info )
		info->bPause = 1;
}

bool sw_thrd_is_paused(HANDLE hThrd)
{
	
	SThrdInfo *info = (SThrdInfo *)hThrd;
	if( info )
		return info->bPause;
	return false;
	
}

/* ���� */
void sw_thrd_resume( HANDLE hThrd )
{
	SThrdInfo *info = (SThrdInfo *)hThrd;
	if( info )
	{
		info->bPause = 0;
		sem_post( &(info->m_sem) );
	}
}

/* �ӳ�(ms) */
void sw_thrd_delay( int timeout )
{
	usleep( timeout*1000 );
}

/* ȡ��ϵͳ����ʱ��(ms) */
unsigned int sw_thrd_get_tick()
{
	/* NO 1. getimeofday */
/* 	static bool firsttimehere = TRUE; */
/* 	static struct timeval timeorigin; */

/* 	struct timeval now; */

/* 	gettimeofday(&now,NULL); */

/* 	if( firsttimehere ) */
/* 	{ */
/* 		timeorigin = now; */
/* 		firsttimehere=FALSE; */
/* 	} */

/* 	return (now.tv_sec-timeorigin.tv_sec)*1000 + (now.tv_usec-timeorigin.tv_usec)/1000; */
	
	/* NO 2. linux jiffies */
/* 	static bool firsttimehere = true; */
/* 	static uint64_t timeorigin; */
/* 	uint64_t now = sw_sys_get_tick(); */
/* 	if(firsttimehere) */
/* 	{ */
/* 		timeorigin = now; */
/* 		firsttimehere = false; */
/* 	} */

/* 	return now - timeorigin; */

/* NO 3. times sysconf(_SC_CLK_TCK); he number of clock ticks per second can be obtained using */

	struct tms tm;
	static uint32_t timeorigin;
	static bool firsttimehere = true;

	uint32_t now = times(&tm);
	if(firsttimehere)
	{
		timeorigin = now;
		firsttimehere = false;
	}

	return (now - timeorigin)*10;
	
	
}

static void* SemaThreadHandler( void* lpParam )
{

	SThrdInfo *info = (SThrdInfo *)lpParam;

	info->m_ppid = getppid();
	info->m_pid =getpid();
	/* pthread_setcancelstate( PTHREAD_CANCEL_ENABLE, NULL); //�����˳��߳� */
//	pthread_setcanceltype(PTHREAD_CANCEL_ASYNCHRONOUS, NULL); //��������ȡ��

	while( !info->m_bExit )
	{
		
		if( info->bPause )
			sem_wait( &(info->m_sem) );
		/* ���Ӳ��Ե� */
		/* pthread_testcancel(); */

		if( info->m_pHandler == NULL || info->m_bExit )
			break;

		if( ! info->m_pHandler( info->m_wParam, info->m_lParam ) )
			break;
	}

	info->m_pHandler = NULL;
	sw_log_debug( "Thread-<%s> exit self\n", info->name );

	return NULL;
}

void sw_thrd_set_global_policy(int policy)
{
	m_global_policy = policy;
	

}

/* ��ӡ��Ϣ */
void sw_thrd_print()
{
	int i;

	for( i=0; i<MAX_THRD_NUM; i++ )
	{
		if(m_all[i] && m_all[i]->m_pHandler )
		{
			sw_log_info("%-2d 0x%08x %-14s ppid=%d pid=%d proc=0x%-8x policy=%d priority=%d pause=%d \n", 
				   i, (int)(m_all[i]), m_all[i]->name,m_all[i]->m_ppid, m_all[i]->m_pid, (int)m_all[i]->m_pHandler, m_all[i]->m_policy, m_all[i]->m_priority, m_all[i]->bPause);
		}
	}
	sw_log_debug( "\nref = %d\n", m_ref );
}

int sw_thrd_getinfo( char* buf, int size )
{
	char szBuf[255];
	int i, n, len;

	*buf = 0;
	len = 0;
	for( i=0; i<MAX_THRD_NUM; i++ )
	{
		if(m_all[i] && m_all[i]->m_pHandler )
		{
			n = sprintf( szBuf, "%-2d 0x%08x %-14s proc=0x%-8x policy=%d priority=%-3d pause=%d ppid=%d pid=%d\n", 
				   i, (int)(m_all[i]), m_all[i]->name, (int)m_all[i]->m_pHandler,
				   m_all[i]->m_policy, m_all[i]->m_priority, m_all[i]->bPause, m_all[i]->m_ppid, m_all[i]->m_pid);
			if( len + n < size )
			{
				strcpy( buf+len, szBuf );
				len += n;
			}
		}
	}
	n = sprintf( szBuf, "\nref = %d\n", m_ref );
	if( len + n < size )
		strcpy( buf+len, szBuf );
	return len;
}

HANDLE sw_thrd_find_byname( char* name )
{
	int i;
	for( i=0; i<MAX_THRD_NUM; i++ )
	{
		if(m_all[i] && m_all[i]->m_pHandler && !strcmp(name, m_all[i]->name) )
			return m_all[i];
	}
	return NULL;
}

