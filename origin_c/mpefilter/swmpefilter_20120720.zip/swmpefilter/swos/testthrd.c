
#include "stdafx.h"
#include "swthrd.h"
#include "swmutex.h"

static HANDLE m_signal = NULL;
static int m_count1 = 0;
static int m_count2 = 0;

static bool ConsoleThreadHandler(unsigned long wParam, unsigned long lParam )
{
	char* p = malloc(1024*1024);
	char* p1 = malloc(1024*1024);

	while(1)
	{
//		usleep(1000*10);
  
/* 		fprintf (stderr, "wait %d\n", wParam); */
/* 		sw_signal_wait(m_signal, -1); */

		fprintf (stderr, "wait end %d\n", wParam);
		memcpy(p, p1, 1024*1024);
		if(wParam == 1)
			m_count1++;
		if(wParam == 2)
			m_count2++;	
		usleep(1);
		
		
	}
	
	return 1;
}


int main(int argc, char** argv)
{
	
	HANDLE h;
	HANDLE h1;
	int i;
  
	for(;;)
	{
		unsigned int tick = sw_thrd_get_tick();
		printf("tick:%u\n", tick);
		usleep(1000*1000);
		
	}
	
	m_signal = sw_signal_create(0, 1);
  
	/* �������� */
	h = sw_thrd_open( "ConsoleReader", 250, 1, 4096, ConsoleThreadHandler, (unsigned long)1, 0 );


	h1 = sw_thrd_open( "ConsoleReader", 25, 1, 4096, ConsoleThreadHandler, (unsigned long)2, 0 );

	sw_thrd_resume(h1);
	sw_thrd_resume(h);

	getchar();
	
	printf("==>%d %d\n", m_count1, m_count2);
	
/* 	/\* ��������, ȷ�������ڴ�й¶ *\/ */
/* 	for(i=0;i<10000;i++) */
/* 	{ */
/* 		h = sw_thrd_open( "ConsoleReader", 60, 1, 4096, ConsoleThreadHandler, (unsigned long)i, 1000 ); */

/* 		sw_thrd_resume(h); */
/* 		usleep(100*1000); */
/* 		sw_thrd_close(h, 1000); */
/* 	} */
  
}
