/************************************************************
* AUTHOR: lijian / huanghuaming / chenkai
* CONTENT: �����������ӿ�
* NOTE:	
* HISTORY:
* [2005-9-16] created
***********************************************************/
#include "stdafx.h"
#include "swmem.h"
#include "swmutex.h"
#include "swlog.h"


#define swos_malloc malloc
#define swos_free free

/* ����������,0=SUCCESS,-1=FAILED */
HANDLE sw_mutex_create()
{

	pthread_mutex_t* h = swos_malloc(sizeof(pthread_mutex_t));
	
	if(h)
		pthread_mutex_init(h, NULL);
	
	return h;
	
}

/* ���� */
void sw_mutex_destroy( HANDLE mutex )
{
	pthread_mutex_t* h = (pthread_mutex_t*)mutex;
	if(h==NULL)
		return;
	
	pthread_mutex_destroy(h);
	swos_free(h);
	
}

/* ���� */
void sw_mutex_lock( HANDLE mutex )
{
	if( mutex == NULL )
		return;
	pthread_mutex_lock((pthread_mutex_t*)mutex );

}

/* ���� */
void sw_mutex_unlock( HANDLE mutex )
{
	if( mutex == NULL )
		return;
	pthread_mutex_unlock((pthread_mutex_t*)mutex );

}
