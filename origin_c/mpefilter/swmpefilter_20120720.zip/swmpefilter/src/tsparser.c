 /* Copyright by sunniwell,All rights reserved.
 *
 * ��������ʽ����ʵ��
 * @version %I% %G%
 * @author chenkai
 */
#include "stdafx.h"
#include "tsparser.h"
/* parser pmt */
static int sw_tsparser_on_pmt(tsparser_t* parser,uint8_t* buf, int size,
			uint8_t playload_unit_start_indicator,
 			uint8_t adaptaion_field_length,uint8_t continuity_counter);

static int sw_tsparser_on_pat(tsparser_t* parser,uint8_t* buf, int size,
			uint8_t playload_unit_start_indicator,
 			uint8_t adaptaion_field_length,uint8_t continuity_counter);


/* open a ts parser */
int tsparser_open(tsparser_t* parser)
{
	if( parser != NULL )
	{
		memset(parser,0,sizeof(tsparser_t));
		parser->pat_section_length  = -1;
		parser->pmt_section_length  = -1;
	}
	return 0;
}


/* close a ts parser */
void tsparser_close(tsparser_t* parser)
{
	if( parser != NULL )
	{
		memset(parser,0,sizeof(tsparser_t));
		parser->pat_section_length  = -1;
		parser->pmt_section_length  = -1;
	}
}

/* send data to parser */
int tsparser_on_data(tsparser_t* parser,uint8_t* buf,int size)
{
	uint8_t transport_error_indicator;
	uint8_t playload_unit_start_indicator;
	uint8_t transport_priority;
	uint16_t PID;
	uint8_t transport_scrambling_control;
	uint8_t adaptation_field_control;
	uint8_t adaptation_field_length;
	uint8_t continuity_counter;
	int ret;

	/* У��TS PACKET�� */
	if( *buf != 0x47 || size!= 188 )
		return -1;
	
	transport_error_indicator = ((*(buf+1)) & 0x80) >> 7;
	playload_unit_start_indicator = ((*(buf+1)) & 0x40) >> 6;
	transport_priority = ((*(buf+1)) & 0x20) >> 5;
	PID = ( (*(buf+1)) & 0x1F );
	PID = (PID<<8) + (*(buf+2));
	transport_scrambling_control = ( (*(buf+3)) & 0xC0 )>>6;
	adaptation_field_control = ( (*(buf+3)) & 0x30 ) >> 4;
	continuity_counter =  ( (*(buf+3)) & 0x0F );
	
	/* ��� adaptation_field_control,������adaptation_field_length */
	adaptation_field_length = 0;
	if( (adaptation_field_control & 0x01 )== 0 )
		return SW_OK;
	else if( adaptation_field_control == 0x03 )
		adaptation_field_length = buf[4] + 1;
	
	ret = -1;
	if( PID == 0 )
		sw_tsparser_on_pat(parser,buf,size,playload_unit_start_indicator,adaptation_field_length,continuity_counter);
	else if( parser->pmt_pid == PID )
		ret = sw_tsparser_on_pmt(parser,buf,size,playload_unit_start_indicator,adaptation_field_length,continuity_counter);
	
	return ret;
}

/* parser pat */
static int sw_tsparser_on_pat(tsparser_t* parser,uint8_t* buf, int size,
			uint8_t playload_unit_start_indicator,
 			uint8_t adaptaion_field_length,uint8_t continuity_counter)
{
	uint8_t fill_bytes;
	uint16_t p_num,pid;
	int i=0;
	memcpy( parser->pat,buf,188);
	/* ȥ���ĸ��ֽڵ�ͬ��ͷ */
	i=4;
	/* ȥ��adaptation_field */
	i += adaptaion_field_length;
	
	/* ��һ����ǰ��1��Ϊ0���ֽ� */
	if( playload_unit_start_indicator == 1 )
	{
		fill_bytes = buf[i];
		i++;
		i += fill_bytes;

		/* TABLE ID */
		i++;

		/* ����section���� */
		parser->pat_section_length =  buf[i] & 0x0F;
		parser->pat_section_length = (parser->pat_section_length<<8) + buf[i+1];
		parser->pat_section_length -= 4;
		i += 2;
		/* ��鳤���Ƿ�Ϸ� */
		if( parser->pat_section_length >1024 )
			return -1;
			
		if( ( size-i )< parser->pat_section_length )
		{
			memcpy( parser->pat_section,buf+i,size -i );
			parser->pat_section_cur = size -i;
			parser->pat_section_continuity = continuity_counter;
			return -1;
		}
		else
		{
			memcpy( parser->pat_section,buf+i,parser->pat_section_length );
			parser->pat_section_cur = parser->pat_section_length;
		}
	}
	else
	{
		/* ��������� */
		parser->pat_section_continuity++;
		if( parser->pat_section_continuity == 0x10 )
			parser->pat_section_continuity = 0x00;
		if( parser->pat_section_continuity != continuity_counter
					|| parser->pat_section_length == (uint16_t)-1 )
		{
			parser->pat_section_cur = 0;
			parser->pat_section_length =-1;
			return -1;
		}

		if( parser->pat_section_cur+size-i< parser->pat_section_length )
		{
			memcpy( parser->pat_section+parser->pat_section_cur,buf+i,size -i );
			parser->pat_section_cur += size -i;
			return -1;
		}
		else
		{
			memcpy( parser->pat_section+parser->pat_section_cur,buf+i,parser->pat_section_length-parser->pat_section_cur );
			parser->pat_section_cur = parser->pat_section_length;
		}
	}
	/* ����PAT section */
	i = 0;
	/* skip 5 bytes */
	i += 5;
	
	p_num = 0;
	pid = 0;
	while( i< parser->pat_section_length )
	{
		p_num = parser->pat_section[i];
		p_num = (p_num<< 8) + parser->pat_section[i+1];
		i += 2;

		pid = parser->pat_section[i] & 0x1F;
		pid = (pid<<8) + parser->pat_section[i+1];
		i += 2;
		
		if(p_num != 0)
		{
			parser->pmt_pid = pid;
			break;
		}
	}
	return 0;
}


/* parser pmt */
static int sw_tsparser_on_pmt(tsparser_t* parser,uint8_t* buf, int size,
			uint8_t playload_unit_start_indicator,
 			uint8_t adaptaion_field_length,uint8_t continuity_counter)
{
	uint8_t fill_bytes;
	uint16_t program_info_length,ES_info_length;
	uint8_t stream_type;
	uint16_t pid;
	uint16_t num_video_pid=0,num_audio_pid=0, num_sub_pid=0;
    	int conditional_access = 0; 
	int i=0,j=0;
	memcpy( parser->pmt,buf,188);
	/* ȥ���ĸ��ֽڵ�ͬ��ͷ */
	i=4;
	/* ȥ��adaptation_field */
	i += adaptaion_field_length;
	
	/* ��һ��������������ֽ� */
	if( playload_unit_start_indicator == 1 )
	{
		fill_bytes = buf[i];
		i++;
		i += fill_bytes;

		/* TABLE ID */
		i++;
		
		/* ����section���� */
		parser->pmt_section_length =  buf[i] & 0x0F;
		parser->pmt_section_length = (parser->pmt_section_length<<8) + buf[i+1];
		parser->pmt_section_length -= 4;
		i += 2;
		/* ��鳤���Ƿ�Ϸ� */
		if( parser->pmt_section_length >1024 )
			return -1;
		
		/* ��PMT�������� */
		if( ( size-i ) < parser->pmt_section_length )
		{
				memcpy( parser->pmt_section,buf+i,size -i );
				parser->pmt_section_cur = size -i;
			  parser->pmt_section_continuity = continuity_counter;
			  return -1;
		}
		else
		{
			memcpy( parser->pmt_section,buf+i,parser->pmt_section_length  );
			parser->pmt_section_cur = parser->pmt_section_length ;
		}
	}
	else
	{
		/* ��������� */
		parser->pmt_section_continuity++;
		if(parser-> pmt_section_continuity == 0x10 )
			parser->pmt_section_continuity = 0x00;
		if( parser->pmt_section_continuity != continuity_counter
					|| parser->pmt_section_length == (uint16_t)-1 )
		{
			parser->pmt_section_cur = 0;
			parser->pmt_section_length =-1;
			return -1;
		}

		if( parser->pmt_section_cur+size-i< parser->pmt_section_length )
		{
			memcpy( parser->pmt_section+parser->pmt_section_cur,buf+i,size -i );
			parser->pmt_section_cur += size -i;
			return -1;
		}
		else
		{	
			memcpy( parser->pmt_section+parser->pmt_section_cur,buf+i,parser->pmt_section_length-parser->pmt_section_cur);
			parser->pmt_section_cur = parser->pmt_section_length ;
		}
	}

	/* ����PMT section */
	i = 0;
	/*skip 5 bytes; program number 2 bytes,version number 5 bits */
	i += 5;
	
	/* PCR_PID */
	parser->pcr_pid = parser->pmt_section[i] & 0x1F;
	parser->pcr_pid = (parser->pcr_pid<<8) + parser->pmt_section[i+1];
	i += 2;
	/* program info */
	program_info_length = parser->pmt_section[i] & 0x0F;
	program_info_length = (program_info_length<<8) + parser->pmt_section[i+1];
	i += 2;
	/* ��鳤���Ƿ�Ϸ� */
	if( program_info_length > 1024 )
		return -1;
    //if (conditional_access == 0)
    {
		uint16_t ca_pid=0;
		uint8_t descriptor_tag=0,descriptor_length=0;
        for (j=0; j<program_info_length; )
        {
            descriptor_tag = parser->pmt_section[i+j]; 
            descriptor_length = parser->pmt_section[i+j+1];
            if (descriptor_tag == 0x09 && descriptor_length <= sizeof(parser->globaldesc))
            {
                parser->globaldesclen = descriptor_length; 
                memcpy(parser->globaldesc, parser->pmt_section+i+j+2, descriptor_length);
                conditional_access = 3; 
				parser->ca_system_id = parser->pmt_section[i+j+2];
				parser->ca_system_id = (parser->ca_system_id<<8)+parser->pmt_section[i+j+3];
				ca_pid=parser->pmt_section[i+j+4]&0x1f;
				ca_pid=(ca_pid<<8)+parser->pmt_section[i+j+5];//ECM PID
				if( (parser->ca_system_id==0x5601 || parser->ca_system_id == 0x0406 || parser->ca_system_id == 0x0604) && ca_pid!=parser->ecm_pid)
				{
					parser->ecm_pid=ca_pid;
					parser->ecm_num = 1;
					parser->ecm_pid_changed=true;
				}
            }
            j += 2 + descriptor_length; 
        }
    }
	i += program_info_length;

	while( i <  parser->pmt_section_length )
	{
		/* stream_type */
		stream_type = parser->pmt_section[i];
		i++;

		/* element_PID */
		pid = parser->pmt_section[i]  & 0x1F;
		pid= (pid<<8) + parser->pmt_section[i+1];
		i += 2;
		/* MPEG1 or MPEG2 video */
		if(stream_type==0x01 || stream_type==0x02 || stream_type == 0x10 || stream_type == 0x1B
				|| stream_type==0x42 )
		{
			if( num_video_pid < MAX_AV_PIDS )
			{
				parser->video_pid[num_video_pid] = pid;
				parser->video_type[num_video_pid] = stream_type;
				num_video_pid++;
				parser->videopid = pid;	
				if( stream_type==0x01 )
					printf( "tsparser_on_pmt: MPEG1 11172-2 video-pid=0x%x\n", pid );
				else if(stream_type==0x02 )
					printf( "tsparser_on_pmt: MPEG2 13818-2 video-pid=0x%x\n", pid );
				else if(stream_type == 0x10 )
					printf( "tsparser_on_pmt: MPEG4 simple profile video-pid=0x%x\n", pid );
				else if( stream_type == 0x1B )
					printf( "tsparser_on_pmt: MPEG4 AVC/H.264 video-pid=0x%x\n", pid );
				else if( stream_type == 0x42 )
					printf( "tsparser_on_pmt: AVS video-pid=0x%x\n", pid);
			}
		}
		// MPEG1 or MPEG2 audio
		else if(stream_type==0x03 || stream_type==0x04 || stream_type == 0x0F || stream_type== 0x11|| stream_type== 0x81|| stream_type== 0x8a)
		{
			if( num_audio_pid< MAX_AV_PIDS )
			{
				parser->audio_pid[num_audio_pid] = pid;
				parser->audio_type[num_audio_pid] = stream_type;
				num_audio_pid ++;			
				if( stream_type==0x03 )
					printf( "tsparser_on_pmt:MPEG1 11172-3 audio-pid=0x%x\n", pid );
				else if(  stream_type==0x04)
					printf( "tsparser_on_pmt: MPEG2 13818-3 audio-pid=0x%x\n", pid );
				else if(stream_type == 0x0F)
					printf( "tsparser_on_pmt: 13818-7 audio-pid=0x%x\n", pid );
				else if(stream_type == 0x11 )
					printf( "tsparser_on_pmt: 14496-3 audio with LATM syntax audio-pid=0x%x\n", pid );
				else if( stream_type == 0x81 )
					printf( "tsparser_on_pmt:Dolby Digital AC3 audio pid=0x%x \n",pid);
				else if( stream_type == 0x82 )
					printf( "tsparser_on_pmt:Digital Digital Surround sound audio-pid=0x%x \n",pid);
                else if(stream_type == 0x8a )
               		printf( "tsparser_on_pmt: DTS pid=0x%x\n", pid );
			}
		}
		else
		{
			printf( "tsparser_on_pmt: stream_type = 0x%x pid=0x%x\n",stream_type,pid );
		}
		/* ES_info_length */
		ES_info_length = parser->pmt_section[i] & 0x0F;
		ES_info_length = (ES_info_length<<8) + parser->pmt_section[i+1];
		i += 2;
		/*i += ES_info_length;*/
		for (j = 0; j < ES_info_length; )
		{
			uint8_t descriptor_tag=0,descriptor_length=0;
			descriptor_tag = parser->pmt_section[i + j]; 
			descriptor_length = parser->pmt_section[i + j + 1]; 
			if (descriptor_tag == 0x9)
			{

				if (pid == parser->audiopid && descriptor_length<=sizeof(parser->audiodesc))
				{
					parser->audiodesclen = descriptor_length; 
					memcpy(parser->audiodesc, parser->pmt_section+i+j+2, descriptor_length);
				}
				else if (pid == parser->videopid && descriptor_length<=sizeof(parser->videodesc))
				{
					parser->videodesclen = descriptor_length; 
					memcpy(parser->videodesc, parser->pmt_section+i+j+2, descriptor_length); 
				}
			}
			else if (stream_type == 0x82 &&  descriptor_tag == 0x0a)
			{
				parser->subtitles[num_sub_pid].pid = pid; 
				memcpy(parser->subtitles[num_sub_pid].language, parser->pmt_section+i+j+2, 3); 
				parser->subtitles[num_sub_pid].language[3] = '\0';
				parser->subtitles[num_sub_pid].com_page_id = 1; 
				parser->subtitles[num_sub_pid].anc_page_id = 1; 
				num_sub_pid++; 
			}
			else if (stream_type == 0x06 && descriptor_tag == 0x59)
			{
				parser->subtitles[num_sub_pid].pid = pid; 
				memcpy(parser->subtitles[num_sub_pid].language, parser->pmt_section+i+j+2, 3); 
				parser->subtitles[num_sub_pid].language[3] = '\0';
				parser->subtitles[num_sub_pid].com_page_id = parser->pmt_section[i+j+6]; 
				parser->subtitles[num_sub_pid].com_page_id =
					(parser->subtitles[num_sub_pid].com_page_id << 8) + parser->pmt_section[i + j + 7]; 
				parser->subtitles[num_sub_pid].anc_page_id = parser->pmt_section[i + j + 8]; 
				parser->subtitles[num_sub_pid].anc_page_id =
					(parser->subtitles[num_sub_pid].anc_page_id << 8) + parser->pmt_section[i + j + 9]; 
				num_sub_pid++; 
			}

			j += (2 + descriptor_length); 
		}


		i += ES_info_length; 
	}

	parser->video_num = num_video_pid;
	parser->audio_num = num_audio_pid;
	parser->sub_num = num_sub_pid;
	return 0;
}
