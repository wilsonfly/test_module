#include <stdint.h>

#include "bcmindexer.h"
#include "bcmindexerpriv.h"
#include "mpeg2types.h"
#include "avstypes.h"
#include "bvlc.h"
#include <string.h>
#include <stdlib.h>
#ifdef LINUX
#include <sys/time.h>
#include <unistd.h>
#elif defined __vxworks
#include <time.h>
#elif defined _WIN32_WCE
#include <Windows.h>
#include <mmsystem.h>
#endif

#if BCHP_CHIP == 7320 || BCHP_CHIP == 7315 || BCHP_CHIP == 7110 || BCHP_CHIP == 7115
/* No RAVE */
#else
#ifndef B_IS_SOFTINDEXER
/* #define B_HAS_RAVE 1 */
#endif
#endif

/* If we offset two words into an SCT6 entry, it looks just like an SCT4 entry,
ignoring the extra payload bytes */
#define CONVERT_TO_SCT4(P_SCT6_ENTRY) \
    ((BSCT_Entry*)((char*)P_SCT6_ENTRY+(sizeof(BSCT_SixWord_Entry)-sizeof(BSCT_Entry))))

/* enable this to add start code validation
   debug messages at the compile time */
/* #define VALIDATE_SC_NAV */
#ifdef VALIDATE_SC_NAV
#define VALIDATE_MPEG_SC(p_curBfr,sc) \
        if(((p_curBfr->startCodeBytes&0xff) > 0xbc)||!(sc==SC_ANY_NON_PTS||sc==SC_PTS||sc==SC_PES||sc==SC_SEQUENCE \
            ||sc==SC_PICTURE||sc==SC_FIRST_SLICE||sc==SC_EXTENSION||sc==SC_SEQ_END||sc==SC_GOP||sc==SC_PES_END \
            ||sc==PC_I_FRAME||sc==PC_P_FRAME||sc==PC_B_FRAME||sc==PC_ANY_FRAME))\
        {\
          BDBG_WRN(("Invalid SCT Entry: %02x pkt offset 0x%02lx%08lx,sc offset 0x%02x",sc, \
          (p_curBfr->recordByteCountHi>>24)&0xff,p_curBfr->recordByteCount,p_curBfr->startCodeBytes & 0xff));\
        }

#define VALIDATE_AVC_SC(p_curSct4,sc)                   \
        if((p_curSct4->startCodeBytes&0xff)>0xbc)       \
        {                                               \
          BDBG_WRN(("Invalid SCT Entry: %02x pkt offset 0x%02lx%08lx,offset 0x%02x", sc, \
          (p_curSct4->recordByteCountHi>>24) & 0xFF, p_curSct4->recordByteCount,p_curSct4->startCodeBytes & 0xff));\
        }

#define VALIDATE_AVS_SC(p_curBfr,sc) \
        if(((p_curBfr->startCodeBytes&0xff) > 0xbc)||!(sc==SC_AVS_ANY_NON_PTS||sc==SC_AVS_PTS||sc==SC_AVS_PES||sc==SC_AVS_SEQUENCE \
            ||sc==SC_AVS_PICTURE_I ||sc==SC_AVS_PICTURE_PB ||sc==SC_AVS_EXTENSION||sc==SC_AVS_SEQ_END||sc==SC_AVS_PES_END \
            ||sc==PC_AVS_P_FRAME||sc==PC_AVS_B_FRAME || sc==SC_AVS_FIRST_SLICE  ))\
        {\
          BDBG_WRN(("Invalid AVS SCT Entry: %02x pkt offset 0x%02lx%08lx,sc offset 0x%02x",sc, \
          (p_curBfr->recordByteCountHi>>24)&0xff,p_curBfr->recordByteCount,p_curBfr->startCodeBytes & 0xff));\
        }

#define VALIDATE_MPEG_NAV(frameType)\
        if(!(frameType == eSCTypeIFrame || frameType == eSCTypePFrame ||\
           frameType == eSCTypeBFrame || eSCTypeBFrame == eSCTypeRPFrame))\
        {\
        }
#else

#define VALIDATE_MPEG_SC(sc_offset,sc)
#define VALIDATE_AVC_SC(sc_offset,sc)
#define VALIDATE_AVS_SC(p_curBfr,sc)
#define VALIDATE_MPEG_NAV(frameType)

#endif


/*---------------------------------------------------------------
- PRIVATE FUNCTIONS
---------------------------------------------------------------*/
static unsigned long BNAV_Indexer_returnPts(const BSCT_Entry *p_sct );
static int BNAV_Indexer_completeFrame( BNAV_Indexer_Handle handle );
static void BNAV_Indexer_StampEntry(BNAV_Indexer_Handle handle, BNAV_Entry *entry);
static unsigned long BNAV_Indexer_subtractByteCounts( unsigned long largerNum, unsigned long smallerNum );
static unsigned long BNAV_Indexer_getScByteOffsetLo( BNAV_Indexer_Handle handle, const BSCT_Entry *p_entry );
static unsigned long BNAV_Indexer_getScByteOffsetHi( BNAV_Indexer_Handle handle, const BSCT_Entry *p_entry );
static long BNAV_Indexer_FeedAVC(BNAV_Indexer_Handle handle, const void *p_bfr, long numEntries);
static long BNAV_Indexer_FeedAVS(BNAV_Indexer_Handle handle, void *p_bfr, long numEntries);
static int BNAV_Indexer_Flush(BNAV_Indexer_Handle handle);

/**
* currentTimestamp returns the # of milliseconds from some fixed point in the past.
* I currently have a LINUX version. The generic version is only 1 second accurate,
* which might be sufficient if the requirement is to make +/- 30 second jumps.
*
* Because multiple entries are read from the driver at once, we might want to interpolate
* the values across a single feed.
**/
static unsigned int currentTimestamp(void) {
#if defined LINUX
    struct timeval tv;
    if (gettimeofday(&tv, NULL)) {
        return 0;
    }
    else {
        return tv.tv_sec*1000+(tv.tv_usec/1000);
    }
#elif defined __vxworks
    return time(NULL) * 1000;
#elif defined _WIN32_WCE
    return GetTickCount();
#endif
}

void BNAV_Indexer_GetDefaultSettings(BNAV_Indexer_Settings *settings)
{
    memset(settings, 0, sizeof(*settings));
    settings->simulatedFrameRate = 0;
    settings->sctVersion = BSCT_Version40bitOffset;
    settings->videoFormat = BNAV_Indexer_VideoFormat_MPEG2;
    settings->navVersion = BNAV_VersionLatest;
    settings->maxFrameSize = 5 * 1024 * 1024; /* We've seen 500K HD I frames. This is 10x larger. */
	settings->append.pts = -1;
}

/******************************************************************************
* INPUTS:   cb = pointer to a function that stores table entries (same format as fwrite)
*           fp = general pointer that is passed in as param 3 into cb function
*           pid = pid of the transport stream used for table generation
* OUTPUTS:  None.
* RETURNS:  pointer to sBcmIndexer structure
* FUNCTION: This function allocates and initializes an indexer structure.
******************************************************************************/
int BNAV_Indexer_Open(BNAV_Indexer_Handle *handle, const BNAV_Indexer_Settings *settings)
{
    *handle = (BNAV_Indexer_Handle)malloc( sizeof( struct BNAV_Indexer_HandleImpl) );
    if (BNAV_Indexer_Reset(*handle, settings)) {
        free(*handle);
        return -1;
    }
    return 0;
}

int BNAV_Indexer_Reset(BNAV_Indexer_Handle handle, const BNAV_Indexer_Settings *settings)
{
    int result = 0;

    if (!settings->writeCallback ||
        !settings->filePointer)
    {
        /*printf("Missing required settings\n");*/
        return -1;
    }

    if (settings->videoFormat == BNAV_Indexer_VideoFormat_AVC &&
        settings->navVersion != BNAV_Version_AVC)
    {
        /*printf("You need to select an AVC BNAV_Version for bcmindexer.\n");*/
        return -1;
    }
    else if (settings->videoFormat != BNAV_Indexer_VideoFormat_AVC &&
        settings->navVersion == BNAV_Version_AVC)
    {
        /*printf("You need to select an MPEG2 BNAV_Version for bcmindexer.\n");*/
        return -1;
    }
    else if (settings->videoFormat != BNAV_Indexer_VideoFormat_AVS &&
        settings->navVersion == BNAV_Version_AVS)
    {
        /*printf("You need to select an MPEG2 BNAV_Version for bcmindexer.\n");*/
        return -1;
    }
    else if (settings->navVersion >= BNAV_VersionUnknown) {
        /*printf("Unsupported BNAV_Version\n");*/
        return -1;
    }

    memset(handle, 0, sizeof(*handle));

    handle->settings = *settings;
	handle->last_pts = -1;

    if (!settings->simulatedFrameRate && !settings->download) {
    /*if (!settings->simulatedFrameRate) {*/
        /* real, not simulated */
        handle->lasttime = handle->starttime = currentTimestamp();
    }
	else if (!settings->simulatedFrameRate && settings->download) {
        /* real, not simulated */
        handle->starttime = handle->settings.append.timestamp;
		handle->last_pts = handle->settings.append.pts;
    }

    BNAV_set_frameType(&(handle->curEntry), eSCTypeUnknown);
    BNAV_set_frameType(&(handle->avcEntry), eSCTypeUnknown);

    BNAV_set_frameOffsetLo(&(handle->curEntry), handle->settings.append.offsetLo);
    BNAV_set_frameOffsetHi(&(handle->curEntry), handle->settings.append.offsetHi);
    BNAV_set_frameOffsetLo(&(handle->avcEntry), handle->settings.append.offsetLo);
    BNAV_set_frameOffsetHi(&(handle->avcEntry), handle->settings.append.offsetHi);

    handle->isHits = 1;  /* Assume HITS until we're proven wrong */
    handle->avc.current_sps = handle->avc.current_pps = -1;

    return result;
}

/******************************************************************************
* INPUTS:   handle = pointer to a previously allocated sBcmIndexer structure
* OUTPUTS:  None.
* RETURNS:  None.
* FUNCTION: This function frees any memory used by an indexer structure.
******************************************************************************/
void BNAV_Indexer_Close(BNAV_Indexer_Handle handle)
{
    free((void *)handle);
}

static void BNAV_Indexer_P_AddAppend(BNAV_Indexer_Handle handle, unsigned long *offsetHi, unsigned long *offset)
{
    if (handle->settings.append.offsetHi || handle->settings.append.offsetLo) {
        off_t value = ((off_t)*offsetHi << 32) + *offset;

        /* add the append amount */
        value += ((off_t)handle->settings.append.offsetHi << 32) + handle->settings.append.offsetLo;

        *offset = value & 0xFFFFFFFF;
        *offsetHi = value >> 32;
    }
}

long BNAV_Indexer_Feed(BNAV_Indexer_Handle handle, void *p_bfr, long numEntries)
{
    long i;
    const BSCT_Entry *p_curBfr;
    int inc;
    BNAV_Entry *navEntry = &handle->curEntry;

    if (handle->settings.videoFormat == BNAV_Indexer_VideoFormat_AVC) {
        return BNAV_Indexer_FeedAVC(handle, p_bfr, numEntries);
    }
    else if(handle->settings.videoFormat == BNAV_Indexer_VideoFormat_AVS){
        return BNAV_Indexer_FeedAVS(handle, p_bfr, numEntries);
    }

    switch (handle->settings.sctVersion) {
    case BSCT_Version32bitOffset:
        return -1;
    case BSCT_Version40bitOffset:
        /* convert 32 bit byte count to 40 bits for venom2 */
        p_curBfr = p_bfr;
        inc = sizeof(BSCT_Entry);
        break;
    case BSCT_Version6wordEntry:
        /* Offseting into BSCT_SixWordEntry gives the same
        as BSCT_Entry. We don't care about the first two words. */
        p_curBfr = CONVERT_TO_SCT4(p_bfr);
        inc = sizeof(BSCT_SixWord_Entry);
        break;
    default:
        return -1;
    }

    for(i=0; i<numEntries; ++i)
    {
        int sc = returnStartCode(p_curBfr->startCodeBytes); /* parse once */
        unsigned long offset = BNAV_Indexer_getScByteOffsetLo(handle, p_curBfr);
        unsigned long offsetHi = BNAV_Indexer_getScByteOffsetHi(handle, p_curBfr);

        BNAV_Indexer_P_AddAppend(handle, &offsetHi, &offset);

        /* detect invalid start code and offsets */
        VALIDATE_MPEG_SC(p_curBfr,sc);

        /*BDBG_MSG(("SCT Entry: %02x 0x%02lx%08lx", sc, offsetHi, offset));*/
        if (handle->seqHdrFlag) {
            if (sc != SC_PES && sc != SC_PTS && sc != SC_EXTENSION) {
                handle->seqHdrFlag = 0;
                handle->seqHdrSize = BNAV_Indexer_subtractByteCounts(offset, handle->seqHdrStartOffset);
            }
        }

        switch(sc)
        {
        case SC_FIRST_SLICE:
            /* I-slice check here */
            if (returnIntraSliceBit(p_curBfr->startCodeBytes) && handle->isHits) {
                BNAV_set_frameType(navEntry, eSCTypeRPFrame);
                handle->isISlice = 1;
            }
            break;

        case SC_PES:
            break;

        case SC_PTS:
            handle->next_pts = BNAV_Indexer_returnPts(p_curBfr);
            break;

        case SC_SEQUENCE:
            handle->seqHdrStartOffset = offset;
            handle->seqHdrFlag = 1; /* set on next qualifying sct */

            /* complete any pending frame */
            handle->picEnd = handle->seqHdrStartOffset;
            BNAV_Indexer_completeFrame( handle );
            break;

        case SC_SEQ_END:   /* TODO: Change me to any non-slice */
            /* complete any pending frame */
            handle->picEnd = offset;
            BNAV_Indexer_completeFrame( handle );
            break;

        case SC_PICTURE:
            /* complete any pending frame */
            handle->picEnd = offset;
            BNAV_Indexer_completeFrame( handle );

            /* start a new frame */
            handle->picStart = offset;

            BNAV_set_frameOffsetLo(navEntry, offset);
            BNAV_set_frameOffsetHi(navEntry, offsetHi);

            switch(returnPictureCode(p_curBfr->startCodeBytes))
            {
            case PC_I_FRAME:
                handle->isISlice = 1;
                handle->isHits = 0;
                BNAV_set_frameType(navEntry, eSCTypeIFrame);
                break;
            case PC_P_FRAME:
                handle->prev_I_rfo = 0;
                /* First P after first I allows open GOP B's to be saved */
                if (handle->hitFirstISlice)
                    handle->allowOpenGopBs = 1;
                BNAV_set_frameType(navEntry, eSCTypePFrame);
                break;
            case PC_B_FRAME:
                BNAV_set_frameType(navEntry, eSCTypeBFrame);
                break;
            }

            /* make sequence header offset relative to current frame rather than */
            /* relative to reference frame to allow removal of b-frames */
            BNAV_set_seqHdrSize(navEntry, (unsigned short)handle->seqHdrSize);
            BNAV_set_seqHdrStartOffset(navEntry,
                        BNAV_Indexer_subtractByteCounts(handle->picStart, handle->seqHdrStartOffset));

            /* Sets the refFrameOffset after adding the prev_I_rfo to the rfo.
            prev_I_rfo will be non-zero ONLY for open gop B's, which are B's that come
            after an I but before a P. */
            BNAV_set_refFrameOffset(navEntry, handle->rfo + handle->prev_I_rfo);

            if (handle->settings.navVersion >= BNAV_VersionOpenGopBs) {
                if (returnPictureCode(p_curBfr->startCodeBytes) == PC_I_FRAME)
                    handle->prev_I_rfo = handle->rfo;
            }

            if (handle->hitFirstISlice)
                handle->rfo++;

            BNAV_set_framePts(navEntry, handle->next_pts);
            break;
        default:
            break;

        }

        p_curBfr = (const BSCT_Entry*)((char*)p_curBfr + inc);
    }

    return i;
}

long BNAV_Indexer_FeedReverse(BNAV_Indexer_Handle handle, const BSCT_Entry *p_bfr, long numEntries)
{
    int i,j;

    if (handle->settings.sctVersion == BSCT_Version32bitOffset) {
        return -1; 
    }

    for(i=numEntries-1; i>=0; --i)
    {
        const BSCT_Entry *curSct = &p_bfr[i];
        BNAV_Entry *navEntry;

        int sc = returnStartCode(curSct->startCodeBytes); /* parse once */

        /*BDBG_MSG(("SCT Entry: %02x %d %08lx %08lx",*/
            /*sc, returnPictureCode(curSct->startCodeBytes), curSct->recordByteCountHi, curSct->recordByteCount));*/

        /* Set navEntry to the current BNAV_Entry */
        if (handle->reverse.total_entries)
            navEntry = &handle->reverse.entry[handle->reverse.total_entries-1];
        else
            navEntry = NULL;

        switch(sc)
        {
#if 0
/* No HITS support for OTF PVR. Is this a requirement? */
        case SC_FIRST_SLICE:
            /* I-slice check here */
            if (returnIntraSliceBit(curSct->startCodeBytes) && handle->isHits) {
                BNAV_set_frameType(navEntry, eSCTypeRPFrame);
                handle->isISlice = 1;
            }
            break;
        case SC_PES:
        case SC_SEQ_END:
            break;
#endif
        case SC_PTS:
            {
            unsigned long pts = BNAV_Indexer_returnPts(curSct);

            /* Set PTS for all entries that don't have one. */
            for (j=handle->reverse.total_entries-1;j>=0;j--) {
                BNAV_Entry *entry = &handle->reverse.entry[j];

                if (BNAV_get_framePts(entry))
                    break;
                BNAV_set_framePts(entry, pts);
            }
            }
            break;

        case SC_SEQUENCE:
            handle->seqHdrStartOffset = BNAV_Indexer_getScByteOffsetLo( handle, curSct );
            handle->seqHdrSize = handle->picEnd - handle->seqHdrStartOffset;

            /* Go through every entry and set seqhdr offset if not set already */
            for (j=handle->reverse.total_entries-1;j>=0;j--) {
                BNAV_Entry *entry = &handle->reverse.entry[j];

                if (BNAV_get_seqHdrStartOffset(entry))
                    break;

                BNAV_set_seqHdrSize(entry, (unsigned short)handle->seqHdrSize);
                BNAV_set_seqHdrStartOffset(entry,
                    BNAV_Indexer_subtractByteCounts(
                        BNAV_get_frameOffsetLo(entry), handle->seqHdrStartOffset));
            }

            BNAV_Indexer_Flush(handle);
            break;

        case SC_PICTURE:
            {
            unsigned frameSize, pc;
            if (!handle->picEnd) {
                /* If we don't know where this frame ends, we have to skip it. */
                break;
            }

            /* Select a new BNAV_Entry */
            if (handle->reverse.total_entries == MAX_GOP_SIZE) {
                /*printf("MAX_GOP_SIZE exceeded. Bad data resulting.\n");*/
                return -1;
            }
            navEntry = &handle->reverse.entry[handle->reverse.total_entries++];

            handle->picStart = BNAV_Indexer_getScByteOffsetLo( handle, curSct );
            frameSize = BNAV_Indexer_subtractByteCounts(handle->picEnd, handle->picStart);
            if (frameSize > handle->settings.maxFrameSize) {
                /*printf("Giant frame (%d bytes) detected and rejected: %d\n", frameSize, handle->totalEntriesWritten);*/
                /* Throw away this entry */
                handle->reverse.total_entries--;
                continue;
            }

            BNAV_set_frameOffsetLo(navEntry, handle->picStart);
            BNAV_set_frameOffsetHi(navEntry, 0); /* BNAV_Indexer_getScByteOffsetHi(handle, curSct)); */

            BNAV_set_frameSize(navEntry, frameSize);
            BNAV_Indexer_StampEntry(handle, navEntry);

            /* Set this to 0 so that we'll set it when we hit a seqhdr */
            BNAV_set_seqHdrStartOffset(navEntry, 0);
            BNAV_set_refFrameOffset(navEntry, 0);

            pc = returnPictureCode(curSct->startCodeBytes);

            switch (pc)
            {
            case PC_I_FRAME:
                BNAV_set_frameType(navEntry, eSCTypeIFrame);
                break;
            case PC_P_FRAME:
                BNAV_set_frameType(navEntry, eSCTypePFrame);
                break;
            case PC_B_FRAME:
                BNAV_set_frameType(navEntry, eSCTypeBFrame);
                break;
            }


            /* When we hit an I frame, we can set the refoffset for the GOP */
            if (pc == PC_I_FRAME) {
                int refoff = 0; /* Offset from I frame */
                int newgop = 1; /* Set at every I frame */
                int foundFirstP = 0; /* This is the marker for open GOP B's */
                for (j=handle->reverse.total_entries-1;j>=0;j--) {
                    BNAV_Entry *entry = &handle->reverse.entry[j];
                    int done = 0;

                    switch (BNAV_get_frameType(entry)) {
                    case eSCTypeBFrame:
                        /* If this is an open GOP B for the previous frame, skip it. */
                        if (newgop && !foundFirstP) {
                            refoff++;
                            continue;
                        }
                        break;
                    case eSCTypePFrame:
                        /* If we have a new GOP but we've already found a P, then we're
                        done setting the open GOP B's for the current reference frame.
                        We're done. */
                        /* coverity[dead_error_condition] */
                        if (newgop && foundFirstP) {
                            /* coverity[dead_error_begin] */
                            done = 1;
                            break;
                        }

                        /* Once we find a P, we're into the middle of the GOP so don't
                        skip open GOP B's. */
                        newgop = 0;
                        foundFirstP = 1;
                        break;
                    case eSCTypeIFrame:
                        newgop = 1;
                        break;
                    default:
                        /*printf("Only GOP-based streams supported.\n");*/
                        return -1;
                    }

                    /* coverity[dead_error_condition] */
                    if (done)
                        /* coverity[dead_error_line] */
                        break;

                    BNAV_set_refFrameOffset(entry, refoff);
                    refoff++;
                }

                /* And now we can flush */
                BNAV_Indexer_Flush(handle);
            }
            }
            break;

        default:
            break;
        }

        if (sc != SC_PES && sc != SC_PTS && sc != SC_EXTENSION && sc != SC_FIRST_SLICE)
        {
            handle->picEnd = BNAV_Indexer_getScByteOffsetLo( handle, curSct);
            /*BDBG_MSG(("Set picEnd %lx, %d", handle->picEnd,sc));*/
        }
    }

    return numEntries;
}

#define BNAV_LARGE_TIME_GAP 3000 /* 3000 msec = 3 seconds */

/**
Set timestamp and vchip stamps for an entry based on current bcmindexer and system state.
**/
static void BNAV_Indexer_StampEntry(BNAV_Indexer_Handle handle, BNAV_Entry *entry)
{
	if (!handle->settings.simulatedFrameRate && !handle->settings.download){
    /*if (!handle->settings.simulatedFrameRate) {*/
        unsigned currenttime = currentTimestamp();

        /* Any large jump in timestamps can only be caused by the source disappearing because of loss of signal, etc.
        The timestamps should skip over this gap. */
        if (currenttime - handle->lasttime > BNAV_LARGE_TIME_GAP) {
            handle->starttime += (currenttime - handle->lasttime) - 30; /* turn any large gap into a 30 millisecond gap by adjusting the starttime */
        }
        BNAV_set_timestamp(entry, currenttime - handle->starttime + handle->settings.append.timestamp);
        handle->lasttime = currenttime;
    }
	else if (!handle->settings.simulatedFrameRate && handle->settings.download) {
		uint64_t pts;

		if((int)handle->last_pts == -1)
		{
			handle->last_pts = BNAV_get_framePts(entry);
			BNAV_set_timestamp(entry, handle->starttime + handle->lasttime);
		}
		else
		{
			pts = BNAV_get_framePts(entry);
			if( pts >= handle->last_pts )
				pts -= handle->last_pts;
			else
				pts = 0;

			if( pts > 0 )
				handle->lasttime = pts/45;
				
			handle->lasttime += handle->starttime;
			BNAV_set_timestamp(entry, handle->lasttime);
			/*handle->last_pts = BNAV_get_framePts(entry);*/
		}
	}

    else {
        /* calc a timestamp based on a simulated frame rate. actual system time is irrevelevant. */
        BNAV_set_timestamp(entry, handle->starttime++ * (1000/handle->settings.simulatedFrameRate));
    }
    BNAV_set_packed_vchip(entry, handle->vchip);
    BNAV_set_version(entry, handle->settings.navVersion);
}

/* For FeedReverse only. Write out BNAV_Entry's which have a seqhdr and refoffset. */
static int BNAV_Indexer_Flush(BNAV_Indexer_Handle handle)
{
    int i;
    /*printf(("flush total %d\n", handle->reverse.total_entries));*/
    for (i=0;i<handle->reverse.total_entries; i++) {
        BNAV_Entry *entry = &handle->reverse.entry[i];

        /*printf("  %ld, %d, %d\n",*/
            /*BNAV_get_seqHdrStartOffset(entry),*/
            /*BNAV_get_refFrameOffset(entry),*/
            /*BNAV_get_frameType(entry)*/
            /*);*/

        if (BNAV_get_seqHdrStartOffset(entry) && BNAV_get_refFrameOffset(entry))
        {
           /* write using callback */
            int numBytes = (*handle->settings.writeCallback)(entry, 1,
                sizeof( BNAV_Entry ), handle->settings.filePointer);
            if (numBytes != sizeof( BNAV_Entry )) {
                /*printf("Unable to write index entry.\n");*/
                return -1;
            }
            handle->totalEntriesWritten++;
            handle->lastEntryWritten = *entry;
        }
        else {
            /* When we hit the first entry we can't send, break out */
            break;
        }
    }

    /* Shift forward the entry array based on how many were sent */
    handle->reverse.total_entries -= i;
    memmove(handle->reverse.entry, &handle->reverse.entry[i],
        handle->reverse.total_entries * sizeof(BNAV_Entry));

    return 0;
}

static int BNAV_P_CheckEntry(BNAV_Indexer_Handle handle, BNAV_Entry *navEntry)
{
    unsigned long frameSize = BNAV_get_frameSize(navEntry);
    int frameType = BNAV_get_frameType(navEntry);

    if (frameSize > handle->settings.maxFrameSize) {
        /*BDBG_WRN(("Giant frame (%ld bytes) detected and rejected: %d", frameSize, handle->totalEntriesWritten));*/
        /* discard everything until next I frame */
        handle->hitFirstISlice = 0;
        handle->rfo = 0;
        handle->isISlice = 0;
        handle->prev_I_rfo = 0;
        handle->allowOpenGopBs = 0; /* including open GOP B's after that first I */
        goto fail;
    }
    else if (frameSize == 0) {
        /*printf("Invalid frame size 0 rejected, probably corrupt index at %d\n", handle->totalEntriesWritten);*/
        goto fail;
    }
    else if (BNAV_get_seqHdrSize(navEntry) == 0) {
        /*printf("Discarding picture with no sequence header\n");*/
        goto fail;
    }

    /* Skip dangling open GOP B's */
    if (frameType == eSCTypeBFrame && handle->hitFirstISlice && !handle->allowOpenGopBs &&
        handle->settings.navVersion != BNAV_Version_AVC &&
        handle->settings.navVersion != BNAV_Version_VC1_PES &&
        handle->settings.navVersion != BNAV_Version_AVS)
    {
        /*printf("Discarding dangling open GOP B: %d\n", handle->totalEntriesWritten);*/
        handle->rfo--;
        goto fail;
    }

    /* success */
    return 0;

fail:
    BNAV_set_frameType(navEntry, eSCTypeUnknown);
    return -1;
}


/* Write a MPEG2 or AVC entry back to the write callback. */
int BNAV_Indexer_completeFrameAux(BNAV_Indexer_Handle handle, void *data, int size)
{
    BNAV_Entry *navEntry = (BNAV_Entry *)data;
    unsigned long frameSize = BNAV_Indexer_subtractByteCounts( handle->picEnd, BNAV_get_frameOffsetLo(navEntry));
    int frameType = BNAV_get_frameType(navEntry);

    BNAV_set_frameSize(navEntry,frameSize);

    /* perform sanity check before writing */
    if (BNAV_P_CheckEntry(handle, navEntry))
    {
        return -1;
    }

    if (handle->isISlice)
        handle->hitFirstISlice = 1;

    if (frameType != eSCTypeUnknown && handle->hitFirstISlice)
    {
        int numBytes;
        BNAV_Indexer_StampEntry(handle, navEntry);

        /*printf("Output: %08lx %08lx %08lx %08lx %08lx %08lx (%s)\n", navEntry->words[0], navEntry->words[1],*/
            /*navEntry->words[2], navEntry->words[3], navEntry->words[4], navEntry->words[5],*/
            /*BNAV_frameTypeStr[frameType]);*/
        /* write using callback */
        numBytes = (*handle->settings.writeCallback)(navEntry, 1, size, handle->settings.filePointer);
        if (numBytes != size) {
            /*printf("Unable to write index entry.\n");*/
            return -1;
        }
        handle->totalEntriesWritten++;
        handle->lastEntryWritten = *navEntry;
    }
    /**
    * Clear the frametype, but don't clear the rest of the information. If
    * in the future the rest of the information must be cleared, watchout so that
    * BNAV_Indexer_GetPosition isn't broken.
    **/
    BNAV_set_frameType(navEntry, eSCTypeUnknown);

    if(handle->isISlice)
    {
        handle->rfo = 1;
        handle->isISlice = 0;
    }
    handle->picEnd = 0;

    return 0;
}

/* Write completed MPEG2 entry to write callback. */
static int BNAV_Indexer_completeFrame(BNAV_Indexer_Handle handle)
{
    return BNAV_Indexer_completeFrameAux(handle, &handle->curEntry, sizeof(handle->curEntry));
}
/* Write completed AVC entry to write callback. */
static int BNAV_Indexer_completeAVCFrame(BNAV_Indexer_Handle handle)
{
    BNAV_AVC_Entry *avcEntry = &handle->avcEntry;

    /* We're going to change the definition of P and B frame for AVC. For MPEG2, a B picture has two
    properties: it uses bidirectional prediction (forward and backward in display order, always backward in decode order)
    and it is not predicted against. The player only uses the second property. It can drop a B frame.
    For AVC, a B picture is has the first property but not the second. At this point, it's unclear if the player
    can use the B directional property for any trick mode (especially if not stored at a slice level).
    Therefore, for the NAV table AVC indexes, the definition of "B frame" will be "non-I frame which is not
    a referenced picture." This means B frames will have the second property - they are discardable. */
    if (BNAV_get_frameType(avcEntry) == eSCTypeBFrame) {
        if (handle->avc.is_reference_picture) {
            /*printf("We have a reference B frame\n");*/
            BNAV_set_frameType(avcEntry, eSCTypePFrame);
        }
    }
    else if (BNAV_get_frameType(avcEntry) == eSCTypePFrame) {
        if (!handle->avc.is_reference_picture) {
            /*printf("We have a non-reference P frame\n");*/
            BNAV_set_frameType(avcEntry, eSCTypeBFrame);
        }
    }

    return BNAV_Indexer_completeFrameAux(handle, &handle->avcEntry, sizeof(handle->avcEntry));
}

/*+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
+ INPUTS:   p_sct = pointer to sct entry
+ OUTPUTS:  None.
+ RETURNS:  pts value (bits [32:1]
+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/
unsigned long BNAV_Indexer_returnPts(const BSCT_Entry *p_sct )
{
#if B_HAS_RAVE
    return p_sct->recordByteCountHi;
#else
    unsigned long pts;
    /* Calculate PTS[32:1] */
    pts = p_sct->startCodeBytes & 0x1;
    pts = (pts << 31) + (p_sct->recordByteCount >> 1);
    return pts;
#endif
}

/******************************************************************************
* INPUTS:   p_entry = pointer to a start code entry
* OUTPUTS:  None.
* RETURNS:  Lower 32 bits of the start code byte offset.
* FUNCTION: This function returns the lower 32 bits of of the number obtained
*           by adding the byte offset of the packet to the offset within the
*           packet of the start code.
******************************************************************************/
unsigned long BNAV_Indexer_getScByteOffsetLo(BNAV_Indexer_Handle handle, const BSCT_Entry *p_entry)
{
    unsigned long byteOffset;

    byteOffset = p_entry->recordByteCount + (p_entry->startCodeBytes & 0xff);
    if (handle->settings.transportTimestampEnabled)
        byteOffset += 4;

    return byteOffset;
}

/******************************************************************************
* INPUTS:   p_entry = pointer to a start code entry
* OUTPUTS:  None.
* RETURNS:  most significant 8 bites of the 40 bit offset, shifted into lower 8 bits
* FUNCTION: This function takes into account the start code offset and possible timestamp and increments the Hi once
*
******************************************************************************/
unsigned long BNAV_Indexer_getScByteOffsetHi(BNAV_Indexer_Handle handle, const BSCT_Entry *p_entry )
{
    unsigned long byteOffset;

    /* Offset into transport packet may cause 32 bit overflow. */
    byteOffset = p_entry->recordByteCount + (p_entry->startCodeBytes & 0xff);
    if (handle->settings.transportTimestampEnabled)
        byteOffset += 4;
    if (byteOffset < p_entry->recordByteCount)
    {
        return (p_entry->recordByteCountHi>>24) + 1;
    }
    else
    {
        return p_entry->recordByteCountHi>>24;
    }
}

/******************************************************************************
* INPUTS:   largerNum - Number to subtract from.
*           smallerNum - Number to be subtracted.
* OUTPUTS:  None.
* RETURNS:  Difference between 2 numbers.
* FUNCTION: This function subtracts largerNum from smallerNum.  It assumes that
*           largerNum is larger and if not, it must have wrapped.
*           This function is used for calculating the difference between 64-bit
*           byte counts using only 32-bit numbers and assuming that the
*           difference between the two number can be contained in a 32-bit
*           unsigned integer.
******************************************************************************/
unsigned long BNAV_Indexer_subtractByteCounts( unsigned long largerNum, unsigned long smallerNum )
{
    if (largerNum >= smallerNum)
    {
        return largerNum - smallerNum;
    }
    else
    {
        return (0 - smallerNum) + largerNum;
    }
}

const char *BNAV_frameTypeStr[] = {
    "Seq",  /* eSCTypeSeqHdr    Sequence header */
    "I",    /* eSCTypeIFrame    I-frame */
    "P",    /* eSCTypePFrame    P-frame */
    "B",    /* eSCTypeBFrame    B-frame */
    "GOP",  /* eSCTypeGOPHdr    GOP header */
    "RP",   /* eSCTypeRPFrame   Reference picture frame */
    "Unk",  /* eSCTypeUnknown   Unknown or "don't care" frame type */
    0
};

int BNAV_Indexer_IsHits(BNAV_Indexer_Handle handle) {
    return handle->isHits;
}

int BNAV_Indexer_SetVChipState(BNAV_Indexer_Handle handle, unsigned short vchipState)
{
    return BNAV_pack_vchip(vchipState, &handle->vchip);
}

unsigned short BNAV_Indexer_GetVChipState(BNAV_Indexer_Handle handle)
{
    return BNAV_unpack_vchip(handle->vchip);
}

unsigned short BNAV_unpack_vchip(unsigned short packed_vchip)
{
    /* unpack from 12 bits */
    packed_vchip = ((packed_vchip << 2) & 0x3f00) | (packed_vchip & 0x003f);
    /* reset the 1 bits & return */
    return packed_vchip | 0x4040;
}

int BNAV_pack_vchip(unsigned short unpacked_vchip, unsigned short *packed_vchip)
{
    /* test the 1 bit in each byte */
    if ((unpacked_vchip & 0x4040) != 0x4040) {
        /*printf("Invalid vchip value: 0x%04x\n", unpacked_vchip);*/
        return -1;
    }
    /* pack into 12 bits */
    *packed_vchip = ((unpacked_vchip & 0x3f00)>>2) | (unpacked_vchip & 0x003f);
    return 0;
}

int BNAV_Indexer_GetPosition(BNAV_Indexer_Handle handle, BNAV_Indexer_Position *position)
{
    if (!handle->totalEntriesWritten)
        return -1;
    else {
        BNAV_Entry *p_entry = &handle->lastEntryWritten;
        position->index = handle->totalEntriesWritten-1;
        position->pts = BNAV_get_framePts(p_entry);
        position->offsetHi = BNAV_get_frameOffsetHi(p_entry);
        position->offsetLo = BNAV_get_frameOffsetLo(p_entry);
        position->timestamp = BNAV_get_timestamp(p_entry);
        position->vchipState = BNAV_unpack_vchip(BNAV_get_packed_vchip(p_entry));
        return 0;
    }
}

static long
BNAV_Indexer_FeedAVC(BNAV_Indexer_Handle handle, const void *p_bfr, long numEntries)
{
    long i;
    const BSCT_SixWord_Entry *p_curBfr;
    BNAV_AVC_Entry *avcEntry = &handle->avcEntry;

    if (handle->settings.sctVersion != BSCT_Version6wordEntry) {
        /*printf("Must use 6 word SCT's for AVC content\n");*/
        return -1;
    }
    /* no AVC hits */
    handle->isHits = 0;

    p_curBfr = (const BSCT_SixWord_Entry *)p_bfr;
    for(i=0; i<numEntries; i++, p_curBfr++)
    {
        unsigned char sc = returnStartCode(p_curBfr->startCodeBytes); /* parse once */
        unsigned long offset, offsetHi;
        unsigned nal_unit_type;
        unsigned nal_ref_idc;
#define TOTAL_PAYLOAD 8
        unsigned char payload[TOTAL_PAYLOAD];
        unsigned index = 0, bit = 7;
        BSCT_Entry *p_curSct4 = CONVERT_TO_SCT4(p_curBfr);

    /*Check for TPIT Entry to extract RAI*/
    if((p_curBfr->word0>>24) == 1){
        if((p_curBfr->startCodeBytes & 0x20)>>5){
            handle->random_access_indicator = true;
        }
        continue;
    }

        /* Grab the PTS */
        if (sc == 0xfe) {
            handle->next_pts = BNAV_Indexer_returnPts(p_curSct4);
            continue;
        }
        if (sc & 0x80) {
            /* if forbidden_zero_bit is set, this is not an AVC start code */
            continue;
        }

        offset = BNAV_Indexer_getScByteOffsetLo( handle, p_curSct4 );
        offsetHi = BNAV_Indexer_getScByteOffsetHi(handle, p_curSct4);
        BNAV_Indexer_P_AddAppend(handle, &offsetHi, &offset);

        VALIDATE_AVC_SC(p_curSct4,sc);

        /*printf("sc %02x at %#lx\n", sc, offset);*/
        nal_ref_idc = (sc >> 5) & 0x3;
        nal_unit_type = sc & 0x1F;

        /* extract 8 bytes of payload from BSCT_SixWord_Entry fields. see RDB for documentation on this. */
        payload[0] = (p_curBfr->startCodeBytes >> 16) & 0xFF;
        payload[1] = (p_curBfr->startCodeBytes >> 8) & 0xFF;
        payload[2] = (p_curBfr->recordByteCountHi >> 16) & 0xFF;
        payload[3] = (p_curBfr->recordByteCountHi >> 8) & 0xFF;
        payload[4] = p_curBfr->recordByteCountHi & 0xFF;
        payload[5] = (p_curBfr->flags >> 24) & 0xFF;
        payload[6] = (p_curBfr->flags >> 16) & 0xFF;
        payload[7] = p_curBfr->flags & 0xFF;

        /*printf("payload %02x%02x%02x%02x%02x%02x%02x%02x\n",*/
            /*payload[0],payload[1],payload[2],payload[3],payload[4],payload[5],payload[6],payload[7]);*/

        /* complete pending PPS or SPS because we've hit the next NAL */
        if (handle->avc.current_pps >= 0) {
            /* complete the PPS */
            int id = handle->avc.current_pps;
            handle->avc.pps[id].size = BNAV_Indexer_subtractByteCounts(
                offset, handle->avc.pps[id].offset);
            handle->avc.current_pps = -1;
        }
        else if (handle->avc.current_sps >= 0) {
            /* complete the SPS */
            int id = handle->avc.current_sps;
            handle->avc.sps[id].size = BNAV_Indexer_subtractByteCounts(
                offset, handle->avc.sps[id].offset);
            handle->avc.current_sps = -1;
        }
        /* We must call BNAV_Indexer_completeAVCFrame UNLESS we have IDR/non-IDR slice
        with first_mb_in_slice != 0. So handle all the "other" cases in one spot. */
        if (nal_unit_type != 1 && nal_unit_type != 5) {
            handle->picEnd = offset;
            if (BNAV_get_frameType(avcEntry) == eSCTypeIFrame)
                handle->prev_I_rfo = handle->rfo;
            BNAV_Indexer_completeAVCFrame( handle );
        }

        /* if SEI and preceding was not an SEI, remember this offset for start point of next PPS, SPS or picture */
        if (nal_unit_type == 6 && !handle->avc.current_sei_valid) {
            handle->avc.current_sei_valid = true;
            handle->avc.current_sei = offset;
        }

        switch (nal_unit_type) {
        case 1: /* non-IDR slice */
        case 5: /* IDR slice */
            {
            unsigned first_mb_in_slice, slice_type, pic_parameter_set_id;
            unsigned sps_id;

            /* vlc decode the payload */
            first_mb_in_slice = b_vlc_decode(payload, TOTAL_PAYLOAD, index, bit, &index, &bit);
            slice_type = b_vlc_decode(payload, TOTAL_PAYLOAD, index, bit, &index, &bit);
            pic_parameter_set_id = b_vlc_decode(payload, TOTAL_PAYLOAD, index, bit, &index, &bit);

            /* check the pps. anything above this is an invalid AVC stream. */
            if (pic_parameter_set_id >= TOTAL_PPS_ID) {
                /*printf("pic_parameter_set_id %d\n", pic_parameter_set_id);*/
                return -1;
            }
            /* check the sps right away. if we use a PPS without receiving it's SPS first, we should discard. */
            sps_id = handle->avc.pps[pic_parameter_set_id].sps_id;
            if (sps_id >= TOTAL_SPS_ID) {
                /*printf("seq_parameter_set_id %d from pps %d\n", sps_id, pic_parameter_set_id);*/
                return -1;
            }

            /*printf("%s slice: mb=%-4d type=%-2d pps=%-3d offset=%#lx\n",*/
                /*(nal_unit_type==1)?"non-IDR":"IDR", first_mb_in_slice, slice_type, pic_parameter_set_id, offset);*/

            if (first_mb_in_slice == 0) {
                /* we have the beginning of a new frame. first, complete the previous frame. */
                handle->picEnd = offset;
                if (BNAV_get_frameType(avcEntry) == eSCTypeIFrame)
                    handle->prev_I_rfo = handle->rfo;
                BNAV_Indexer_completeAVCFrame( handle );

                /* start the next frame */
                handle->picStart = handle->avc.current_sei_valid?handle->avc.current_sei:offset; /* start with preceding SEI's if present */

                BNAV_set_frameOffsetLo(avcEntry, handle->picStart);
                BNAV_set_frameOffsetHi(avcEntry, offsetHi);

                /* default to I frame until P or B slices indicate differently */
                BNAV_set_frameType(avcEntry, eSCTypeIFrame);
                handle->isISlice = 1;
                handle->avc.is_reference_picture = 0;

                /* Set PPS and SPS */
                BNAV_set_seqHdrStartOffset(avcEntry,
                    BNAV_Indexer_subtractByteCounts(handle->picStart, handle->avc.pps[pic_parameter_set_id].offset));
                BNAV_set_seqHdrSize(avcEntry,
                    handle->avc.pps[pic_parameter_set_id].size);
                BNAV_set_SPS_Offset(avcEntry,
                    BNAV_Indexer_subtractByteCounts(handle->picStart, handle->avc.sps[sps_id].offset));
                BNAV_set_SPS_Size(avcEntry,
                    handle->avc.sps[sps_id].size);

                /*printf("sps %d: %#lx, %ld\n", sps_id, BNAV_get_SPS_Offset(avcEntry), BNAV_get_SPS_Size(avcEntry));*/

                /* check for P slice, which means it's not a B frame */
                if (slice_type == 0 || slice_type == 5) {
                    handle->prev_I_rfo = 0;
                    /* First P after first I allows open GOP B's to be saved */
                    if (handle->hitFirstISlice)
                        handle->allowOpenGopBs = 1;
                }

                /* Sets the refFrameOffset after adding the prev_I_rfo to the rfo.
                prev_I_rfo will be non-zero ONLY for open gop B's, which are B's that come
                after an I but before a P. */
                /*printf("BNAV_set_refFrameOffset %d, %d\n", handle->rfo, handle->prev_I_rfo);*/
                BNAV_set_refFrameOffset(avcEntry, handle->rfo + handle->prev_I_rfo);

                if (handle->hitFirstISlice)
                    handle->rfo++;

                BNAV_set_framePts(avcEntry, handle->next_pts);

        BNAV_set_RandomAccessIndicator(avcEntry, handle->random_access_indicator);
        handle->random_access_indicator = false;
            }

            if (nal_unit_type == 5 && (slice_type !=2 && slice_type != 7)) {
                /*printf("IDR frame with non-I slices\n");*/
                return -1;
            }

            /* test if the slice is a referenced by another slice */
            if (nal_ref_idc) {
                handle->avc.is_reference_picture = 1;
            }

            /* test every slice to determine frame type */
            switch (slice_type) {
            case 2:
            case 7:
                /* we've already defaulted to I frame */
                break;
            case 0:
            case 5:
                /* if we ever get one P slice, then it's either a P or B frame, cannot be I */
                if (BNAV_get_frameType(avcEntry) == eSCTypeIFrame) {
                    handle->isISlice = 0;
                    BNAV_set_frameType(avcEntry, eSCTypePFrame);
                }
                break;
            case 1:
            case 6:
                /* if we ever get one B slice, it's a B frame */
                handle->isISlice = 0;
                BNAV_set_frameType(avcEntry, eSCTypeBFrame);
                break;
            default:
                /*printf("unsupported slice_type %d\n", slice_type);*/
                break;
            }
            }
            break;
        case 7: /* sequence parameter set */
            {
            unsigned profile_idc, constraint_flags, level_idc, seq_parameter_set_id;

            /* parse and vlc decode the payload */
            profile_idc = payload[0];
            constraint_flags = payload[1];
            level_idc = payload[2];
            index = 3;
            seq_parameter_set_id = b_vlc_decode(payload, TOTAL_PAYLOAD, index, bit, &index, &bit);
            if (seq_parameter_set_id >= TOTAL_SPS_ID) {
                /*printf("corrupt seq_parameter_set_id %d\n", seq_parameter_set_id);*/
                return -1;
            }
            handle->avc.sps[seq_parameter_set_id].offset = handle->avc.current_sei_valid?handle->avc.current_sei:offset; /* start with preceding SEI's if present */
            handle->avc.current_sps = seq_parameter_set_id;

            /*printf("SeqParamSet: profile_idc=%d flags=0x%x level_idc=%d SPS=%d offset=%#lx\n",*/
                /*profile_idc, constraint_flags, level_idc, seq_parameter_set_id, offset);*/
            }
            break;
        case 8: /* picture parameter set */
            {
            unsigned pic_parameter_set_id, seq_parameter_set_id;

            /* vlc decode payload */
            pic_parameter_set_id = b_vlc_decode(payload, TOTAL_PAYLOAD, index, bit, &index, &bit);
            if (pic_parameter_set_id >= TOTAL_PPS_ID) {
                /*printf("corrupt pic_parameter_set_id %d\n", pic_parameter_set_id);*/
                return -1;
            }
            seq_parameter_set_id = b_vlc_decode(payload, TOTAL_PAYLOAD, index, bit, &index, &bit);
            if (seq_parameter_set_id >= TOTAL_SPS_ID) {
                /*printf("corrupt seq_parameter_set_id %d\n", seq_parameter_set_id);*/
                return -1;
            }

            handle->avc.pps[pic_parameter_set_id].offset = handle->avc.current_sei_valid?handle->avc.current_sei:offset; /* start with preceding SEI's if present */
            handle->avc.pps[pic_parameter_set_id].sps_id = seq_parameter_set_id;
            handle->avc.current_pps = pic_parameter_set_id;

            /*printf("PicParamSet: PPS=%d, SPS=%d offset=%#lx\n",*/
                /*pic_parameter_set_id, seq_parameter_set_id, offset);*/
            }
            break;

#if 0
/* This code is optional because we are detecting the picture type by examining each slice. */
        case 9: /* access unit delimiter */
            {
#if BDBG_DEBUG_BUILD
            static const char *primary_pic_type_str[] = {
                "I",
                "I,P",
                "I,P,B",
                "SI",
                "SI,SP",
                "I,SI",
                "I,SI,P,SP",
                "I,SI,P,SP,B"
            };
#endif
            int primary_pic_type;
            primary_pic_type = (payload[0] >> 5) & 0x3;

            BDBG_MSG(("AUD %d (%s)", primary_pic_type, primary_pic_type_str[primary_pic_type]));
            }
            break;
#endif
        }

        /* after any non-SEI, the current_sei is no longer valid */
        if (nal_unit_type != 6) {
            handle->avc.current_sei_valid = false;
        }
    }

    return i;
}

static long
BNAV_Indexer_FeedAVS(BNAV_Indexer_Handle handle, void *p_bfr, long numEntries)
{
    long i;
    const BSCT_Entry *p_curBfr=NULL;
    const BSCT_SixWord_Entry *p_cur6WordBfr=NULL;
    BNAV_Entry *navEntry = &handle->curEntry;

    if (handle->settings.sctVersion != BSCT_Version6wordEntry)
    {
        /*printf("Must use 6 word SCT's for AVC content\n");*/
        return -1;
    }
    p_cur6WordBfr = (const BSCT_SixWord_Entry *)p_bfr;

    for (i=0; i<numEntries; i++,p_cur6WordBfr++)
    {
        int sc;
        unsigned long offset, offsetHi;

        p_curBfr = CONVERT_TO_SCT4(p_cur6WordBfr);

        /* make sure this is not a tpit entry */
        if ((p_cur6WordBfr->word0>>24) == 1)
        {
            if ((p_curBfr->startCodeBytes & 0x20)>>5)
            {
                handle->random_access_indicator = true;
            }
            continue;
        }

        sc = returnStartCode(p_curBfr->startCodeBytes); /* parse once */
        offset = BNAV_Indexer_getScByteOffsetLo(handle, p_curBfr);
        offsetHi = BNAV_Indexer_getScByteOffsetHi(handle, p_curBfr);

        BNAV_Indexer_P_AddAppend(handle, &offsetHi, &offset);

        /* detect invalid start code and offsets */
        VALIDATE_AVS_SC(p_curBfr,sc);

        /*printf("AVS SCT Entry: %02x 0x%02lx%08lx\n", sc,*/
                  /*(p_curBfr->recordByteCountHi>>24) & 0xFF, p_curBfr->recordByteCount);*/
        if (handle->seqHdrFlag)
        {
            if (sc != SC_AVS_PES && sc != SC_AVS_PTS && sc != SC_AVS_EXTENSION && sc != SC_AVS_USER_DATA)
            {
                handle->seqHdrFlag = 0;
                handle->seqHdrSize = BNAV_Indexer_subtractByteCounts(offset, handle->seqHdrStartOffset);
            }
        }

        switch (sc)
        {
        case SC_AVS_FIRST_SLICE:
            break;

        case SC_AVS_PES:
            break;

        case SC_AVS_PTS:
            handle->next_pts = BNAV_Indexer_returnPts(p_curBfr);
            break;

        case SC_AVS_SEQUENCE:
            handle->seqHdrStartOffset = offset;
            handle->seqHdrFlag = 1; /* set on next qualifying sct */

            /* new complete any pending frame */
            handle->picEnd = handle->seqHdrStartOffset;
            BNAV_Indexer_completeFrame( handle );
            break;

        case SC_AVS_SEQ_END:   /* TODO: Change me to any non-slice */
            /* complete any pending frame */
            handle->picEnd = offset;
            BNAV_Indexer_completeFrame( handle );
            break;

        case SC_AVS_PICTURE_I:
        case SC_AVS_PICTURE_PB:
            /* complete any pending frame */
            handle->picEnd = offset;
            BNAV_Indexer_completeFrame( handle );

            /* start a new frame */
            handle->picStart = offset;

            BNAV_set_frameOffsetLo(navEntry, offset);
            BNAV_set_frameOffsetHi(navEntry, offsetHi);

            if (sc == SC_AVS_PICTURE_I)
            {
                handle->isISlice = 1;   /* indicated I picture */
                handle->isHits = 0;     /* for AVS this should always be 0 */
                BNAV_set_frameType(navEntry, eSCTypeIFrame);
            }
            else
            {
                switch (returnAvsPictureCode(p_curBfr->recordByteCountHi))
                {
                case PC_AVS_P_FRAME:
                    handle->prev_I_rfo = 0;
                    /* First P after first I allows open GOP B's to be saved */
                    /* if (handle->hitFirstISlice)
                        handle->allowOpenGopBs = 1; */
                    BNAV_set_frameType(navEntry, eSCTypePFrame);
                    break;
                case PC_B_FRAME:
                    BNAV_set_frameType(navEntry, eSCTypeBFrame);
                    break;
                }
            }

            /* make sequence header offset relative to current frame rather than */
            /* relative to reference frame to allow removal of b-frames */
            BNAV_set_seqHdrSize(navEntry, (unsigned short)handle->seqHdrSize);
            BNAV_set_seqHdrStartOffset(navEntry,
                                       BNAV_Indexer_subtractByteCounts(handle->picStart, handle->seqHdrStartOffset));

            /* Sets the refFrameOffset after adding the prev_I_rfo to the rfo.
            prev_I_rfo will be non-zero ONLY for open gop B's, which are B's that come
            after an I but before a P. */
            BNAV_set_refFrameOffset(navEntry, handle->rfo + handle->prev_I_rfo);

            if (handle->settings.navVersion >= BNAV_VersionOpenGopBs)
            {
                if (sc == SC_AVS_PICTURE_I)
                    handle->prev_I_rfo = handle->rfo;
            }

            if (handle->hitFirstISlice)
                handle->rfo++;

            BNAV_set_framePts(navEntry, handle->next_pts);
            break;
        default:
            break;

        }

    }

    return i;
}

int BNAV_Indexer_FeedPES(BNAV_Indexer_Handle handle, uint8_t *p_bfr, unsigned size)
{
	p_bfr = p_bfr;
	size = size;
    if (handle->settings.navVersion == BNAV_Version_VC1_PES) {
        /*return BNAV_P_FeedPES_VC1(handle, p_bfr, size);*/
        return -1;
    }

    /*printf("FeedPES is only supported for BNAV_Version_VC1_PES\n");*/
    return -1;
}


int BNAV_Indexer_FileOffset_Add( BNAV_Indexer_Handle handle, int size )
{
	uint64_t size_l = size;

	if(handle)
	{
		if( (uint64_t)( handle->settings.append.offsetLo + size_l) > 0xFFFFFFFF)
		{
			handle->settings.append.offsetHi += 1;
		}
		handle->settings.append.offsetLo += size_l;
	}
	return 0;
}
