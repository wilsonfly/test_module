#include "stdafx.h"
#include "swhttpserver.h"
#include "swthrd.h"
#include <netinet/tcp.h>

typedef struct
{
	int skt;
	unsigned long ip;
	/* �������˿� */
	unsigned short port;
	/*�������߳�*/
	HANDLE  thrd;
	/*�ص�����*/
	PHttpServerCallback httpserver_callback;
	/*�ص������Ĳ���*/
	unsigned long callback_param;
}SHttpServer;

typedef struct
{
	HttpResponseNum type;
	const char *name;
	const char *info;
} HttpEnumString;

static const HttpEnumString httpResponseNames[] = {
	{ HTTP_OK, "OK", "" },
	{ HTTP_MOVED_TEMPORARILY, "Found", "Directories must end with a slash." },
	{ HTTP_REQUEST_TIMEOUT, "Request Timeout",
	  "No request appeared within a reasonable time period." },
	{ HTTP_NOT_IMPLEMENTED, "Not Implemented",
	  "The requested method is not recognized by this server." },
	{ HTTP_UNAUTHORIZED, "Unauthorized", "" },
	{ HTTP_NOT_FOUND, "Not Found",
	  "The requested URL was not found on this server." },
	{ HTTP_BAD_REQUEST, "Bad Request", "Unsupported method." },
	{ HTTP_FORBIDDEN, "Forbidden", "" },
	{ HTTP_INTERNAL_SERVER_ERROR, "Internal Server Error",
	  "Internal Server Error" },
	{ HTTP_CREATED, "Created","Created" },
	{ HTTP_ACCEPTED, "Accepted","Accepted"},
	{ HTTP_NO_CONTENT, "No Content","No Content"},
	{ HTTP_MULTIPLE_CHOICES, "Multiple Choices","Multiple Choices"},
	{ HTTP_MOVED_PERMANENTLY, "Moved Permanently","Move Permanently"},
	{ HTTP_NOT_MODIFIED, "Not Modified","Not Modified"},
	{ HTTP_BAD_GATEWAY, "Bad Gateway", "" },
	{ HTTP_SERVICE_UNAVAILABLE, "Service Unavailable", "" },
};

static const char RFC1123FMT[] = "%a, %d %b %Y %H:%M:%S GMT";
static bool HttpServerProc( unsigned long wParam, unsigned long lParam );

/** 
 * ����һ��httpserver 
 * 
 * @param port �������˿ںţ� ������
 * @param callback �ص�����
 * @param wparam  �ص������Ĳ���
 * 
 * @return ����Httpserver���
 */
HANDLE sw_httpserver_open(unsigned long ip,unsigned short port, PHttpServerCallback callback, uint32_t wparam )
{
	int fd;
	int on = 1;
	SHttpServer* pServer = NULL;
    	struct sockaddr_in addr;
	fd = socket( AF_INET,SOCK_STREAM,0);
	if(fd < 0)
	{
		printf("sw_httpserver_open::Create socket failed!\n");
		return NULL;
	}
	setsockopt(fd, SOL_SOCKET, SO_REUSEADDR, (void *)&on, sizeof(on)) ;
	addr.sin_family = AF_INET;
	addr.sin_addr.s_addr = ip;
	addr.sin_port = port;
	bind( fd, (struct sockaddr*)&addr, sizeof(addr) );
	listen(fd, 32);
	if((pServer = malloc(sizeof(SHttpServer))) == NULL)
	{
		printf("[HTTPSERVER]malloc failed!\n");
		return NULL;
	}
	memset(pServer, 0, sizeof(SHttpServer));
	pServer->skt = fd;
	pServer->ip = INADDR_ANY;
	pServer->port = port;
	pServer->httpserver_callback = callback;
	pServer->callback_param = wparam;
	pServer->thrd = sw_thrd_open( "tHttpServer", 80, 0, 16384, (PThreadHandler)HttpServerProc, (unsigned long)pServer, 0 );
	if(pServer->thrd == NULL)
	{
		printf("[HTTPSERVER]sw_thrd_open failed!\n");
		free(pServer);
		close(fd);
		return NULL;	
	}
	sw_thrd_resume( pServer->thrd );
	return pServer;
}


/** 
 * �ر�httpserver
 * 
 * @param server 
 */
void sw_httpserver_close( HANDLE server )
{
	SHttpServer* pServer = (SHttpServer*)server;

	if( server == NULL )
		return;
	if( pServer->skt != -1)
		shutdown(pServer->skt,2);

	if(pServer->thrd)
	{
		sw_thrd_close(pServer->thrd, 5000);
		pServer->thrd = NULL;
	}
	pServer->httpserver_callback = NULL;
	pServer->callback_param = 0;
	close(pServer->skt);
	pServer->skt = -1;
	free(pServer);	
}

//��socket��ȡ����
static int safe_read( int skt, char *buf, int size,int timeout)
{
	fd_set rfds,efds;
	int ret;
	struct timeval  tv;
	FD_ZERO(&rfds);
	FD_SET(skt, &rfds);
	FD_ZERO(&efds);
	FD_SET(skt, &efds);
	tv.tv_sec = timeout/1000;
	tv.tv_usec = timeout%1000*1000;
	if (timeout < 0)
		ret = select(skt+1, &rfds, NULL, &efds, NULL);
	else
		ret = select(skt+1, &rfds, NULL, &efds, &tv);

	if( FD_ISSET(skt, &efds) )
		return -1;
	if( ret >0 && FD_ISSET(skt, &rfds) )
	{
		ret = recv(skt, buf, size,0);
		if( ret <= 0 )
		{
			if( errno != EINTR && errno != EAGAIN )
				return -1;
		}
		return ret;
	}
	if (ret <0 && errno != EINTR )
		return -1;
	return 0;
}

//��ȡһ�ַ�
static char http_getc(SHttpConnectObj *s)
{
	int len = 0;
	if (s->ptr >= s->ptrend) 
	{
		len = safe_read(s->skt, s->buffer, BUFFER_SIZE,-1);
		if (len <= 0) 
		{
			printf("http getc: read failed\n");
			return -1;
		} 
		else 
		{
			s->ptr = s->buffer;
			s->ptrend = s->buffer + len;
		}
	}
	return *s->ptr++;
}

static int getLine(SHttpConnectObj* obj, int timeout)
{
	int  count = 0;
	char *buf = obj->buf,c = 0;
	while ( c = http_getc(obj) )
	{
		if( c == (char)-1 )
		{
			obj->request_header.header_length = 0;
			printf("getLine fail\n");
			return -1;
		}
		obj->buf[count] = c;
		obj->request_header.header_length++;
	  	if (buf[count] == '\r') continue;
		if (buf[count] == '\n') {
			buf[count] = 0;
			return count;
		}
		if(count < (HTTPSERVER_MAX_LINE - 1))
			count++;
	}
	if (count) return count;
	else return -1;
}

/** 
 * ����Request��ͷ�� �ɹ������request_header�ṹ
 * 
 * @param obj 
 * @param timeout 
 * 
 * @return int: �ɹ����ر���ͷ�Ĵ�С�� ʧ�ܷ��ظ���
 */
int sw_httpserver_recv_request_header(SHttpConnectObj* obj, int timeout )
{
	char *p;
	int i;
	memset(&obj->request_header, 0, sizeof(HTTP_REQUEST_HEADER));
	do
	{
		if(getLine(obj,timeout) <= 0)
			break;
		p = strchr(obj->buf, ' ');
		if( p==NULL )
			continue;
		i = p-obj->buf;
		if(strncasecmp(obj->buf, "GET", i) == 0 || strncasecmp(obj->buf, "POST", i) == 0 )
		{
			memcpy( obj->request_header.method, obj->buf, i );
			while( *p==' ' )p++;
			for( i=0; p[i] && p[i]!=' '; i++ );
			memcpy( obj->request_header.request_url, p, 
				i<sizeof(obj->request_header.request_url) ? i : sizeof(obj->request_header.request_url)-1 );
		}
		else if(strncasecmp(obj->buf, "Host:", i) == 0)
		{
			strncpy(obj->request_header.host, p+1, sizeof(obj->request_header.host)-1);
			
		}
		else if(strncasecmp(obj->buf, "Accept:", i) == 0)
		{
			strncpy(obj->request_header.accept_type, p+1, sizeof(obj->request_header.accept_type)-1);
			
		}
		else if(strncasecmp(obj->buf, "Accept-Encoding:", i) == 0)
		{
			strncpy(obj->request_header.accept_encoding, p+1, sizeof(obj->request_header.accept_encoding)-1);
			
		}	
		else if(strncasecmp(obj->buf, "Content-Type:", i) == 0)
		{
			strncpy(obj->request_header.content_type, p+1, sizeof(obj->request_header.content_type)-1);
			
		}
		else if(strncasecmp(obj->buf, "Connection:", i) == 0)
		{
			strncpy(obj->request_header.connection, p+1,  sizeof(obj->request_header.connection)-1);
			
		}
		else if(strncasecmp(obj->buf, "Range:", i) == 0)
		{
			char *q = strstr( p,"bytes=" );
			if( q )
			{
				q = q+6;
				if( atoi(q)> 0 )
				{
					obj->request_header.header_length = 0;
					break;
				}

			}
			strncpy(obj->request_header.connection, p+1,  sizeof(obj->request_header.connection)-1);
		}
	}while(1);
	printf("%s\n",obj->buf);
	return obj->request_header.header_length;	
}
	
/** 
 * ��������ʵ��
 * 
 * @param obj 
 * @param buf 
 * @param buf_size 
 * @param timeout 
 * 
 * @return ���ؽ������ݵ��ֽ����� 0: ������ɣ� -1: ���ճ���
 */
int sw_httpserver_recv_request_content(SHttpConnectObj* obj, char*buf, int buf_size, int timeout )
{
	//do nothing
	return -1;
}

static int safe_write( int skt, const char *buffer, int n,int timeout)
{
	int ret, buflen;
	int i = 0;
	fd_set wfds,efds;
	struct timeval  tv;
	tv.tv_sec = timeout/1000;
	tv.tv_usec = timeout%1000*1000;
	buflen = n;
	while(i < buflen)
	{
		FD_ZERO(&wfds);
		FD_SET(skt, &wfds);
		FD_ZERO(&efds);
		FD_SET(skt, &efds);
		ret = select(skt+1, NULL, &wfds, &efds, &tv);
		if (0 < ret && FD_ISSET(skt, &wfds) &&  !FD_ISSET(skt, &efds))
			ret = send(skt, buffer+i, buflen-i,0);
		if (ret <= 0 || FD_ISSET(skt, &efds))
		{
			printf("send error ret = %d, info:%s\n",ret,strerror(errno) );
			return -1;
		}
		i += ret;
	}
	return 0;
}
		
/** 
 * 
 * ������Ӧ����ͷ
 * @param obj 
 * @param responseNum 
 * @param pContentType 
 * @param pContentEncoding 
 * @param pConnection 
 * @param nContentLength 
 * @param timeout 
 * 
 * @return ���͵������ֽ���
 */
int sw_httpserver_send_response_header(SHttpConnectObj* obj, HttpResponseNum responseNum, 
									   char* pContentType, char* pContentEncoding, 
									   char* pConnection,
									   int nContentLength, 
									   int timeout)
{
	char *buf = obj->buf;
	const char *responseString = "";
	const char *infoString = NULL;
	time_t timer = time(0);
	char timeStr[80];
	int i, len;

	for (i = 0; i<(int)(sizeof(httpResponseNames)/sizeof(httpResponseNames[0])); i++) 
	{
		if (httpResponseNames[i].type == responseNum) 
		{
			responseString = httpResponseNames[i].name;
			infoString = httpResponseNames[i].info;
			break;
		}
	}

	if(infoString == NULL)
	{
		printf("Wrong response number[%d]\n",  responseNum);
		return -1;
		
	}

	/* emit the current date */
	strftime(timeStr, sizeof(timeStr), RFC1123FMT, gmtime(&timer));

	len = sprintf(buf,
				  "HTTP/1.1 %d %s\r\n"
				  "Server: AndroidSTB(Sunniwell)\r\n"
				  "Date: %s\r\n",
				  responseNum, responseString, timeStr);
	if(pContentType)
		len += sprintf(buf+len, "Content-type: %s\r\n", pContentType);
	if(pContentEncoding)
		len += sprintf(buf+len, "Content-Encoding: %s\r\n", pContentEncoding);
	if( nContentLength == -1 )
	{
		obj->chunked = true;
		len += sprintf(buf+len, "Transfer-Encoding: chunked\r\n");
	}
	else if(nContentLength>0)
		len += sprintf(buf+len, "Content-Length: %lld\r\n", (int64_t)nContentLength);
	if(pConnection)
		len += sprintf(buf+len, "Connection: %s\r\n", pConnection);
   	len += sprintf(buf+len, "Cache-Control: no-cache\r\n");
	len += sprintf(buf+len, "\r\n");
	printf("[HTTPSERVER RESPONSE]\n%s\n", buf);
	i = 0;
	while(i < len)
	{
		int ret = 0;
		ret = send(obj->skt, buf + i, len - i,0);
		if( ret <= 0 )
		{
			printf("send return error : %d\n", ret);
			/*error has happended , report fail*/
			return 0;
		}
		i += ret;
	}

	return len;
}
	
/** 
 * ������Ӧʵ��
 * 
 * @param obj 
 * @param buf 
 * @param buf_size 
 * @param timeout 
 * 
 * @return ���ط��������ֽ��� -1������ʧ��
 */
int sw_httpserver_send_response_content(SHttpConnectObj* obj,
						char*buf, int buf_size,
						int timeout)
{
	if( obj->chunked )
	{
		char temp[16];
		char crlf[] = "\r\n";
		snprintf(temp, sizeof(temp), "%x\r\n", buf_size);
		if( safe_write(obj->skt, temp, strlen(temp),60000 ) <0 || 
				safe_write(obj->skt,buf,buf_size,60000 ) <0 ||
				safe_write(obj->skt,crlf,2,60000)<0 )
			return -1;
		return buf_size;
	}
	return safe_write(obj->skt, buf, buf_size,60000);

}

/** 
 * �ر�����,ͬʱ�ͷ���Դ
 * 
 * @param obj 
 */
void sw_httpserver_close_connectobj(SHttpConnectObj* obj)
{
	if(obj)
	{
		close(obj->skt);
		free(obj);	
	}
}
	

static bool HttpServerProc( unsigned long wParam, unsigned long lParam )
{
	int skt = -1,optval = 1,ret = 0;
	SHttpServer *pServer = (SHttpServer *)wParam;
	struct sockaddr_in from;
	int slen = sizeof(from);
	if((skt = accept( pServer->skt, (struct sockaddr *)&from, &slen )) >= 0)
	{
		SHttpConnectObj* obj = malloc(sizeof(SHttpConnectObj));
		int on = 1;
		if(obj == NULL)
		{
			printf("[HTTPSERVER]malloc failed!\n");
			return true;
								
		}

		obj->skt = skt;
		obj->from_ip = from.sin_addr.s_addr;
		obj->from_port = from.sin_port;
		obj->hHttpServer = pServer;
		obj->ptr = obj->buffer;
		obj->ptrend = obj->buffer;

		ret = setsockopt(skt, SOL_SOCKET, SO_KEEPALIVE, (void *)&on, sizeof (on));
		if( ret != 0 )
			printf("setsockopt keepalive failed %s\n",strerror(errno));
		optval = 1;
		ret = setsockopt(skt,IPPROTO_TCP,TCP_NODELAY,(void*)&optval,sizeof(optval));
		if( ret != 0 )
			printf("setsockopt tcpnodelay failed %s\n",strerror(errno));

		optval = 1;
		ret = ioctl(skt, FIONBIO, (int)&optval);
		if( ret != 0 )
			printf("setsockopt unblock failed %s\n",strerror(errno));
		if(pServer->httpserver_callback)
			pServer->httpserver_callback(obj, pServer->callback_param);
		
		return true;
	}
	pServer->thrd = NULL;
	return false;
}

