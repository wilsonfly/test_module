#include <sys/types.h>
#include <sys/stat.h>

#include <stdio.h>
#include <stdlib.h>
#include <errno.h>
#include <ctype.h>
#include <time.h>
#include <string.h>   /* for NULL */
#include <unistd.h>

#include "hi_adp.h"
#include "hi_adp_tuner.h"
#include "hi_adp_boardcfg.h"
#include "hi_unf_ecs.h"

#if 0
#define     ACTIVE_TUNER_ID 0
HI_S32  DVB_CabTunerInit()
{
    HI_UNF_TUNER_ATTR_S TunerAttr;

    /* ��ʼ��Tuner*/
    HIAPI_RUN_RETURN(HI_UNF_TUNER_Init());

    /* ��Tuner*/
    HIAPI_RUN_RETURN(HI_UNF_TUNER_Open(ACTIVE_TUNER_ID));

    /* ��ȡĬ������,�Ա�������������� */
    HIAPI_RUN_RETURN(HI_UNF_TUNER_GetDeftAttr(ACTIVE_TUNER_ID, &TunerAttr));

    HIAPI_RUN_RETURN(HI_UNF_TUNER_SetAttr(ACTIVE_TUNER_ID, &TunerAttr));

    return HI_SUCCESS;
}

HI_S32  DVB_CabTunerDeInit()
{
    HI_S32 s32Ret = HI_SUCCESS;

    HIAPI_RUN(HI_UNF_TUNER_Close(ACTIVE_TUNER_ID),s32Ret);
    HIAPI_RUN(HI_UNF_TUNER_DeInit(),s32Ret);

    return HI_SUCCESS;
}

/***********************************************************
	u32freq : MHZ
	u32SymbolRate : KHZ
	u32qam : 0:16QAM 1:32QAM 2:64QAM 3:128QAM 4:256QAM
************************************************************/
HI_S32  DVB_CabTunerLock(HI_U32 u32TunerPort,HI_U32 u32freq, HI_U32 u32SymbolRate, HI_U32 u32qam)
{
    HI_U32 i;
    HI_S32 ret;
    HI_UNF_TUNER_CONNECT_PARA_S stConnectPara;
    HI_UNF_TUNER_STATUS_S stTunerStatus;
    
    stConnectPara.enSigType = HI_UNF_TUNER_SIG_TYPE_CAB;
    stConnectPara.unConnectPara.stCab.bReverse   = 0;
    stConnectPara.unConnectPara.stCab.u32Freq = u32freq * 1000;
    stConnectPara.unConnectPara.stCab.u32SymbolRate = u32SymbolRate * 1000;
    stConnectPara.unConnectPara.stCab.enModType = u32qam + HI_UNF_MOD_TYPE_QAM_16;

    /* ����Tuner*/
    HIAPI_RUN_RETURN(HI_UNF_TUNER_Connect(u32TunerPort, &stConnectPara, 500));

    /*�ȴ�5��, �����û�������򱨴�*/
    for (i = 0; i < 50; i++)
    {
        ret = HI_UNF_TUNER_GetStatus(u32TunerPort, &stTunerStatus);
        if ((HI_SUCCESS == ret) && (HI_UNF_TUNER_SIGNAL_LOCKED == stTunerStatus.enLockStatus))
        {
            printf("tuner lock %d success !\n",stConnectPara.unConnectPara.stCab.u32Freq);
            break;
        }

        usleep(100000);
    }

    /* ���Tuner����,���ӡ"Tuner�Ѿ�����"��Ϣ */
    if (HI_UNF_TUNER_SIGNAL_LOCKED != stTunerStatus.enLockStatus)
    {
        printf("tuner lock %d failed !\n",stConnectPara.unConnectPara.stCab.u32Freq);
        return HI_FAILURE;
    }

    return HI_SUCCESS;

}
#endif


/********************************* TUNER ���ú���*******************************************/
HI_S32 HIADP_Tuner_Init()
{
    HI_S32   Ret;
    HI_UNF_TUNER_ATTR_S          TunerAttr;

    /* ��ʼ��Tuner*/
    Ret = HI_UNF_TUNER_Init();
    if (HI_SUCCESS != Ret)
    {
        printf("call HI_UNF_TUNER_Init failed.\n");
        return Ret;
    }

    /* ��Tuner*/
    Ret = HI_UNF_TUNER_Open(TUNER_USE);
    if (HI_SUCCESS != Ret)
    {
        printf("call HI_UNF_TUNER_Open failed.\n");
        HI_UNF_TUNER_DeInit();
        return Ret;
    }

    /* ��ȡĬ������,�Ա�������������� */
    Ret = HI_UNF_TUNER_GetDeftAttr(TUNER_USE, &TunerAttr);
    if (HI_SUCCESS != Ret)
    {
        printf("call HI_UNF_TUNER_GetDeftAttr failed.\n");
        HI_UNF_TUNER_Close(TUNER_USE);
        HI_UNF_TUNER_DeInit();
        return Ret;
    }

    TunerAttr.enTunerDevType = TUNER_TYPE;
    TunerAttr.enDemodDevType = DEMOD_TYPE;
    TunerAttr.enI2cChannel = I2C_CHANNEL;
    Ret = HI_UNF_TUNER_SetAttr(TUNER_USE, &TunerAttr);
    if (HI_SUCCESS != Ret)
    {
        printf("call HI_UNF_TUNER_SetAttr failed.\n");
        HI_UNF_TUNER_Close(TUNER_USE);
        HI_UNF_TUNER_DeInit();
        return Ret;
    }

    return HI_SUCCESS;
}

/* Freq:MHZ  SymbolRate:KHZ  */
HI_S32 HIADP_Tuner_Connect(HI_U32 TunerID,HI_U32 Freq,HI_U32 SymbolRate,HI_U32 QamType)
{
    HI_UNF_TUNER_CONNECT_PARA_S  ConnectPara;

    ConnectPara.enSigType = HI_UNF_TUNER_SIG_TYPE_CAB;
    ConnectPara.unConnectPara.stCab.bReverse = 0;
    ConnectPara.unConnectPara.stCab.u32Freq = Freq * 1000;
    ConnectPara.unConnectPara.stCab.u32SymbolRate = SymbolRate * 1000;
    switch (QamType)
    {
        case 16 :
            ConnectPara.unConnectPara.stCab.enModType = HI_UNF_MOD_TYPE_QAM_16;
            break;
        case 32 :
            ConnectPara.unConnectPara.stCab.enModType = HI_UNF_MOD_TYPE_QAM_32;
            break;
        case 64 :
            ConnectPara.unConnectPara.stCab.enModType = HI_UNF_MOD_TYPE_QAM_64;
            break;
        case 128 :
            ConnectPara.unConnectPara.stCab.enModType = HI_UNF_MOD_TYPE_QAM_128;
            break;
        case 256 :
            ConnectPara.unConnectPara.stCab.enModType = HI_UNF_MOD_TYPE_QAM_256;
            break;
        case 512 :
            ConnectPara.unConnectPara.stCab.enModType = HI_UNF_MOD_TYPE_QAM_512;
            break;            
        default:
            ConnectPara.unConnectPara.stCab.enModType = HI_UNF_MOD_TYPE_QAM_64; 
    }

    /* ����Tuner*/
    return HI_UNF_TUNER_Connect(TUNER_USE, &ConnectPara, 500);
}

HI_VOID HIADP_Tuner_DeInit()
{
    HI_UNF_TUNER_Close(TUNER_USE);
    HI_UNF_TUNER_DeInit();
}

