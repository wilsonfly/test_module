#include "stdafx.h"
#include "dvbpsi.h"
#include "dvbpsi_private.h"
#include "psi.h"
#include "mpesection.h"

typedef struct{
	dvbpsi_decoder_t dvbpsi;
	uint16_t pid;
	uint8_t match[16];
	uint8_t mask[16];
	uint8_t mask_len;
	uint8_t left_buf[188];
	int left_size;
	mpesection_callback callback;
	uint32_t wparam;
	
}mpesection_t;

static void dvbpsi_mpesection(dvbpsi_decoder_t* p_decoder,
                              dvbpsi_psi_section_t* p_section)
{
	int k = 0;
	mpesection_t* mpe = (mpesection_t*)p_decoder->p_private_decoder;
/*
	printf("section: \n\ttableid %d\n\ti_length %d\n\ti_version %d\n",
		p_section->i_table_id,
		p_section->i_length,
		p_section->i_version);
*/
	//����������
	if( p_section->i_table_id == (mpe->match[0] & mpe->mask[0]) )
	{
		for( k = 1;k<mpe->mask_len;k++)
		{
			if( ( p_section->p_data[k+2] & mpe->mask[k]) != (mpe->match[k] & mpe->mask[k]) )
				break;
		}
	}
	//���Ϲ�������
	if( k == mpe->mask_len && mpe->callback)
	{
		mpe->callback( p_section->p_data,
			p_section->i_length+3,mpe->wparam );
	}
	//ɾ��
	dvbpsi_DeletePSISections( p_section );        
}

// ����һMPE sections�ռ���
HANDLE mpesection_create( uint16_t pid,mpesection_callback callback, uint32_t wparam )
{
	mpesection_t* section = (mpesection_t*)malloc(sizeof(mpesection_t));
	if( section )
	{
		dvbpsi_handle h_dvbpsi = NULL;
		memset( section,0,sizeof(mpesection_t));
		h_dvbpsi = &section->dvbpsi;
		section->pid = pid;
		section->callback = callback;
		section->wparam = wparam;
		h_dvbpsi->pf_callback = dvbpsi_mpesection;
		h_dvbpsi->p_private_decoder = (void*)section;
		h_dvbpsi->i_section_max_size = 4096;
		/* PSI decoder initial state */
		h_dvbpsi->i_continuity_counter = 31;
		h_dvbpsi->b_discontinuity = 1;
		h_dvbpsi->p_current_section = NULL;
	}
	return section;
}

// ����sections�ռ���
void mpesection_destroy( HANDLE pobj )
{
	mpesection_t* section = (mpesection_t*)pobj;
	if( section )
	{
		free( section );
	}
}

//���ù�������
int mpesection_set_filter( HANDLE pobj,uint8_t match[16],uint8_t mask[16],uint8_t mask_len)
{
	mpesection_t* section = (mpesection_t*)pobj;
	int i = 0;
	if( section )
	{
		memcpy(section->match,match,mask_len);
		memcpy(section->mask,mask,mask_len);
		section->mask_len = mask_len;
		return 0;
	}
	return -1;
}

//TS���ݴ���
int mpesection_ontsdata( HANDLE pobj,uint8_t* data, uint32_t size )
{
	mpesection_t* section = (mpesection_t*)pobj;
	uint16_t pid;
	int i = 0, n = 0;
	if( !section )
		return -1;
	//�ϴη����������в���
    if( section->left_size >0 && data[188-section->left_size] == 0x47 )
    {
        memcpy(section->left_buf+section->left_size, data, 188-section->left_size);
        pid = ( (*(section->left_buf+1)) & 0x1F );
		pid = (pid<<8) + (*(section->left_buf+2));
		if( pid == section->pid )
        	dvbpsi_PushPacket(&section->dvbpsi,section->left_buf );
        i = 188-section->left_size;
        section->left_size = 0;
    }
    
    //����TS SYNC Header
    for( ;i<size; i++ )
    {
        if( *(data+i) == 0x47 )
        {
            for( n=i; n<size; n += 188 )
            {
                if( *(data+n) != 0x47 )
                    break;
            }
            if( n >= size )
                break;
        }
    }
	//����TS��
    for(;i<n;i += 188 )
    {
        if( i+188 <= size )
        {
            section->left_size = 0;
            pid = ( (*(data+i+1)) & 0x1F );
			pid = (pid<<8) + (*(data+i+2));
			if( pid == section->pid )
            	dvbpsi_PushPacket(&section->dvbpsi,data+i );
        }
        else
        {
            section->left_size = size-i;
            memcpy( section->left_buf, data+i, section->left_size );
        }
    }
    return size;
}
