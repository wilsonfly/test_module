#include "config.h"
#include "stdafx.h"
#include "tsparser.h"
#include "tsindexer.h"
#include "bcmindexer.h"
#include "bcmindexerpriv.h"

#define TS_PACKET_SIZE 188
#define MAX_PREBUF_SIZE (1024+512)*1024
//#define MAX_PREBUF_SIZE 512*1024

#define get_frameType( words ) (words[0] >> 24)
#define get_frameOffset( words ) (((int64_t)words[2]<<32)|words[3])
#define get_framePts( words ) (words[4])
#define get_frameSize( words ) (words[5] & 0x0ffffffful)

//�����Ϣ
typedef struct{
	//�ļ�·��
	char filepath[512];
	//m3u�ļ����·��
	char m3upath[512];
	//��Ƭ���
	unsigned int fraginterval;
	//��Ƭ��Ŀ
	unsigned int fragnum;
	//��ǰ�ķ�Ƭ���
	unsigned int curnum;
	//�����洢ÿƬ��ʱ�䳤��
	unsigned int *durnation;
	int  curindex;
	//�Ƿ���ֱ��
	bool islive;
	//��Ƭ�ļ����
	FILE *tsfp;
	//m3u8�ļ����
	FILE *m3ufp;
	
}outputinfo_t;

//TS��Ƭ����ṹ
typedef struct {
	// TS��������
	tsparser_t parser; 
	unsigned char left_buf[TS_PACKET_SIZE];
	unsigned int left_size;
	//1.Ԥ������,�洢����������Ŀ��Ϣ֮ǰ������
	//2.��������ʱ�洢�ռ�,�洢��������TS������
	unsigned char *prebuf;
	//�������ݴ�С
	unsigned int presize;
	//�����Ϣ
	outputinfo_t *output;
	//TS����������
	sTsIndexer *indexer;
	//ES��������
	BNAV_Indexer_Handle bcmindexer;
	//��������ʱ�洢�ռ�,��СΪ����I֡����Ĵ�С,Ŀǰ����Ϊ1MB
	unsigned char* tsdatabuf;
	unsigned int  tsdatasize;
	//��һ֡PTS
	int64_t last_frame_pts;
	//��һI֡PTS
	int64_t last_iframe_pts;
	//�ļ�λ��
	uint64_t filepos;
	//����λ��
	uint64_t datapos;
	//��ǰ֡������һI֡ʱ����
	uint32_t timediff;
	//PTS�Ƿ���ƫת
	bool is_ptsjumped;
}tsfragment_t;

//��������
static void parser_stream( tsfragment_t* fragment, unsigned char* buffer, int size );
//�����ص�����
//==static int parser_callback( int type, unsigned char* buffer, int size );
//TS�����������ص���������
static unsigned long feed2bcmindexer( const void *p_bfr, unsigned long numEntries, unsigned long entrySize,void *fp );
//�ص���������,�ſմ���
static int mpegsizecallback(BNAV_Indexer_Handle handle, unsigned long *hi, unsigned long *lo);
//֡������Ϣ�ص�����
static int frame_parser_ondata( const void *p_bfr, unsigned long entrysize, unsigned entrynum, void *handle );
//����ʱ��ȡ��ǰTS��������λ��
extern uint64_t tsinder_get_currentpos( sTsIndexer * const p_tsi );

//��ʼ��
int sw_tsfragment_init( )
{
	printf("sw_tsfragment_init ok\n");
	return 0;
}

//�˳�
void sw_tsfragment_exit()
{
	printf("sw_tsfragment_exit ok\n");
}


HANDLE sw_tsfragment_open( char* outpath, char* m3upath, unsigned int fraginterval, unsigned int fragnum ,bool live )
{
	tsfragment_t *fragment = NULL;
	
	//����������
	if( outpath == NULL || live == false || fragnum  == 0 )
	{
		printf("[sw_tsfragment_open] invalid parameter input live = %d\n",live);
		return NULL;
	}
	if( strlen( outpath ) >= sizeof(fragment->output->filepath))
	{
		printf("[sw_tsfragment_open] input path is too deep, large than %d\n",sizeof(fragment->output->filepath));
		return NULL;
	}
	//����һ���� 
	fragment = (tsfragment_t*)malloc( sizeof(tsfragment_t));
	//û��ָ��m3u8�ļ�·��,���úͷ�Ƭ�ļ�һ��
	if( m3upath == NULL )
		m3upath = outpath;
	
	if( fragment )
	{
		memset( fragment,0,sizeof( tsfragment_t ));
		fragment->output = malloc(sizeof(outputinfo_t));
		if( fragment->output )
		{
			memset( fragment->output,0,sizeof(outputinfo_t));
			strncpy( fragment->output->filepath,outpath,sizeof(fragment->output->filepath)-1 );
			strncpy( fragment->output->m3upath,m3upath,sizeof(fragment->output->m3upath)-1 );
			fragment->output->fraginterval = fraginterval*1000; //ms
			fragment->output->fragnum = fragnum;
			fragment->output->islive = live;
		}
		else
		{
			printf("[sw_tsfragment_open] malloc output failed\n");
			goto OPEN_FAIL;
		}
		fragment->prebuf = malloc(MAX_PREBUF_SIZE);
		if( fragment->prebuf )
		{
			memset( fragment->prebuf,0,MAX_PREBUF_SIZE );
		}
		else
		{
			printf("[sw_tsfragment_open] malloc prebuf failed\n");
			goto OPEN_FAIL;
		}
		fragment->output->durnation = (unsigned int*)malloc( sizeof(int)*(fragnum+1) );
		if( fragment->output->durnation )
		{
			memset( fragment->output->durnation,0,sizeof(int)*(fragnum+1) );
		}
		else
		{
			printf("[sw_tsfragment_open] malloc durnation failed\n");
			goto OPEN_FAIL;
		}
	}
	fragment->last_iframe_pts = -1;
	fragment->last_frame_pts = -1;
	return (HANDLE)fragment;
OPEN_FAIL:
	if( fragment->output )
		free( fragment->output );
	if( fragment->prebuf )
		free( fragment->prebuf );
	if( fragment->output->durnation )
		free( fragment->output->durnation );
	free( fragment );
	return NULL;
}

/** 
 * @brief �ر�һ·TS����Ƭ������
 * @param hfragment ��Ƭ���������
 * @return ��
 */
void sw_tsfragment_close( HANDLE hfragment )
{
	tsfragment_t* fragment = (tsfragment_t*)hfragment;
	if( fragment )
	{
		if( fragment->output->tsfp )
			fclose (fragment->output->tsfp);
		if( fragment->output->m3ufp )	
			fclose (fragment->output->m3ufp);
		if( fragment->output )
			free( fragment->output );
		if( fragment->prebuf )
			free( fragment->prebuf );
		if( fragment->output->durnation )
			free( fragment->output->durnation );
		tsparser_close( &fragment->parser );
		free( fragment );
	}
}

//���ݴ���
int sw_tsfragment_ondata( HANDLE hfragment,unsigned char* data, unsigned int size )
{
	int ret = 0;
	tsfragment_t* fragment = (tsfragment_t*)hfragment;
	if( fragment == NULL )
		return size;
	//��Ҫ�ȷ���������Ϣ
	if( fragment->parser.videopid == 0 )
	{
		parser_stream( fragment,data,size );
		//û�з�����������Ϣ,��������
		if( fragment->parser.videopid <=0 )
			return 0;
		//��������Ƶ��Ϣ	
		{
			//Create bcmindexer
			BNAV_Indexer_Settings settings;
			BNAV_Indexer_GetDefaultSettings(&settings);
			settings.writeCallback = (INDEX_WRITE_CB)frame_parser_ondata;
			settings.filePointer = (void*)fragment;
			settings.navVersion = BNAV_VersionLatest;
			settings.transportTimestampEnabled = 0;
			settings.simulatedFrameRate = 30;
			settings.mpegSizeCallback = mpegsizecallback;
			//H.264 AVC
			if (fragment->parser.video_type[0] == 0x1B)
			{
				settings.videoFormat = BNAV_Indexer_VideoFormat_AVC;
				settings.sctVersion = BSCT_Version6wordEntry;
				settings.navVersion = BNAV_Version_AVC;
			}
			//AVS 
			else if (fragment->parser.video_type[0] == 0x42)
				settings.videoFormat = BNAV_Indexer_VideoFormat_AVS;
			//MPEG2
			else
				settings.videoFormat = BNAV_Indexer_VideoFormat_MPEG2;
			
			if ( BNAV_Indexer_Open(&fragment->bcmindexer, &settings))
			{
				printf("BNAV_Indexer_Open failed, please check\n");
				return -1;
			}
			
			//Create TS Indexer 
			{
				tsindex_settings settings;
				tsindex_settings_init(&settings);
				settings.pid = fragment->parser.video_pid[0];
				settings.cb = (INDEX_WRITE_CB)feed2bcmindexer;
				settings.fp = (void*)fragment->bcmindexer;
				//H.264 AVC
				if (fragment->parser.video_type[0] == 0x1B)
				{
					settings.start_code_lo = 0x00;
					settings.start_code_hi = 0xFF;
					settings.is_avc = 1;
					settings.entry_size = 6; 
				}
				else 
					settings.entry_size = 4;
				fragment->indexer = tsindex_allocate_ex(&settings);
			}
		}
		//��������������
		if( fragment->presize > 0 )
		{
			fragment->datapos = fragment->presize;
			ret = tsindex_feed( fragment->indexer,fragment->prebuf, fragment->presize );
			if( ret == -1 )
			{
				fragment->datapos = tsinder_get_currentpos( fragment->indexer );
				fragment->presize = tsinder_get_currentpos( fragment->indexer );
			}
		}
		return 0;
	}
	
	if( fragment->presize + size < MAX_PREBUF_SIZE )
	{
		memcpy( fragment->prebuf+fragment->presize,data,size );
		fragment->presize += size;
	}
	else
	{
		uint32_t writedatasize = 0;
		if( fragment->output->tsfp )
		{
			//	printf("!!!sw_tsfragment_ondata prebuffer is full !!!,write data to file\n");
				writedatasize = fragment->presize/188*188;
				if( fragment->prebuf[0] != 0x47 )
					printf("[sw_tsfragment_ondata]ts data is not sync,please check it\n");
				fwrite( fragment->prebuf,1,writedatasize,fragment->output->tsfp);
				fragment->presize = fragment->presize-writedatasize;
				memmove( fragment->prebuf,fragment->prebuf+writedatasize,fragment->presize );
				memcpy( fragment->prebuf+fragment->presize,data,size );
				fragment->presize += size;
				fragment->filepos = fragment->filepos+writedatasize;
		}
		else
		{
			//printf("sw_tsfragment_ondata prebuffer is full !!!,Reset it\n",
			//	fragment->presize+size,MAX_PREBUF_SIZE,size);
			memcpy( fragment->prebuf,data,size );
			fragment->presize = size;
		}
	}
	
	if( fragment->indexer )
	{
		fragment->datapos += size;
		ret = tsindex_feed( fragment->indexer,data, size );
		if( ret == -1 )
		{
			/*
			FILE *fp = fopen("/home/king/1.bin","wb");
			fwrite(data,1,size,fp);
			fclose(fp);
			*/
			size -= fragment->datapos-tsinder_get_currentpos( fragment->indexer );
			printf("TS data maybe incorrect %lld->%lld,%d\n",fragment->datapos, tsinder_get_currentpos( fragment->indexer ),size);
			//��������Ч����
			fragment->presize -= fragment->datapos-tsinder_get_currentpos( fragment->indexer );
			fragment->datapos = tsinder_get_currentpos( fragment->indexer );
		}
	}
	return 0;
}

/** 
 * @brief �������
 * @param hfragment ��Ƭ���������
 * @return ��
 */
void sw_tsfragment_flush( HANDLE hfragment )
{
	
}

//��������
static void parser_stream( tsfragment_t* fragment, unsigned char* buffer, int size )
{
	int i = 0, n = 0;
	//�ϴη����������в���
    if( fragment->left_size >0 && buffer[TS_PACKET_SIZE-fragment->left_size] == 0x47 )
    {
        memcpy(fragment->left_buf+fragment->left_size, buffer, TS_PACKET_SIZE-fragment->left_size);
        tsparser_on_data(&fragment->parser, fragment->left_buf, TS_PACKET_SIZE);
        i = TS_PACKET_SIZE-fragment->left_size;
        fragment->left_size = 0;
    }
    
    //����TS SYNC Header
    for( ;i<size; i++ )
    {
        if( *(buffer+i) == 0x47 )
        {
            for( n=i; n<size; n += TS_PACKET_SIZE )
            {
                if( *(buffer+n) != 0x47 )
                    break;
            }
            if( n >= size )
                break;
        }
    }
	//����TS��
    for(;i<n;i+=TS_PACKET_SIZE)
    {
        if( i+TS_PACKET_SIZE <= size )
        {
            fragment->left_size = 0;
            if( tsparser_on_data(&fragment->parser,buffer+i,TS_PACKET_SIZE) == 0 )
               	break;
        }
        else
        {
            fragment->left_size = size-i;
            memcpy( fragment->left_buf, buffer+i, fragment->left_size );
        }
    }
    //��Ԥ���������ݻ�������
    if( fragment->presize+size < MAX_PREBUF_SIZE )
	{
		memcpy( fragment->prebuf+fragment->presize,buffer,size );
		fragment->presize += size;
	}
	else
	{
		printf("Warning, Prebuffer is full, Reset it\n");
		memcpy( fragment->prebuf,buffer,size );
		fragment->presize = size;
	}
}

static int mpegsizecallback(BNAV_Indexer_Handle handle, unsigned long *hi, unsigned long *lo)
{
	//do nothing	
	return 0;
}

static unsigned long feed2bcmindexer( const void *p_bfr, unsigned long numEntries, unsigned long entrySize,void *fp )
{
	entrySize = entrySize;
	return BNAV_Indexer_Feed((BNAV_Indexer_Handle)fp, (void*)p_bfr, numEntries);
}

//VOD Files
static int create_vod_files( outputinfo_t *output )
{
	return 0;
}

//LIVE FIles
static int create_live_files( outputinfo_t *output )
{
	char filepathname[1024],filename[256],*p = NULL;
	int i = 0,len = 0,seq = 0;
	if( output == NULL )
		return -1;
	memset( filename,0,sizeof(filename));
	//�رյ�ǰ�ļ�
	if( output->tsfp )
	{
		fclose (output->tsfp);
		output->tsfp = NULL;
	}
	
	//��һ�δ���,��Ҫ����index.m3u8�ļ�
	if( output->curnum == 0 )
	{
		p = strrchr( output->m3upath,'/');
		if( p )
		{
			memset( filepathname,0,sizeof(filepathname));
			memcpy( filepathname,output->m3upath,p-output->m3upath );
			strcat( filepathname,"/index.m3u8");
			strncpy( filename,p+1,sizeof(filename)-1 ); 
		}
		else
		{
			sprintf( filepathname,"%s","index.m3u8");
			strncpy( filename,output->m3upath,sizeof(filename)-1 ); 
		}
		printf( "M3u8 filepathname %s\n",filepathname);
		output->m3ufp = fopen( filepathname,"wb");
		if( output->m3ufp == NULL )
		{
			printf("fragment_create_tsfile: create file :%s failed\n",filepathname);
			return -1;
		}
		memset( filepathname,0,sizeof(filepathname));
		sprintf(filepathname,
			"#EXTM3U\n#EXT-X-VERSION:1\n#EXT-X-STREAM-INF:PROGRAM-ID=1,BANDWIDTH=915936\n%s.m3u8\n",
		filename);
		fwrite( filepathname,1,strlen(filepathname),output->m3ufp );
		fclose( output->m3ufp );
		output->m3ufp = NULL;
	}
	
	memset(filepathname,0,sizeof(filepathname));
	sprintf(filepathname,"%s-%d.ts",output->filepath,++output->curnum);
	output->tsfp = fopen( filepathname,"wb");
	if( output->tsfp == NULL )
	{
		printf("fragment_create_tsfile: create file :%s failed\n",filepathname);
		return -1;
	}
	//ɾ��������ļ�
	if( output->curnum > output->fragnum+1 )
	{
		memset(filepathname,0,sizeof(filepathname));
		sprintf(filepathname,"%s-%u.ts",output->filepath,output->curnum-output->fragnum-1);
		unlink(filepathname);
	}
	memset(filepathname,0,sizeof(filepathname));
	//�ӵڶ����ļ���ʼ,����m3u8�ļ�
	if( output->curnum >=2 )
	{
		//����m3u8�ļ�
		sprintf(filepathname,"%s.m3u8",output->m3upath);
		output->m3ufp = fopen( filepathname,"wb");
		if( output->m3ufp == NULL )
		{
			printf("fragment_create_tsfile: create file :%s failed\n",filepathname);
			return -1;
		}
		memset(filepathname,0,sizeof(filepathname));
		if( output->curnum > output->fragnum+1 )
			seq = output->curnum-output->fragnum;
		else
			seq = 1;
		//����û��������ж�,�趨m3u8�ļ�С��1K
		len = sprintf(filepathname,
			"#EXTM3U\n#EXT-X-TARGETDURATION:%d\n#EXT-X-MEDIA-SEQUENCE:%d\n",
				output->fraginterval/1000 ,seq);
		p = strrchr( output->filepath,'/');
		if( p ) 
//huasheng			p = p++;
			p = p+1;
		else
			p = output->filepath;
		//��¼�ļ�,ֻ������ķ�Ƭ�Ŵ���
		for( i = 0;i<output->fragnum;i++ )
		{
			if( !output->durnation[i] )
				break;
			if( output->curnum > output->fragnum+1 )
				seq = output->curnum-output->fragnum + i;
			else
				seq = i + 1;
			len += sprintf( filepathname+strlen(filepathname),
					"#EXTINF:%d\n%s-%u.ts\n",output->durnation[i],p,seq );
		}
		fwrite( filepathname,1,len,output->m3ufp );
		fclose( output->m3ufp );
		output->m3ufp = NULL;
	}
	return 0;
}
//����TS��Ƭ�ļ�,����M3u8�ļ�
static int fragment_create_tsfile( outputinfo_t *output )
{
	if( output->islive )
		return create_live_files( output );
	return create_vod_files(output);
}

static int frame_parser_ondata( const void *p_bfr, unsigned long entrysize, unsigned entrynum, void *handle )
{
	tsfragment_t* fragment = (tsfragment_t*)handle;
	unsigned int *words = (unsigned int *)p_bfr;
	uint32_t ontime = 0,writedatasize = 0;
	int64_t pts = 0,frameoffset = 0;
	//printf("111111@@@@@@@offset %lld,pts %d, type %d\n",get_frameOffset(words),get_framePts( words ),get_frameType( words ));
	//û���ҵ���һ��I Frame,��������
	if( fragment->last_iframe_pts == -1 && get_frameType( words ) != eSCTypeIFrame )
		return 0;
	pts = get_framePts( words );
	//PTS��ͬ��������
	if( fragment->last_frame_pts == get_framePts( words ) )
		return 0;
	if( fragment->last_frame_pts == -1 )
	    fragment->last_frame_pts = pts;
	//PTS �����������ƫת
	if( (fragment->last_frame_pts+3*1000*45 < pts ) || 
		(fragment->last_frame_pts-3*1000*45 > pts) )
	{
		printf("frame_parser_ondata video pts has  jumped last %lld-%lld\n",fragment->last_frame_pts,pts);
		fragment->is_ptsjumped = true;
	}
	
	if( fragment->is_ptsjumped )
		fragment->timediff = fragment->timediff + 40;
	else
		fragment->timediff = (pts-fragment->last_iframe_pts)/45;
	fragment->last_frame_pts = get_framePts( words );
	//���ʱ���Ƭ�Ƿ���
	if( fragment->timediff >= fragment->output->fraginterval )
		ontime = 1;
	if( get_frameType( words ) == eSCTypeIFrame )
	{
		//��һ��I֡
		if( fragment->last_iframe_pts == -1 )
		{
			if( fragment_create_tsfile( fragment->output ))
				return 0;
			//д��PAT,PMT
			fwrite( fragment->parser.pat,1,sizeof( fragment->parser.pat ),fragment->output->tsfp );
			fwrite( fragment->parser.pmt,1,sizeof(fragment->parser.pmt ),fragment->output->tsfp );
			fragment->filepos = get_frameOffset(words);
			//frameOffset��ָ����Ƶ��start code [00 00 01 xx],������ָ��TS���Ŀ�ʼ
			//��ǰ����һ��TS��
			fragment->filepos = fragment->filepos/188*188;
			//������I֡������
			memmove( fragment->prebuf,fragment->prebuf+fragment->filepos,fragment->datapos-fragment->filepos );
			fragment->presize = fragment->datapos-fragment->filepos;
			fragment->last_iframe_pts = get_framePts( words );
			fragment->is_ptsjumped = false;
		}
		else
		{
			frameoffset = get_frameOffset(words);
			frameoffset = frameoffset/188*188;
			//prebuf��������ʱ��,���ǻ��Ȱ�����д���ļ���,�����ͻ�����ļ�λ�������frameoffset
			//�����
			if( frameoffset>fragment->filepos )
				writedatasize = frameoffset-fragment->filepos;
			else
			{
				writedatasize = 0;
			}

			if( writedatasize>0 )
			{
				if( fragment->output->tsfp )
				{
					if( writedatasize <= fragment->presize )
					{
						fwrite( fragment->prebuf,1,writedatasize,fragment->output->tsfp);
						if( fragment->prebuf[0] != 0x47 )
						{
							//printf("write data 0x%x,0x%x,0x%x,0x%x,%lld,%lld\n",
							///fragment->prebuf[0],fragment->prebuf[1],fragment->prebuf[2],fragment->prebuf[3],
							//frameoffset,fragment->filepos,frameoffset);
								printf("[frame_parser_ondata]ts data is not sync,please check it\n");
						}
					}
					else
						printf("[frame_parser_ondata] invalid data size %d,%d\n",writedatasize,fragment->presize);
				}
				//��¼�µ��ļ�λ��
				fragment->filepos = frameoffset;
				//��û��д���������ǰ��
				memmove( fragment->prebuf,fragment->prebuf+writedatasize,fragment->datapos-fragment->filepos );
				if( fragment->prebuf[0] != 0x47 )
				{
						printf("write data 0x%x,0x%x,0x%x,0x%x,0x%x,0x%x\n",
						fragment->prebuf[0],fragment->prebuf[1],fragment->prebuf[2],fragment->prebuf[3],
						fragment->prebuf[4],fragment->prebuf[5]);
						printf("info offset %lld, filepos %lld, datapos %lld,presize %d,writedatasize %d\n",frameoffset,fragment->filepos,fragment->datapos
						,fragment->presize,writedatasize);
						exit(0);
				}
				fragment->presize = fragment->datapos-fragment->filepos;
				//��Ҫ�����µķ�Ƭ
				if( ontime == 1 )
				{
					//wrapped
					if( fragment->output->curindex+1==fragment->output->fragnum )
					{
						int x = 0,tmp = 0;
						for( x = 0; x<fragment->output->fragnum-1;x++)
						{
								fragment->output->durnation[x] = fragment->output->durnation[x+1]; 		
						}
					}
					else
						fragment->output->curindex++;
					//��Ƭʱ�䳤��,������������ķ���
					fragment->output->durnation[fragment->output->curindex] = 
						fragment->timediff/1000+(fragment->timediff%1000)*2/1000;
					if( fragment_create_tsfile( fragment->output ))
						return 0;
					fragment->last_iframe_pts = get_framePts( words );
					fragment->is_ptsjumped = false;
					//д��PAT,PMT
					fwrite( fragment->parser.pat,1,sizeof( fragment->parser.pat ),fragment->output->tsfp );
					fwrite( fragment->parser.pmt,1,sizeof(fragment->parser.pmt ),fragment->output->tsfp );
				}
			}
		}
	}
	return 0;
}
