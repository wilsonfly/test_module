#include "bvlc.h"

#include <stdint.h>

/**
Advance both bit and index by one through the byte array
**/
#define ADVANCE(bit, index) \
	do {if (bit) {(bit)--;} else {(index)++;(bit)=7;} } while (0)

static int b_vlc_measure_prefix(const uint8_t *data,unsigned size,unsigned index,unsigned current_bit, 
	unsigned *next_index,unsigned *next_bit,unsigned *prefix_length)
{
	int bit = current_bit;
	int done = 0;
		
	if (bit > 7) {
		/*printf("Invalid bit. Must be 0..7.\n");*/
		return -1;
	}
	
	*prefix_length = 0;
	
	/* count 0's to determine prefix_length */
	for (; index < size; index++) {
		while (bit >= 0 && !done) {
			if (data[index] & (0x1 << bit))
				done = 1;
			else {
				(*prefix_length)++;
				bit--;
			}
		}
		if (done) 
			break;
		bit = 7;
	}
	/* make sure we have enough data */
	if (*prefix_length > (size * 8)/2-1) {
		/*printf("not enough data sent for this vlc value\n");*/
		return -1;
	}
	
	*next_index = index;
	*next_bit = bit;
	return 0;
}

int b_vlc_skip(const uint8_t *data,unsigned size, unsigned current_index, unsigned current_bit, 
	unsigned *next_index,unsigned *next_bit)
{
	unsigned prefix_length;
	
	if (b_vlc_measure_prefix(data, size, current_index, current_bit, next_index, next_bit, &prefix_length))
		return -1;

#if 1
	/* Optimization: use integer math to advance by prefix_length + 1 */
	prefix_length++; /* take into account the middle 1 */
	if (prefix_length <= *next_bit)
		*next_bit -= prefix_length;
	else {
		prefix_length -= *next_bit + 1;
		*next_index += 1 + prefix_length/8;
		*next_bit = 7 - (prefix_length % 8);
	}
#else
	/* advance one bit at a time */
	/* skip the middle 1 */
	ADVANCE(*next_bit, *next_index);
	
	/* skip the suffix - measure_prefix has already guaranteed we have enough data */
	while (prefix_length--)
		ADVANCE(*next_bit, *next_index);
#endif
		
	return 0;
}

int b_vlc_decode(const uint8_t *data,unsigned size,unsigned current_index,unsigned current_bit, 
	unsigned *next_index,unsigned *next_bit)
{
	unsigned index;
	int bit;
	unsigned suffix_length, prefix_length;
	unsigned value;
	uint64_t suffix;
		
	/*printf("vlc: %02x%02x %d, bit %d\n", data[current_index], (size>current_index+1)?data[current_index+1]:0, size, current_bit);*/

	/* find the first 1, which determines prefix_length */
	if (b_vlc_measure_prefix(data, size, current_index, current_bit, &index, (unsigned*)&bit, &prefix_length))
		return -1;
	
	if (prefix_length > 64) {
		/*printf("vlc value too large for this algorithm\n");*/
		/* If you hit this, rework the algorithm. I'm assuming I can load the
		entire suffix into a primitive datatype. */
		return -1;
	}
	
	/* advance past middle 1 */
	ADVANCE(bit, index);
	
	/* get suffix based on prefix_length */
	
	/* Optimization: no prefix, no suffix, value is 0 */
	if (!prefix_length) {
		value = 0;
		/*printf("  prefix len 0, done\n");*/
	}
	else {
		/* Optimization: if the suffix is completely contained in this byte, we 
		don't have to operate bitwise */
		if (prefix_length <= 8 && (int)prefix_length <= bit+1) {
			static unsigned char mask[] = {0x0,0x01,0x03,0x07,0x0F,0x1F,0x3F,0x7F,0xFF};
			suffix = (data[index] >> (bit-(prefix_length-1))) & mask[prefix_length];
			/*printf("  prefix len %d, suffix (in byte) val %x\n", prefix_length, (int)suffix);*/
			bit -= prefix_length;
			if (bit == -1) {
				bit = 7;
				index++;
			}
		}
		else {
			/* step through it bit by bit. this is the most general way and will
			work with any value. */
			suffix = 0;
			/*printf("  prefix len %d, index %d bit %d\n", prefix_length, index, bit);*/
			for (suffix_length = 0; suffix_length < prefix_length; suffix_length++) {
				suffix <<= 1;
				if (data[index] & (0x1 << bit))
					suffix |= 1;
				ADVANCE(bit, index);
			}
			/*printf("  prefix len %d, suffix val %x\n", prefix_length, (int)suffix);*/
		}
	
		/* now do the final calculation: 2^prefix_length - 1 + suffix */
		value = 1;
		while (prefix_length--) value *= 2;
		value = value - 1 + suffix;
	}

	/* move to the next bit so that subsequent calls to b_vld_decode are easy
	to make for adjacent values. */
	if (next_index) *next_index = index;
	if (next_bit) *next_bit = bit;
		
	/*printf("  result = %d (%d, %d)\n", value, index, bit);*/
	return value;
}

#if 0
/* The VLC algorithm is complicated, and probably should be optimized in the
future. This routine helps test it. Please leave it in the code for reference. */
#define BDBG_ASSERT assert
#include <assert.h>

#define ERROR() do{BDBG_ERR(("Error on line %d", __LINE__)); return -1;}while (0)

int test(unsigned char byte0, unsigned char byte1, unsigned char byte2,
	int size, int test_val, int test_next_index, int test_next_bit)
{
	char buf[3] = {byte0, byte1, byte2};
	int val;
	unsigned next_index, next_bit;
	
	next_index = 0; next_bit = 7;
	val = b_vlc_decode(buf, size, next_index, next_bit, &next_index, &next_bit);
	if (val != test_val) ERROR();
	if (next_index != test_next_index) ERROR();
	if (next_bit != test_next_bit) ERROR();

	next_index = 0; next_bit = 7;
	b_vlc_skip(buf, size, next_index, next_bit, &next_index, &next_bit);
	if (next_index != test_next_index) ERROR();
	if (next_bit != test_next_bit) ERROR();
	
	return 0;
}

int main()
{
	char buf[10];
	int val;
	unsigned next_index, next_bit;

	test(0x80, 0x00, 0x00, 1, 		0, 0, 6);
	test(0x40, 0x00, 0x00, 1, 		1, 4, 0);
	test(0x60, 0x00, 0x00, 1, 		2, 0, 4);
	test(0x20, 0x00, 0x00, 1, 		3, 0, 2);
	test(0x28, 0x00, 0x00, 1, 		4, 0, 2);
	test(0x14, 0x00, 0x00, 1, 		9, 0, 0);
	test(0x05, 0x40, 0x00, 2, 		41, 1, 4);
	test(0x01, 0x40, 0x00, 2, 		158, 1, 1);
	test(0x01, 0xFF, 0x00, 2, 		254, 1, 0);
	test(0x00, 0x20, 0x00, 3, 		1023, 2, 2);
	
	buf[0] = 0xf4; /* skip,skip,skip,skip, 010 */
	next_index = 0; next_bit = 7;
	b_vlc_skip(buf, 1, next_index, next_bit, &next_index, &next_bit);
	BDBG_ASSERT(next_bit == 6);
	b_vlc_skip(buf, 1, next_index, next_bit, &next_index, &next_bit);
	BDBG_ASSERT(next_bit == 5);
	b_vlc_skip(buf, 1, next_index, next_bit, &next_index, &next_bit);
	BDBG_ASSERT(next_bit == 4);
	b_vlc_skip(buf, 1, next_index, next_bit, &next_index, &next_bit);
	BDBG_ASSERT(next_bit == 3);
	val = b_vlc_decode(buf, 1, next_index, next_bit, &next_index, &next_bit);
	BDBG_ASSERT(val == 1);
	BDBG_ASSERT(next_index == 0);
	BDBG_ASSERT(next_bit == 0);

	buf[0] = 0xf0; /* 0, 0, 0, 0 */
	next_index = 0; next_bit = 7;
	val = b_vlc_decode(buf, 1, next_index, next_bit, &next_index, &next_bit);
	BDBG_ASSERT(val == 0);
	val = b_vlc_decode(buf, 1, next_index, next_bit, &next_index, &next_bit);
	BDBG_ASSERT(val == 0);
	val = b_vlc_decode(buf, 1, next_index, next_bit, &next_index, &next_bit);
	BDBG_ASSERT(val == 0);
	val = b_vlc_decode(buf, 1, next_index, next_bit, &next_index, &next_bit);
	BDBG_ASSERT(val == 0);
	BDBG_ASSERT(next_index == 0);
	BDBG_ASSERT(next_bit == 3);
	
	buf[0] = 0x00;
	buf[1] = 0xf0;
	buf[2] = 0xe0;
	next_index = 0; next_bit = 7;
	val = b_vlc_decode(buf, 3, next_index, next_bit, &next_index, &next_bit);
	BDBG_ASSERT(val == 480);
	val = b_vlc_decode(buf, 3, next_index, next_bit, &next_index, &next_bit);
	BDBG_ASSERT(val == 0);
	val = b_vlc_decode(buf, 3, next_index, next_bit, &next_index, &next_bit);
	BDBG_ASSERT(val == 0);
	BDBG_ASSERT(next_index == 2);
	BDBG_ASSERT(next_bit == 4);
	
	return 0;
}
#endif
