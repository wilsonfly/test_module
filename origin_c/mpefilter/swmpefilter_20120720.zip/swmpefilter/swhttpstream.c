#include "stdafx.h"
#include "swhttpserver.h"
#include "swthrd.h"
#include "swmpefilter_priv.h"
#include "swmutex.h"
#include <netinet/tcp.h>

#define MAX_HTTP_CONNECTS	4
#define MAX_CHANNELS		32
#define BUF_MEM_SIZE		(1024*1024)

//������Ϣ
typedef struct httpstream{
	//http�ͻ�����Ϣ
	SHttpConnectObj* objs[MAX_HTTP_CONNECTS];
	//�������Ӹ���
	int connectnums;
	//�����߳�
	HANDLE thrd;
	//Ƶ��ID
	char channelid[256];
	//������
	uint8_t* buf;
	//�������
	dataqueue_t* dq;
	//objs ����
	HANDLE mutex;
}httpstream_t;


//httpserver
static HANDLE m_httpserver = NULL;
//http ��������
static httpstream_t m_httpstreams[MAX_CHANNELS];


//
static int httpstream_proc( uint32_t wParam, uint32_t lParam )
{
	httpstream_t* s = (httpstream_t*)wParam;
	struct timeval timeout;
	int i = 0,ret = 0,wret = 0,maxfd = -1;
	fd_set wfds,efds,rfds;
	uint8_t *buf = NULL;
	uint32_t size = 0;
	dataqueue_get_readbuf(s->dq, &buf, &size);
	if( size <= 0 )
	{
		sw_thrd_delay(40);
		return true;
	}
	FD_ZERO( &wfds);
	FD_ZERO( &efds);
	FD_ZERO( &rfds);
	//��ѯ�ͻ�����
	for( i = 0;i<s->connectnums;i++ )
	{
		FD_SET(s->objs[i]->skt, &wfds);
		FD_SET(s->objs[i]->skt, &efds);
		FD_SET(s->objs[i]->skt, &rfds);
		if( maxfd <(int)s->objs[i]->skt )
			maxfd = s->objs[i]->skt;
	}
	//��ѯ���пͻ��˵�����
	if( maxfd > 0 )
	{
		timeout.tv_sec = 2; 
		timeout.tv_usec = 0; 
		ret = select(maxfd+1, &rfds, &wfds, &efds, &timeout);
		if( ret < s->connectnums )
		{
			//����Ƿ���һֱ���������ݵĿͻ���
			for( i = 0;i<s->connectnums;i++ )
			{
				if( !FD_ISSET(s->objs[i]->skt, &wfds) )
				{
					//����2��û�н���,�ص��ÿͻ���
					if( (sw_thrd_get_tick() - s->objs[i]->extend )>= 2000 )
					{
						int k = 0;
						printf(">>>client %d.%d.%d.%d long time to recv data\n",(int)(s->objs[i]->from_ip&0xff),
							(int)(s->objs[i]->from_ip>>8)&0xff,
							(int)(s->objs[i]->from_ip>>16)&0xff,
							(int)(s->objs[i]->from_ip>>24)&0xff );
						sw_httpserver_close_connectobj( s->objs[i] );
						if( s->mutex ) sw_mutex_lock( s->mutex );
						//��ǰ��
						for( k = i; k<s->connectnums-1;k++ )
						{
							s->objs[k] = s->objs[k+1]; 
						}
						i--;
						s->connectnums--;
						if( s->mutex ) sw_mutex_unlock( s->mutex );
					}
				}
				else
				{
					s->objs[i]->extend = sw_thrd_get_tick();
				}
			}
			return true;
		}

		for( i = 0;i<s->connectnums;i++ )
		{
			wret = 1;
			if (0 < ret )
			{
				if( FD_ISSET(s->objs[i]->skt, &rfds) && !FD_ISSET(s->objs[i]->skt, &efds))
				{
					wret = recv(s->objs[i]->skt, buf,size,0);
					wret = 0;
				}				
				else
				{
					if( FD_ISSET(s->objs[i]->skt, &wfds) && !FD_ISSET(s->objs[i]->skt, &efds))
					{
						s->objs[i]->extend = sw_thrd_get_tick();
						if( s->objs[i]->chunked )
						{
							char temp[16];
							char crlf[] = "\r\n";
							snprintf(temp, sizeof(temp), "%x\r\n", dq_payload_size(buf));
							wret = send(s->objs[i]->skt, temp, strlen(temp),0);
							if( wret > 0 )
								wret = send(s->objs[i]->skt, buf+dq_payload_offset(buf),
										dq_payload_size(buf),0);
							if( wret >0 )
								wret = send(s->objs[i]->skt, crlf, 2,0);
						}
						else
							wret = send(s->objs[i]->skt, buf+dq_payload_offset(buf), dq_payload_size(buf),0);
					}
				}
				
			}
			//��������
			if ( wret <= 0 || FD_ISSET(s->objs[i]->skt, &efds))
			{
				int z = 0;
				printf("send error info:%s %d\n",strerror(errno),wret );
				printf("client %d.%d.%d.%d has been leaved\n",(int)(s->objs[i]->from_ip&0xff),
				(int)(s->objs[i]->from_ip>>8)&0xff,
				(int)(s->objs[i]->from_ip>>16)&0xff,
				(int)(s->objs[i]->from_ip>>24)&0xff );
				sw_httpserver_close_connectobj( s->objs[i] );
				if( s->mutex ) sw_mutex_lock( s->mutex );
				//��ǰ��
				for( z = i; z<s->connectnums-1;z++ )
				{
					s->objs[z] = s->objs[z+1]; 
				}
				i--;
				s->connectnums--;
				if( s->mutex ) sw_mutex_unlock( s->mutex );
			}	
		}
	}
	dataqueue_read_complete( s->dq, buf );
	return true; 
}

static int httpsever_callback( SHttpConnectObj* obj, uint32_t wParam )
{
	char *p = NULL;
	httpstream_t* s = NULL;
	if( sw_httpserver_recv_request_header( obj,2000 )<= 0 )
	{
		sw_httpserver_close_connectobj( obj );
		return -1;
	}
	if( strcmp( obj->request_header.method,"GET" ) )
	{
		sw_httpserver_send_response_header( obj,HTTP_NOT_IMPLEMENTED,NULL,NULL,"close",0,-1 );
		sw_httpserver_close_connectobj( obj );
		return -1;
	}
	printf("Request Url %s\n",obj->request_header.request_url);
	p = strrchr( obj->request_header.request_url, '/' );
	if( p )
	{
		int i = 0, j = 0;
		p++;
		//��ѯ����Ƶ���Ƿ�Ϸ�
		for( ;m_httpstreams[i].channelid;i++ )
		{
			if( !strncasecmp(p,m_httpstreams[i].channelid,strlen(m_httpstreams[i].channelid) ) )
			{
				break;
			}
		}
		//���뵽Ƶ�������߳�
		if( m_httpstreams[i].dq )
		{
			int idx = -1,z = 0;
			if( m_httpstreams[i].mutex ) sw_mutex_lock( m_httpstreams[i].mutex );
			if( m_httpstreams[i].connectnums<MAX_HTTP_CONNECTS )
			{
				sw_httpserver_send_response_header( obj,HTTP_OK,"video/mpeg",NULL,"close",-1,-1 );
				//sw_httpserver_send_response_header( obj,HTTP_OK,"video/mpeg",NULL,"close",0x7ffffffe,-1 );
				obj->extend = sw_thrd_get_tick();
				m_httpstreams[i].objs[m_httpstreams[i].connectnums] = obj;
				m_httpstreams[i].connectnums++;
			}
			else
			{
				sw_httpserver_send_response_header( obj,HTTP_INTERNAL_SERVER_ERROR,NULL,NULL,"close",0,-1 );
				sw_httpserver_close_connectobj( obj );
			}
			if( m_httpstreams[i].mutex ) sw_mutex_unlock( m_httpstreams[i].mutex );
			return 0;
		}
	}
	sw_httpserver_send_response_header( obj,HTTP_NOT_FOUND,NULL,NULL,"close",0,-1 );
	sw_httpserver_close_connectobj( obj );
	return 0;
}


int sw_httpstream_init( unsigned long ip,  unsigned short port )
{
	int  i = 0;
	//ignore pipe error
	sigset_t signal_mask;
	sigemptyset (&signal_mask);
	sigaddset (&signal_mask, SIGPIPE);
	pthread_sigmask (SIG_BLOCK, &signal_mask, NULL);
	memset( &m_httpstreams,0,sizeof(m_httpstreams));
	//����һhttp������
	m_httpserver = sw_httpserver_open( ip,htons(port),httpsever_callback,0 );
	if( m_httpserver == NULL )
		printf("open httpserver failed\n");
	return 0;
}


void sw_httpstream_deinit()
{
	if( m_httpserver )
	{
		sw_httpserver_close( m_httpserver );
		m_httpserver = NULL;
	}
}

//
HANDLE sw_httpstream_open( char* channelid )
{
	int i = 0;
	char thrdname[64];
	for( i =0 ;i<MAX_CHANNELS;i++ )
	{
		if( m_httpstreams[i].dq == NULL )
		{
			memset( m_httpstreams[i].channelid,0,sizeof(m_httpstreams[i].channelid) );
			strncpy( m_httpstreams[i].channelid,channelid,sizeof(m_httpstreams[i].channelid)-1 );
			m_httpstreams[i].buf =  malloc( BUF_MEM_SIZE );
			if( m_httpstreams[i].buf == NULL )
			{
				printf("No enough Memory\n");
				break;
			}
			sprintf(thrdname,"HttpStream%d",i);
			memset(m_httpstreams[i].buf,0,BUF_MEM_SIZE);
			m_httpstreams[i].mutex = sw_mutex_create();
			m_httpstreams[i].dq = dataqueue_create( m_httpstreams[i].buf,BUF_MEM_SIZE );
			m_httpstreams[i].thrd = sw_thrd_open( thrdname, 80, 0, 16384, (PThreadHandler)httpstream_proc, (unsigned long)&m_httpstreams[i], 0 );
			sw_thrd_resume(m_httpstreams[i].thrd);
			return &m_httpstreams[i];
		}
	}
	return NULL;
}


HANDLE sw_httpstream_close( HANDLE h )
{
	int i = 0;
	httpstream_t* s = (httpstream_t*)h;
	if( s )
	{
		if( s->thrd ) 
		{
			sw_thrd_close(s->thrd,5000);
			s->thrd = NULL;
		}
		if( s->dq ) 
		{
			dataqueue_destory(s->dq);
			s->dq = NULL;
		}
		if( s->mutex ) 
		{
			sw_mutex_destroy(s->mutex);	
			s->mutex = NULL;
		}
		if( s->buf ) 
		{
			free(s->buf);
			s->buf = NULL;
		}
	}
	return 0;
}

int sw_httpstream_ondata( HANDLE h, uint8_t *buf, int size )
{
	httpstream_t* s = (httpstream_t*)h;
	uint8_t *databuf = NULL;
	int datasize = size;
	if( s )
	{
			dataqueue_get_writebuf(s->dq,0,&databuf,&datasize);
			if( databuf && datasize>=size)
			{
				memcpy(databuf,(char*)buf,size);
			}
			else
			{
				printf("########################queue maybe full\n");
				return 0;
			}
			dataqueue_write_complete(s->dq,0,0,databuf,size,0);	
	}
	return 0;
}
