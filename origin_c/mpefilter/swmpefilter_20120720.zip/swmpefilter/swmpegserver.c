#include "stdafx.h"
#include "swhttpserver.h"
#include "swthrd.h"
#include "swmutex.h"

#define MAX_HTTP_CONNECTS	32
#define MAX_CHANNELS		32
//Ƶ����Ϣ
static struct channelinfo{
	char *udpaddr;
	unsigned short port;
	char* channelname;
}m_channels[] = {
	{"192.168.1.99",3333,"cctv1.ts" },
	{"192.168.1.99",3334,"cctv2.ts" },
	{"233.3.3.3",3335,"cctv3.ts" },
	{NULL,0,NULL}
};

//������Ϣ
typedef struct mpegsrv{
	SHttpConnectObj* objs[MAX_HTTP_CONNECTS];
	int connectnums;
	HANDLE thrd;
	int skt; 
	int maxfd;
	struct channelinfo *info;
}mpegsrv_t;

//httpserver
static HANDLE m_httpserver = NULL;
//http ��������
static mpegsrv_t m_chnlservers[MAX_CHANNELS];
static HANDLE m_mutex = NULL;

static int setup_network( unsigned int ip, unsigned short port )
{
	int skt,reuse = 1;
	struct sockaddr_in local; 
	struct ip_mreqn mreq; 
	skt = socket(AF_INET, SOCK_DGRAM, 0);
	memset(&local, 0, sizeof(local)); 
	local.sin_family = AF_INET; 
	local.sin_addr.s_addr = ip;
	local.sin_port = htons(port); 	
	 
	if (setsockopt(skt, SOL_SOCKET, SO_REUSEADDR, (char *)&reuse, sizeof(reuse)) != 0)
	{
		printf("[setup_network]SO_REUSEADDR failed! \n");
		close(skt);
		return -1;
	}
	if (bind(skt, (struct sockaddr *)&local, sizeof(local)) == SOCKET_ERROR)
	{
		printf("[setup_network]bind failed!\n");
		close(skt);
		return -1;
	}
	if( (ip&0xff) >= 0xE0 && (ip&0xff) < 0xF0 )
	{
		memset(&mreq, 0, sizeof(mreq)); 
		mreq.imr_multiaddr.s_addr = ip; 
		mreq.imr_address.s_addr = 0;
		mreq.imr_ifindex = 0;
		if (setsockopt(skt, IPPROTO_IP, IP_ADD_MEMBERSHIP, (char*)&mreq, sizeof(mreq)) < 0)
		{
			printf("[setup_network]add multicast group failed!\n");
			close(skt);
			return -1;
		}
	}
	return skt;
}


static int request_proc( uint32_t wParam, uint32_t lParam )
{
	mpegsrv_t* s = (mpegsrv_t*)wParam;
	struct timeval timeout;
	unsigned char tsdata[1504];
	int recvlen = 0,i = 0,ret = 0,wret = 0;
	fd_set rfd; 
	fd_set efd;  
	struct sockaddr_in from; 
	uint32_t slen = sizeof(from);
	memset(&from, 0, sizeof(from));
	timeout.tv_sec = 0; 
	timeout.tv_usec =300*1000; 
	FD_ZERO(&rfd); 
	FD_ZERO(&efd);
	FD_SET(s->skt, &rfd); 
	FD_SET(s->skt, &efd); 
	if (select(s->skt+1, &rfd, NULL, &efd, &timeout)> 0)
	{
		fd_set wfds,efds;
		recvlen = recvfrom(s->skt, tsdata,sizeof(tsdata) , 0, (struct sockaddr *)&from, &slen); 
		FD_ZERO(&wfds);
		FD_ZERO(&efds);
		for( i = 0;i<s->connectnums;i++ )
		{
			FD_SET(s->objs[i]->skt, &wfds);
			FD_SET(s->objs[i]->skt, &efds);
			if( s->maxfd <s->objs[i]->skt )
				s->maxfd = s->objs[i]->skt;
		}
		timeout.tv_sec = 0; 
		timeout.tv_usec =300*1000; 
		ret = select(s->maxfd+1, NULL, &wfds, &efds, &timeout);
		for( i = 0;i<s->connectnums;i++ )
		{
			wret = 1;
			if (0 < ret && FD_ISSET(s->objs[i]->skt, &wfds) && !FD_ISSET(s->objs[i]->skt, &efds))
			{
				if( s->objs[i]->chunked )
				{
					char temp[16];
					char crlf[] = "\r\n";
					snprintf(temp, sizeof(temp), "%x\r\n", recvlen);
					wret = send(s->objs[i]->skt, temp, strlen(temp),0);
					wret = send(s->objs[i]->skt, tsdata, recvlen,0);
					wret = send(s->objs[i]->skt, crlf, 2,0);
				}
				else
					wret = send(s->objs[i]->skt, tsdata, recvlen,0);
			}
			if ( wret <= 0 || FD_ISSET(s->objs[i]->skt, &efds))
			{
				int z = 0;
				printf("send error info:%s %d\n",strerror(errno),wret );
				printf("client %d.%d.%d.%d has been leaved\n",(int)(s->objs[i]->from_ip&0xff),
				(int)(s->objs[i]->from_ip>>8)&0xff,
				(int)(s->objs[i]->from_ip>>16)&0xff,
				(int)(s->objs[i]->from_ip>>24)&0xff );
				sw_httpserver_close_connectobj( s->objs[i] );
				if( m_mutex ) sw_mutex_lock( m_mutex );
				//��ǰ��
				for( z = i; z<s->connectnums-1;z++ )
				{
					s->objs[z] = s->objs[z+1]; 
				}
				i--;
				s->connectnums--;
				if( m_mutex ) sw_mutex_unlock( m_mutex );
				//�ͻ��˶��Ͽ���,�˳������߳�
				if( s->connectnums == 0 )
				{
					close( s->skt );
					memset( s,0,sizeof(mpegsrv_t));
					s->skt = -1;
					return false;
				}
			}	
		}
		
	}
	else
	{
		printf("recv data from(%s:%d)timeout \n",s->info->udpaddr,s->info->port);
	}
	return true; 
}

static int httpsever_callback( SHttpConnectObj* obj, uint32_t wParam )
{
	char *p = NULL;
	mpegsrv_t* s = NULL;
	if( sw_httpserver_recv_request_header( obj,2000 )<0 )
	{
		sw_httpserver_close_connectobj( obj );
		return -1;
	}

	if( strcmp( obj->request_header.method,"GET" ) )
	{
		sw_httpserver_send_response_header( obj,HTTP_NOT_IMPLEMENTED,NULL,NULL,"close",0,-1 );
		sw_httpserver_close_connectobj( obj );
		return -1;
	}
	printf("Request Url %s\n",obj->request_header.request_url);
	p = strrchr( obj->request_header.request_url, '/' );
	if( p )
	{
		int i = 0, j = 0;
		p++;
		//��ѯ����Ƶ���Ƿ�Ϸ�
		for( ;m_channels[i].channelname;i++ )
		{
			if( !strncasecmp(p,m_channels[i].channelname,strlen(m_channels[i].channelname) ) )
				break;
		}
		
		if( m_channels[i].udpaddr )
		{
			int idx = -1,z = 0;
			if( m_mutex ) sw_mutex_lock( m_mutex );
			for( j = 0;j<MAX_CHANNELS;j++ )
			{
				if( m_chnlservers[j].skt == -1 && idx == -1 )
					idx = j;
				if( m_chnlservers[j].info == &m_channels[i] )
				{
					sw_httpserver_send_response_header( obj,HTTP_OK,"video/mpeg",NULL,"close",-1,-1 );
					m_chnlservers[j].objs[m_chnlservers[j].connectnums] = obj;
					m_chnlservers[j].connectnums++;
					idx = -1;
					if( m_mutex ) sw_mutex_unlock( m_mutex );
					return 0;
				}
			}
			if( m_mutex ) sw_mutex_unlock( m_mutex );
			//�µ�Ƶ������
			if( idx  != -1 )
			{
				char thrdname[64];
				s = &m_chnlservers[idx];
				sw_httpserver_send_response_header( obj,HTTP_OK,"video/mpeg",NULL,"close",-1,-1 );
				s->objs[s->connectnums] = obj;
				s->connectnums++;
				s->info = &m_channels[i];
				s->skt = setup_network( inet_addr(m_channels[i].udpaddr), m_channels[i].port );	
				s->maxfd = obj->skt;
				sprintf(thrdname,"Request%d",idx);
				s->thrd = sw_thrd_open( thrdname, 80, 0, 16384, (PThreadHandler)request_proc, (unsigned long)s, 0 );
				sw_thrd_resume( s->thrd );
				return 0;
			}
		}
	}
	sw_httpserver_send_response_header( obj,HTTP_NOT_FOUND,NULL,NULL,"close",0,-1 );
	sw_httpserver_close_connectobj( obj );
	return 0;
}

int sw_mpegsrv_start( )
{
	int  i = 0;
	//ignore pipe error
	sigset_t signal_mask;
	sigemptyset (&signal_mask);
	sigaddset (&signal_mask, SIGPIPE);
	pthread_sigmask (SIG_BLOCK, &signal_mask, NULL);
	for( ;i<sizeof(m_chnlservers)/sizeof(m_chnlservers[0]);i++ )
	{
		memset( &m_chnlservers[i],0,sizeof( m_chnlservers[i]));
		m_chnlservers[i].skt = -1;
	}
	m_mutex = sw_mutex_create();
	//����һhttp������
	m_httpserver = sw_httpserver_open( htons(8280),httpsever_callback,0 );
	if( m_httpserver == NULL )
		return 0;
	while( getchar() != 'q' );
	return 0;
}

void sw_mpegsrv_stop()
{
	if( m_httpserver )
	{
		sw_httpserver_close( m_httpserver );
		m_httpserver = NULL;
	}
	if( m_mutex )
	{
		sw_mutex_destroy( m_mutex );
		m_mutex = NULL;
	}
}
