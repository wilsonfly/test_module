#!/bin/bash
#
#   $1: branch name
#

# BRANCH_NAME=pre-mtk-capricorn-p-9652
BRANCH_NAME=""
PROJ_MANIFEST=oneplus/manifests
SSH_URL=""
# WITHOUT_FULL_HISTORY=""
WITHOUT_FULL_HISTORY="--depth=20"

GIT_LFS_REPO_MMPLAYER=mtk/fusion-an/device/mstar/common/libraries/media/mmplayer
GIT_LFS_REPO_MI=mtk/fusion-an/device/mstar/common/libraries/mi
GIT_LFS_REPO_LIB_MAXIM=mtk/fusion-an/platform/hardware/mstar/libopenglhw/maxim
GIT_LFS_REPO_MAXIM=mtk/fusion-an/platform/vendor/mstar/maxim
GIT_LFS_REPO_MTK_OBJ=mtk/lfs/mtk_obj

# REPO_URL="https://mirrors.tuna.tsinghua.edu.cn/git/git-repo"
REPO_URL="ssh://tvgerrit.oneplus.cn/oppo/git-repo"
# REPO_BRANCH=master
REPO_BRANCH=stable


### check if current ip in SZ or not
# IP_CUR=$(hostname -i)
IP_CUR=`hostname -I | awk '{print $1}'`

fn_MenuPlatform()
{
	# clear
	echo -e "Platform menu"
	echo -e "Select the platfomr which you would like to do repo init/sync"
	echo -e "\t1) MT5670"
	echo -e "\t2) MT9652"
	echo -e "\t3) MT9950"
	echo -e "\t4) MT9612"
	echo -e "\t5) MT9632"
	echo -en "Enter your option:"
	read -n 1 optionPlatform
	
	case $optionPlatform in
	1)
		fn_MenuBranchInMT5670
		;;
	2)
		fn_MenuBranchInMT9652
		;;
	3)
		fn_MenuBranchInMT9950
		;;
	4)
		fn_MenuBranchInMT9612
		;;
	5)
		fn_MenuBranchInMT9632
		;;
	*)
		echo "(error) Unknown option. ($option)"
		;;
	esac
}

fn_MenuBranchInMT5670()
{	
	echo -e "\nSelect a branch name which you would like to have"
	echo -e "\t1) mtk-scorpio-p-5670"
	echo -e "\t2) mtk-scorpio-p-5670-tag133_20200808"
	echo -e "\t3) scorpio-p-5670"
	echo -e "\t4) scorpio-p-5670-1.18_20210126"
	echo -e "\t5) scorpio-p-5670-1.16_20201218"
	read -n 1 optionBranch
	
	case $optionBranch in
	1)
		BRANCH_NAME=mtk-scorpio-p-5670
		;;
	2)
		BRANCH_NAME=mtk-scorpio-p-5670-tag133_20200808
		;;
	3)
		BRANCH_NAME=scorpio-p-5670
		;;
	4)
		BRANCH_NAME=scorpio-p-5670-1.18_20210126
		;;
	5)
		BRANCH_NAME=scorpio-p-5670-1.16_20201218
		;;
	*)
		echo "(error) Unknown option. ($optionBranch)"
		;;
	esac
}

fn_MenuBranchInMT9652()
{
	echo -e "\nSelect a branch name which you would like to have"
	echo -e "\t1) mtk-capricorn-p-9652"
	echo -e "\t2) mtk-capricorn-p-9652-tag83_20201213"
	echo -e "\t3) capricorn-p-9652"
	echo -e "\t4) capricorn-p-9652-1.10_20201217"
	echo -e "\t5) capricorn-p-9652-1.8_20201215"
	echo -e "\t6) capricorn-p-9652-1.8_20201115"
	read -n 1 optionBranch
	
	case $optionBranch in
	1)
		BRANCH_NAME=mtk-capricorn-p-9652
		;;
    2)
        BRANCH_NAME=mtk-capricorn-p-9652-tag83_20201213
        ;;
	3)
		BRANCH_NAME=capricorn-p-9652
		;;
	4)
		BRANCH_NAME=capricorn-p-9652-1.10_20201217
		;;
	5)
		BRANCH_NAME=capricorn-p-9652-1.8_20201215
		;;
	6)
		BRANCH_NAME=capricorn-p-9652-1.8_20201115
		;;
	*)
		echo "(error) Unknown option. ($optionBranch)"
		;;
	esac
}

fn_MenuBranchInMT9950()
{
	echo -e "\nSelect a branch name which you would like to have"
	echo -e "\t1) mtk-sagittarius-p-9950"
	echo -e "\t2) sagittarius-p-9950"
	echo -e "\t3) sagittarius-p-9950-1.6_20201217"
	echo -e "\t4) sagittarius-p-9950-1.6_20201115"
	read -n 1 optionBranch
	
	case $optionBranch in
	1)
		BRANCH_NAME=mtk-sagittarius-p-9950
		;;
	2)
		BRANCH_NAME=sagittarius-p-9950
		;;
	3)
		BRANCH_NAME=sagittarius-p-9950-1.6_20201217
		;;
	4)
		BRANCH_NAME=sagittarius-p-9950-1.6_20201115
		;;
	*)
		echo "(error) Unknown option. ($optionBranch)"
		;;
	esac
}

fn_MenuBranchInMT9612()
{
	echo -e "\nSelect a branch name which you would like to have"
	echo -e "\t1) mtk-aquarius-q-9612"
	echo -e "\t2) mtk-aquarius-q-9612-ta17_20210113"
	echo -e "\t3) mtk-aquarius-q-9612-tag31_20210202"
	echo -e "\t4) aquarius-q-9612"
	echo -e "\t5) aquarius-q-9612-1.6_20210221 (MP)"
	echo -e "\t6) aquarius-q-9612-1.4_20210202 (PVT)"
	echo -e "\t7) aquarius-q-9612-1.3_20210202 (Netflix Cert.)"
	echo -e "\t8) aquarius-q-9612-1.2_20210202 (Temporary Google Cert.)"
	echo -e "\t9) aquarius-q-9612-1.1_20210117 (Dobly Audio Cert.)"
	read -n 1 optionBranch
	
	case $optionBranch in
	1)
		BRANCH_NAME=mtk-aquarius-q-9612
		;;
    2)
        BRANCH_NAME=mtk-aquarius-q-9612-ta17_20210113
        ;;
	3)
        BRANCH_NAME=mtk-aquarius-q-9612-tag31_20210202
        ;;
	4)
		BRANCH_NAME=aquarius-q-9612
		;;
	5)
        BRANCH_NAME=aquarius-q-9612-1.6_20210221
        ;;
	6)
        BRANCH_NAME=aquarius-q-9612-1.4_20210202
        ;;
	7)
        BRANCH_NAME=aquarius-q-9612-1.3_20210202
        ;;
    8)
        BRANCH_NAME=aquarius-q-9612-1.2_20210202
        ;;
	9)
		BRANCH_NAME=aquarius-q-9612-1.1_20210117
		;;
	*)
		echo "(error) Unknown option. ($optionBranch)"
		;;
	esac
}

fn_MenuBranchInMT9632()
{
	echo -e "\nSelect a branch name which you would like to have"
	echo -e "\t1) mtk-capricorn-p-9652"
	echo -e "\t2) capricorn-p-9652"
	read -n 1 optionBranch
	
	case $optionBranch in
	1)
		BRANCH_NAME=mtk-capricorn-p-9652
		;;
	2)
		BRANCH_NAME=capricorn-p-9652
		;;
	*)
		echo "(error) Unknown option. ($optionBranch)"
		;;
	esac
}

fn_DetermineSshUrl()
{
	if [ "$BRANCH_NAME" == "" ]; then
		echo -e "\n(info) Unknown project branch name. ($BRANCH_NAME)"
		exit 1;
	fi
	
	echo -e "\n(info) Processing..."
	if [[ $IP_CUR == *"172.19"* ]] \
		|| [[ $IP_CUR == *"10.27.8"* ]]; then
		# echo "(info) SH IP. $IP_CUR"
		SSH_URL="ssh://tvgerrit2.oneplus.cn"
	else
		# echo "(info) Not SH IP. $IP_CUR"
		SSH_URL="ssh://tvgerrit.oneplus.cn"
	fi
	echo "(info) ssh url info $SSH_URL"
}

fn_IsSyncWithFullHistory()
{
	echo -e "\nSync with full history (y/n)"
	read -n 1 optionYN
	
	if [ "$optionYN" == "n" ] \
		|| [ "$optionYN" == "N" ]; then
		WITHOUT_FULL_HISTORY="--depth=10"
	fi
}

fn_RemoveLog()
{
	### remove log at first
	# echo "(info) remove *.log at first. rm -f *.log"
	rm -f *.log
}

fn_EnsureGitEnv()
{
	### check if git-lfs install or not
	GitConfigLfs=$(git config --list | grep "git-lfs smudge")
	if [ -z "$GitConfigLfs" ]; then
		### git lfs initial
		echo -e "(info) git lfs install"
		git lfs install
	else
		echo -e "(info) git-lfs is already initialized"
	fi

	GitConfigColor=$(git config --list | grep "color")
	if [ -z "$GitConfigColor" ]; then
		### git config color
		echo -e "(info) git config --global color.ui auto"
		git config --global color.ui auto
	fi
}

fn_InitAndSync()
{
	echo -e "(info) ##### fn_InitAndSync #####"
	
	echo -e "(info) export REPO_TRACE=1"
	export REPO_TRACE=1

	PATH_MIRROR=""
	PATH_REPO_MIRROR_BASE=""
	### Overwrite if necessary
	if [ -d "/data/mirror" ]; then
		PATH_REPO_MIRROR_BASE=/data/mirror
	elif [ -d "/work/mirror" ]; then
		PATH_REPO_MIRROR_BASE=/work/mirror
	fi

	if [[ "$BRANCH_NAME" == *"capricorn-p-9652"* ]]; then
		PATH_MIRROR=${PATH_REPO_MIRROR_BASE}/capricorn-p-9652
	elif [[ "$BRANCH_NAME" == *"sagittarius-p-9950"* ]]; then
		PATH_MIRROR=${PATH_REPO_MIRROR_BASE}/sagittarius-p-9950
	elif [[ "$BRANCH_NAME" == *"aquarius-q-9612"* ]]; then
		PATH_MIRROR=${PATH_REPO_MIRROR_BASE}/aquarius-q-9612
	else
		PATH_MIRROR=${PATH_REPO_MIRROR_BASE}/scorpio-p-5670
	fi
	
	if [ -d "${PATH_MIRROR}/.repo" ]; then
		### mirror
		# echo "(info) repo init $WITHOUT_FULL_HISTORY -u $SSH_URL/$PROJ_MANIFEST -b $BRANCH_NAME --reference=${PATH_MIRROR}"
		# repo init $WITHOUT_FULL_HISTORY -u $SSH_URL/$PROJ_MANIFEST -b $BRANCH_NAME --reference=${PATH_MIRROR} || { echo "(error) repo init $WITHOUT_FULL_HISTORY -u $SSH_URL/$PROJ_MANIFEST -b $BRANCH_NAME --reference=${PATH_MIRROR} fail!!!"; exit 1; }
		
		# echo "(info) repo init $WITHOUT_FULL_HISTORY -u $SSH_URL/$PROJ_MANIFEST -b $BRANCH_NAME --reference=${PATH_MIRROR} --repo-url https://mirrors.tuna.tsinghua.edu.cn/git/git-repo --repo-branch master --no-repo-verify"
		# repo init $WITHOUT_FULL_HISTORY -u $SSH_URL/$PROJ_MANIFEST -b $BRANCH_NAME --reference=${PATH_MIRROR} --repo-url https://mirrors.tuna.tsinghua.edu.cn/git/git-repo --repo-branch master --no-repo-verify || { echo "(error) repo init $WITHOUT_FULL_HISTORY -u $SSH_URL/$PROJ_MANIFEST -b $BRANCH_NAME --reference=${PATH_MIRROR} fail!!!"; exit 1; }
		
		echo "(info) repo init $WITHOUT_FULL_HISTORY -u $SSH_URL/$PROJ_MANIFEST -b $BRANCH_NAME --reference=${PATH_MIRROR} --repo-url $REPO_URL --repo-branch $REPO_BRANCH --no-repo-verify"
		repo init $WITHOUT_FULL_HISTORY -u $SSH_URL/$PROJ_MANIFEST -b $BRANCH_NAME --reference=${PATH_MIRROR} --repo-url $REPO_URL --repo-branch $REPO_BRANCH --no-repo-verify || { echo "(error) repo init $WITHOUT_FULL_HISTORY -u $SSH_URL/$PROJ_MANIFEST -b $BRANCH_NAME --reference=${PATH_MIRROR} fail!!!"; exit 1; }
	else
		# echo "(info) repo init $WITHOUT_FULL_HISTORY -u $SSH_URL/$PROJ_MANIFEST -b $BRANCH_NAME"
		# repo init $WITHOUT_FULL_HISTORY -u $SSH_URL/$PROJ_MANIFEST -b $BRANCH_NAME || { echo "(error) repo init --depth=20 -u $SSH_URL/$PROJ_MANIFEST -b $BRANCH_NAME fail!!!"; exit 1; }
		
		# echo "(info) repo init $WITHOUT_FULL_HISTORY -u $SSH_URL/$PROJ_MANIFEST -b $BRANCH_NAME --repo-url https://mirrors.tuna.tsinghua.edu.cn/git/git-repo --repo-branch master --no-repo-verify"
		# repo init $WITHOUT_FULL_HISTORY -u $SSH_URL/$PROJ_MANIFEST -b $BRANCH_NAME --repo-url https://mirrors.tuna.tsinghua.edu.cn/git/git-repo --repo-branch master --no-repo-verify || { echo "(error) repo init $WITHOUT_FULL_HISTORY -u $SSH_URL/$PROJ_MANIFEST -b $BRANCH_NAME fail!!!"; exit 1; }
		
		echo "(info) repo init $WITHOUT_FULL_HISTORY -u $SSH_URL/$PROJ_MANIFEST -b $BRANCH_NAME --repo-url $REPO_URL --repo-branch $REPO_BRANCH --no-repo-verify"
		repo init $WITHOUT_FULL_HISTORY -u $SSH_URL/$PROJ_MANIFEST -b $BRANCH_NAME --repo-url $REPO_URL --repo-branch $REPO_BRANCH --no-repo-verify || { echo "(error) repo init $WITHOUT_FULL_HISTORY -u $SSH_URL/$PROJ_MANIFEST -b $BRANCH_NAME fail!!!"; exit 1; }
	fi
	
	# echo -e "(info) repo init -u $SSH_URL/$PROJ_MANIFEST -b $BRANCH_NAME $WITHOUT_FULL_HISTORY"
	# repo init -u $SSH_URL/$PROJ_MANIFEST -b $BRANCH_NAME $WITHOUT_FULL_HISTORY || { echo "(error) repo init -u $SSH_URL/$PROJ_MANIFEST -b $BRANCH_NAME $WITHOUT_FULL_HISTORY fail!!!"; exit 1; }

	if [ -e "repo_sync_${BRANCH_NAME}.log" ]; then
		echo -e "(info) remove previous repo sync log if there is any. rm -f repo_sync_${BRANCH_NAME}.log"
		rm -f repo_sync_${BRANCH_NAME}.log
	fi

	echo "(info) time repo sync -j8 --no-clone-bundle -c --no-repo-verify 2>&1 | tee repo_sync_${BRANCH_NAME}.log"
	time repo sync -j8 --no-clone-bundle -c --no-repo-verify 2>&1 | tee repo_sync_${BRANCH_NAME}.log

	### check if sync error or not
	# grep "error: Cannot" repo_sync_${BRANCH_NAME}.log
	grep "repo sync has finished successfully" repo_sync_${BRANCH_NAME}.log
	if [ $? -eq 0 ]; then
		echo -e "(info) repo sync successfully"
	else
		echo -e "(info) There has sync error. try again"
		if [ -e "repo_sync_${BRANCH_NAME}.log" ]; then
			echo -e "(info) remove previous repo sync log if there is any. rm -f repo_sync_${BRANCH_NAME}.log"
			rm -f repo_sync_$BRANCH_NAME.log
		fi
		
		echo -e "(info)(2 nd) time repo sync -j8 --no-clone-bundle -c --no-repo-verify 2>&1 | tee repo_sync_${BRANCH_NAME}.log"
		time repo sync -j8 --no-clone-bundle -c --no-repo-verify 2>&1 | tee repo_sync_${BRANCH_NAME}.log || { echo "(error)(2 nd) repo sync -j16 --no-clone-bundle -c fail!!!"; exit 1; }
		
		# grep "error: Cannot" repo_sync_${BRANCH_NAME}.log
		grep "repo sync has finished successfully" repo_sync_${BRANCH_NAME}.log
		if [ $? -eq 0 ]; then
			echo -e "(info) repo sync successfully"
		else
			echo -e "(info) There has sync error (2)"
			echo "(info) unset REPO_TRACE"
			unset REPO_TRACE
			exit 1
		fi
	fi
		
	if [[ "$BRANCH_NAME" == *"sagittarius-p-9950"* ]] \
        || [[ "$BRANCH_NAME" == *"capricorn-p-9652"* ]] \
        || [[ "$BRANCH_NAME" == *"aquarius-q-9612"* ]]; then
		fn_GitLfsPull
	fi

	echo "(info) unset REPO_TRACE"
	unset REPO_TRACE
}

fn_GitLfsPull()
{
	### check if mtk/lfs/mtk_obj exists or not
	unset REPO_TRACE
	RESULT=$(repo forall ${GIT_LFS_REPO_MTK_OBJ} -c 'echo "$REPO_PROJECT"')
	echo "(info) ${BRANCH_NAME} repo forall ${GIT_LFS_REPO_MTK_OBJ} RESULT: ${RESULT}"
	export REPO_TRACE=1
	
	### setup project list (forall)
	REPO_FORALL_LIST=""
	if [[ "$BRANCH_NAME" == *"capricorn-p-9652"* ]]; then
		REPO_FORALL_LIST=${GIT_LFS_REPO_MMPLAYER}" "${GIT_LFS_REPO_MI}" "${GIT_LFS_REPO_LIB_MAXIM}" "${GIT_LFS_REPO_MAXIM}
		if [ "$RESULT" == "$GIT_LFS_REPO_MTK_OBJ" ]; then
			REPO_FORALL_LIST+=" "${GIT_LFS_REPO_MTK_OBJ}
		fi
	elif [[ "$BRANCH_NAME" == *"sagittarius-p-9950"* ]]; then
		REPO_FORALL_LIST=${GIT_LFS_REPO_MMPLAYER}" "${GIT_LFS_REPO_MI}
		if [ "$RESULT" == "$GIT_LFS_REPO_MTK_OBJ" ]; then
			REPO_FORALL_LIST+=" "${GIT_LFS_REPO_MTK_OBJ}
		fi
	elif [[ "$BRANCH_NAME" == *"aquarius-q-9612"* ]]; then
		if [ "$RESULT" == "$GIT_LFS_REPO_MTK_OBJ" ]; then
			REPO_FORALL_LIST+=${GIT_LFS_REPO_MTK_OBJ}
		fi
	else
        echo -e "(warning) Unkonwn branch ($BRANCH_NAME)."
	fi
	
	echo -e "(info) REPO_FORALL_LIST: $REPO_FORALL_LIST"
	### change the url if the repository is lfs
	### lfs url is only avaiable in SZ
	echo -e "(info) To change the remote url in the lfs repository due to lfs url only avaible in host gerrit server"
	echo -e "(info) export GIT_TRACE=1"
    export GIT_TRACE=1

	time repo forall ${REPO_FORALL_LIST} \
	-c 'echo "$REPO_PROJECT" && git remote set-url oneplus.tv ssh://tvgerrit.oneplus.cn/${REPO_PROJECT}' \
	2>&1 | tee repo_forall_git_remote_set_url.log
	
	### git lfs pull in each lfs repsoitories
	echo "(info) git lfs pull in each lfs repsoitories"
	time repo forall ${REPO_FORALL_LIST} \
	-c 'echo "$REPO_PROJECT" && git lfs pull oneplus.tv' \
	2>&1 | tee repo_forall_git_lfs_pull.log
	
	### check if git lfs pull error or not
	grep "error: " repo_forall_git_lfs_pull.log
	if [ $? -ne 0 ]; then
		echo -e "(info) git lfs pull successfully"
	else
		echo -e "(error) git lfs pull error. Try again"
		echo -e "(info) remove repo_forall_git_lfs_pull.log at first"
		echo -e "(info) rm -f repo_forall_git_lfs_pull.log"
		rm -f repo_forall_git_lfs_pull.log
		
		### git lfs pull in each lfs repsoitories
		echo -e "(info) git lfs pull in each lfs repsoitories"
		
		time repo forall ${REPO_FORALL_LIST} \
		-c 'echo "$REPO_PROJECT" && git lfs pull oneplus.tv' \
		2>&1 | tee repo_forall_git_lfs_pull.log
	
		### check if git lfs pull error or not
		grep "error: " repo_forall_git_lfs_pull.log
		if [ $? -ne 0 ]; then
			echo -e "(info) git lfs pull successfully"
		else
			echo -e "(info) unset REPO_TRACE"
			unset REPO_TRACE
			echo -e "(info) unset GIT_TRACE"
			unset GIT_TRACE
		
			echo -e "(error) git lfs pull error"
			exit 1
		fi		
	fi
	
	echo -e "(info) unset GIT_TRACE"
	unset GIT_TRACE
}

echo "##############################"

fn_MenuPlatform
# fn_IsSyncWithFullHistory
fn_DetermineSshUrl
fn_RemoveLog
fn_EnsureGitEnv
fn_InitAndSync
