1. buildTargetSys.sh 编译脚本

2. platform_init_and_sync.sh 拉代码脚本. 选单

3. platform_init_and_sync_svr.sh 拉代码脚本, 支持 manifest snapshot
e.g
./platform_init_and_sync_svr.sh aquarius-q-9612
./platform_init_and_sync_svr.sh aquarius-q-9612 manifest_2012290356.xml

Note.
manifest_2012290356.xml
a) 可以在版本服务器中获取
b) 放在 .repo/manifests/manifest_2012290356.xml