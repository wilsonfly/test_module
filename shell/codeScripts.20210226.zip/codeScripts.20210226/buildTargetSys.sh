#!/bin/bash
#
#   To build target
#

PLATFORM=""
LUNCH_SYS=""
BUILD_TYPE=""
PLATFORM_MAKE_CMD=""
MAKE_PARAMETERS=""

MAKE_PARAMETERS_SIGN_IMG="SIGN_IMG_SUPPORT=true"
MAKE_PARAMETERS_RLS_CUSTOM_BUILD="RLS_CUSTOM_BUILD=true"
MAKE_PARAMETERS_GLOBAL_ENV="GLOBAL_ENV=variant=user"
MAKE_PARAMETERS_ENABLE_OTA="ENABLE_OTA=true"
MAKE_PARAMETERS_GA="DMIC_AEC_LIBRARY=google"

fn_DeterminePlatform()
{
	echo -e "\n*************************"

	if [ -d "android/p-base" ]; then
		PLATFORM=MT5670
	elif [ -d "device/oneplus/OPPOCNM652" ]; then
		PLATFORM=MT9652
	elif [ -d "device/oneplus/mt9950" ]; then
		PLATFORM=MT9950
	elif [ -d "device/oneplus/Cebu" ]; then
		PLATFORM=MT9612
	else
		### default
		PLATFORM=MT5670
	fi
	
	echo -e "\n(info) fn_determine_platform. platform: ${PLATFORM}"
}

fn_MenuLunchSysMT5670()
{
	echo -e "\t1) Oneplus_Dosa_IN"
	echo -e "\t2) Oneplus_Dosa"
	read -n 1 optionLunchSys
	
	case $optionLunchSys in
	1)
		LUNCH_SYS=Oneplus_Dosa_IN
		;;
	2)
		LUNCH_SYS=Oneplus_Dosa
		;;
	*)
		echo "(error) Unknown option. ($optionLunchSys). exit"
		exit 1
		;;
	esac
	
	echo -e "\n(info) fn_MenuLunchSysMT5670. lunch: ${LUNCH_SYS}"
}

fn_MenuLunchSysMT9652()
{
	echo -e "\t1) OPPOCNM652"
	echo -e "\t2) OnePlusCNM652"
	echo -e "\t3) OPPOCNM632 (MT9632)"
	read -n 1 optionLunchSys
	
	case $optionLunchSys in
	1)
		LUNCH_SYS=OPPOCNM652
		;;
	2)
		LUNCH_SYS=OnePlusCNM652
		;;
	3)
		LUNCH_SYS=OPPOCNM632
		;;
	*)
		echo "(error) Unknown option. ($optionLunchSys). exit"
		exit 1
		;;
	esac
	
	echo -e "\n(info) fn_MenuLunchSysMT9652. lunch: ${LUNCH_SYS}"
}

fn_MenuLunchSysMT9950()
{
	echo -e "\t1) mt9950_cn_oppo"
	echo -e "\t2) mt9950_cn_oneplus"
	read -n 1 optionLunchSys
	
	case $optionLunchSys in
	1)
		LUNCH_SYS=mt9950_cn_oppo
		;;
	2)
		LUNCH_SYS=mt9950_cn_oneplus
		;;
	*)
		echo "(error) Unknown option. ($optionLunchSys). exit"
		exit 1
		;;
	esac
	
	echo -e "\n(info) fn_MenuLunchSysMT9950. lunch: ${LUNCH_SYS}"
}

fn_MenuLunchSysMT9612()
{
	echo -e "\t1) Cebu"
	echo -e "\t2) OPPO_Cebu"
	read -n 1 optionLunchSys
	
	case $optionLunchSys in
	1)
		LUNCH_SYS=Cebu
		;;
	2)
		LUNCH_SYS=OPPO_Cebu
		;;
	*)
		echo "(error) Unknown option. ($optionLunchSys). exit"
		exit 1
		;;
	esac
	
	LUNCH_SYS=Cebu
	
	echo -e "\n(info) fn_MenuLunchSysMT9612. lunch: ${LUNCH_SYS}"
}

fn_MenuLunchSysByPlatform()
{
	echo -e "\n*************************"
	echo -e "\nSelect the lunch system which you would like to have"
	
	if [ "$PLATFORM" == "MT5670" ]; then
		fn_MenuLunchSysMT5670
	elif [ "$PLATFORM" == "MT9652" ]; then
		fn_MenuLunchSysMT9652
	elif [ "$PLATFORM" == "MT9950" ]; then
		fn_MenuLunchSysMT9950
	elif [ "$PLATFORM" == "MT9612" ]; then
		fn_MenuLunchSysMT9612
	else
		echo "(error) unknown platform. exit"
		exit 1
	fi
	
	# echo -e "\n(info) fn_select_lunch_sys. lunch: ${LUNCH_SYS}"
}

fn_MenuBuildType()
{
	echo -e "\n*************************"
	echo -e "\nSelect the build type which you would like to have"
	
	echo -e "\t1) userdebug"
	echo -e "\t2) user  (Without release key. The key is the same as userdebug)"
	read -n 1 optionBuildType
	
	case $optionBuildType in
	1)
		BUILD_TYPE=userdebug
		;;
	2)
		BUILD_TYPE=user
		;;
	*)
		echo "(error) Unknown option. ($optionBuildType). exit"
		exit 1
		;;
	esac
	
	echo -e "\n(info) build type: ${BUILD_TYPE}"
}

fn_MenuBuildClean()
{
	echo -e "\n*************************"
	echo -e "\nSelect the make command which you would like to have"
	
	echo -e "\t1) build system"
	echo -e "\t2) clean system"
	echo -e "\t3) build system with ota package"
	read -n 1 optionMakeCmd
	
	case $optionMakeCmd in
	1)
		PLATFORM_MAKE_CMD=mtk_build
		;;
	2)
		PLATFORM_MAKE_CMD=mtk_clean
		;;
	3)
		PLATFORM_MAKE_CMD=mtk_build
		if [ "$MAKE_PARAMETERS" == "" ]; then
			MAKE_PARAMETERS=$MAKE_PARAMETERS_ENABLE_OTA
		else
			MAKE_PARAMETERS+=" "$MAKE_PARAMETERS_ENABLE_OTA
		fi
		;;
	*)
		echo "(error) Unknown option. ($optionMakeCmd). exit"
		exit 1
		;;
	esac
	
	echo -e "\n(info) make command: ${PLATFORM_MAKE_CMD}"
}

fn_BuildTargetSys()
{
	echo -e "\n*************************"
	echo -e "\nfn_BuildTargetSys"

	### remove make log at first
	echo "(info) rm -f make_*.log"
	rm -f make_*.log
	
	if [ "$PLATFORM" == "MT5670" ]; then
		### goto specific path android/p-base
		echo "(info)(${PLATFORM}) goto android/p-base. cd android/p-base"
		cd android/p-base
	fi
	
	### Preparing a Compiler Cache
	echo "(info) Preparing a Compiler Cache"
	# if [ "${PLATFORM_MAKE_CMD}" == "mtk_clean" ] \
		# || [ ! -d "out" ]; then
		# echo "(info) Clean ccache at first"
		# echo "(info) prebuilts/misc/linux-x86/ccache/ccache -C"
		# prebuilts/misc/linux-x86/ccache/ccache -C
	# fi
	
	if [ -e "prebuilts/misc/linux-x86/ccache/ccache" ]; then
		echo "(info) export USE_CCACHE=1"
		export USE_CCACHE=1
		
		echo "(info) prebuilts/misc/linux-x86/ccache/ccache -M 30G"
		prebuilts/misc/linux-x86/ccache/ccache -M 30G
	fi

	### Configuring Android Jack
	# echo "(info) Configuring Android Jack"
	# echo "(info) export ANDROID_JACK_VM_ARGS=\"-Xmx8g -Dfile.encoding=UTF-8 -XX:+TieredCompilation\""
	# export ANDROID_JACK_VM_ARGS="-Xmx8g -Dfile.encoding=UTF-8 -XX:+TieredCompilation"

	# MAKE_PARAMETERS=""
	if [ "$BUILD_TYPE" == "user" ]; then
		if [ "$MAKE_PARAMETERS" == "" ]; then
			MAKE_PARAMETERS=$MAKE_PARAMETERS_SIGN_IMG
		else
			MAKE_PARAMETERS+=" "$MAKE_PARAMETERS_SIGN_IMG
		fi
		if [[ "$PLATFORM" == *"MT9652"* ]] \
			|| [[ "$PLATFORM" == *"MT9950"* ]] \
			|| [[ "$PLATFORM" == *"MT9612"* ]]; then
			if [ "$MAKE_PARAMETERS" == "" ]; then
				MAKE_PARAMETERS=$MAKE_PARAMETERS_GLOBAL_ENV
			else
				MAKE_PARAMETERS+=" "$MAKE_PARAMETERS_GLOBAL_ENV
			fi
		else
			echo "(info) export variant=user"
			export variant=user
		fi
	else
		echo "(info) unset variant"
		unset variant
		
		if [[ "$PLATFORM" == *"MT9652"* ]] \
			|| [[ "$PLATFORM" == *"MT9950"* ]] \
			|| [[ "$PLATFORM" == *"MT9612"* ]]; then
			if [ "$MAKE_PARAMETERS" == "" ]; then
				MAKE_PARAMETERS=$MAKE_PARAMETERS_RLS_CUSTOM_BUILD
			else
				MAKE_PARAMETERS+=" "$MAKE_PARAMETERS_RLS_CUSTOM_BUILD
			fi
		fi
	fi
	
	if [[ "$PLATFORM" == *"MT9612"* ]]; then
		### enable ga
		if [ "$MAKE_PARAMETERS" == "" ]; then
			MAKE_PARAMETERS=$MAKE_PARAMETERS_GA
		else
			MAKE_PARAMETERS+=" "$MAKE_PARAMETERS_GA
		fi
		### customized patch at first
		echo "(info) [$PLATFORM] customized patch at first"
		echo "(info) sh vendor/mediatek/proprietary_tv/apollo/linux_mts/build/mak/android/android_q_base_build_fusion.sh"
		sh vendor/mediatek/proprietary_tv/apollo/linux_mts/build/mak/android/android_q_base_build_fusion.sh
	fi
	
	if [ "$LUNCH_SYS" == "OPPOCNM632" ]; then
		### check if there is the system build
		if [ -d "device/oneplus/OPPOCNM632" ]; then
			echo "(info) system build - $LUNCH_SYS"
		else
			echo "(error) There is no system build - $LUNCH_SYS. exit 1"
			exit 1;
		fi
	elif [ "$LUNCH_SYS" == "OPPO_Cebu" ]; then
		### check if there is the system build
		if [ -d "vendor/mediatek/proprietary_tv/apollo/mtk_obj/oneplus/OPPO_Cebu" ]; then
			echo "(info) system build - $LUNCH_SYS"
		else
			echo "(error) There is no system build - $LUNCH_SYS. exit 1"
			exit 1;
		fi
	fi
	
	### build target system
	echo "(info) source build/envsetup.sh;lunch ${LUNCH_SYS}-${BUILD_TYPE};time make -j32 ${MAKE_PARAMETERS} ${PLATFORM_MAKE_CMD} 2>&1 | tee make_${PLATFORM_MAKE_CMD}_time.log"
	source build/envsetup.sh;\
	lunch $LUNCH_SYS-$BUILD_TYPE;\
	time make -j32 $MAKE_PARAMETERS $PLATFORM_MAKE_CMD 2>&1 | tee make_${PLATFORM_MAKE_CMD}_${LUNCH_SYS}-${BUILD_TYPE}_`date +%y%m%d%H%M`.log
	
	
	if [ "${PLATFORM_MAKE_CMD}" == "mtk_clean" ]; then
        if [[ "$PLATFORM" == *"MT9612"* ]]; then
            if [ -e "patched" ]; then
                echo "(info) rm -f patched"
                rm -f patched
			fi
		fi
		### Ensure to remove the out/
		if [ -d out ]; then
			rm -rf out
		fi
	fi
}

# echo -e "\n*************************"
fn_DeterminePlatform
fn_MenuLunchSysByPlatform
fn_MenuBuildType
fn_MenuBuildClean
fn_BuildTargetSys
