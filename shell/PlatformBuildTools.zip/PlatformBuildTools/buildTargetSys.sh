#!/bin/bash
#
#   To build target
#   e.g.
#   ./buildTargetSys.sh
#

PLATFORM=""
LUNCH_SYS=""
BUILD_TYPE=""
PLATFORM_MAKE_CMD=""
MAKE_PARAMETERS=""
MAKE_COMMOND="make"

MAKE_PARAMETERS_SIGN_IMG=" SIGN_IMG_SUPPORT=true"
MAKE_PARAMETERS_RLS_CUSTOM_BUILD=" RLS_CUSTOM_BUILD=true"
MAKE_PARAMETERS_GLOBAL_ENV=" GLOBAL_ENV=variant=user"
MAKE_PARAMETERS_ENABLE_OTA=" ENABLE_OTA=true"
MAKE_PARAMETERS_GA=" DMIC_AEC_LIBRARY=google"
MAKE_PARAMETERS_WEEKLY_BUILD_TYPE=" WEEKLY_BUILD_TYPE=PRETEST"
MAKE_PARAMETERS_COMPILE_SYNC_BSP=" COMPILE_SYNC_BSP=true"
MAKE_PARAMETERS_CUS_BOARD_NAME=" CUS_BOARD_NAME=M3V1"
MAKE_PARAMETERS_OUTPUT_60HZ=" OUTPUT_60HZ=true"
MAKE_PARAMETERS_BOARD_MMAP_SIZE=" BOARD_MMAP_SIZE=1.5G"
#MAKE_PARAMETERS_GOOGLE_DIST=" GOOGLE_DIST=true"
MAKE_PARAMETERS_ENABLE_FLASHWRITER=" FLASH_WRITER=true"

fn_DeterminePlatform()
{
    echo -e "\n*************************"

    if [ -d "android/p-base" ]; then
        PLATFORM=MT5670
    elif [ -d "device/oneplus/OPPOCNM652" ]; then
        PLATFORM=MT9652
    elif [ -d "device/oneplus/mt9950" ]; then
        PLATFORM=MT9950
    elif [ -d "device/oneplus/Cebu" ]; then
        PLATFORM=MT9612
    elif [ -d "device/oneplus/Dubai" ]; then
        PLATFORM=MT9216
    elif [ -d "device/oneplus/Edinburgh" ]; then
        PLATFORM=MT9617
    else
        ### default
        PLATFORM=MT5670
    fi

    echo -e "\n(info) fn_determine_platform. platform: ${PLATFORM}"
}

fn_MenuLunchSysMT5670()
{
    echo -e "\t1) Oneplus_Dosa_IN"
    echo -e "\t2) Oneplus_Dosa"
    read -n 1 optionLunchSys

    case $optionLunchSys in
    1)
        LUNCH_SYS=Oneplus_Dosa_IN
        ;;
    2)
        LUNCH_SYS=Oneplus_Dosa
        ;;
    *)
        echo "(error) Unknown option. ($optionLunchSys). exit"
        exit 1
        ;;
    esac

    echo -e "\n(info) fn_MenuLunchSysMT5670. lunch: ${LUNCH_SYS}"
}

fn_MenuLunchSysMT9652()
{
    echo -e "\t1) OPPOCNM652"
    echo -e "\t2) OnePlusCNM652"
    echo -e "\t3) OPPOCNM632 (MT9632)"
    echo -e "\t4) OPPOCNM632_CacheLess"
    echo -e "\t5) OPPOCNM632_K9(cvte board/cacheless)"
    echo -e "\t6) OPPOCNM632_KONKA_OPPO_CacheLess(65K9x)"
    #echo -e "\t7) OPPOCNM632_CVTE_KONKA_CacheLess"
    read -n 1 optionLunchSys

    case $optionLunchSys in
    1)
        LUNCH_SYS=OPPOCNM652
        ;;
    2)
        LUNCH_SYS=OnePlusCNM652
        ;;
    3)
        LUNCH_SYS=OPPOCNM632
        ;;
    4)
        LUNCH_SYS=OPPOCNM632_CacheLess
        ;;
    5)
        LUNCH_SYS=OPPOCNM632_K9
        ;;
    6)
        LUNCH_SYS=OPPOCNM632_KONKA_OPPO_CacheLess
        ;;
    #7)
    #    LUNCH_SYS=OPPOCNM632_CVTE_KONKA_CacheLess
    #    ;;
    *)
        echo "(error) Unknown option. ($optionLunchSys). exit"
        exit 1
        ;;
    esac

    echo -e "\n(info) fn_MenuLunchSysMT9652. lunch: ${LUNCH_SYS}"
}

fn_MenuLunchSysMT9950()
{
    echo -e "\t1) mt9950_cn_oppo"
    echo -e "\t2) mt9950_cn_oneplus"
    read -n 1 optionLunchSys

    case $optionLunchSys in
    1)
        LUNCH_SYS=mt9950_cn_oppo
        ;;
    2)
        LUNCH_SYS=mt9950_cn_oneplus
        ;;
    *)
        echo "(error) Unknown option. ($optionLunchSys). exit"
        exit 1
        ;;
    esac

    echo -e "\n(info) fn_MenuLunchSysMT9950. lunch: ${LUNCH_SYS}"
}

fn_MenuLunchSysMT9612()
{
    echo -e "\t1) Cebu"
    echo -e "\t2) OPPO_Cebu"
    echo -e "\t3) Cebu_8g"
    read -n 1 optionLunchSys

    case $optionLunchSys in
    1)
        LUNCH_SYS=Cebu
        ;;
    2)
        LUNCH_SYS=OPPO_Cebu
        ;;
    3)
        LUNCH_SYS=Cebu_8g
        ;;
    *)
        echo "(error) Unknown option. ($optionLunchSys). exit"
        exit 1
        ;;
    esac

    #LUNCH_SYS=Cebu

    echo -e "\n(info) fn_MenuLunchSysMT9612. lunch: ${LUNCH_SYS}"
}

fn_MenuLunchSysMT9216()
{
    LUNCH_SYS=Dubai_eu
    echo -e "\n(info) fn_MenuLunchSysMT9216. lunch: ${LUNCH_SYS}"
}

fn_MenuLunchSysMT9617()
{

    echo -e "\t1) Edinburgh_gtv"
    echo -e "\t2) Geneva_gtv"
    read -n 1 optionLunchSys

    case $optionLunchSys in
    1)
        LUNCH_SYS=Edinburgh_gtv
        ;;
    2)
        LUNCH_SYS=Geneva_gtv
        ;;
    *)
        echo "(error) Unknown option. ($optionLunchSys). exit"
        exit 1
        ;;
    esac
    echo -e "\n(info) fn_MenuLunchSysMT9617. lunch: ${LUNCH_SYS}"
}

fn_MenuLunchSysByPlatform()
{
    echo -e "\n*************************"
    echo -e "\nSelect the lunch system which you would like to have"

    if [ "$PLATFORM" == "MT5670" ]; then
        fn_MenuLunchSysMT5670
    elif [ "$PLATFORM" == "MT9652" ]; then
        fn_MenuLunchSysMT9652
    elif [ "$PLATFORM" == "MT9950" ]; then
        fn_MenuLunchSysMT9950
    elif [ "$PLATFORM" == "MT9612" ]; then
        fn_MenuLunchSysMT9612
    elif [ "$PLATFORM" == "MT9216" ]; then
        fn_MenuLunchSysMT9216
    elif [ "$PLATFORM" == "MT9617" ]; then
        fn_MenuLunchSysMT9617
    else
        echo "(error) unknown platform. exit"
        exit 1
    fi

    # echo -e "\n(info) fn_select_lunch_sys. lunch: ${LUNCH_SYS}"
}

fn_MenuBuildType()
{
    echo -e "\n*************************"
    echo -e "\nSelect the build type which you would like to have"

    echo -e "\t1) userdebug"
    echo -e "\t2) user  (Without release key. The key is the same as userdebug)"
    read -n 1 optionBuildType

    case $optionBuildType in
    1)
        BUILD_TYPE=userdebug
        ;;
    2)
        BUILD_TYPE=user
        ;;
    *)
        echo "(error) Unknown option. ($optionBuildType). exit"
        exit 1
        ;;
    esac

    echo -e "\n(info) build type: ${BUILD_TYPE}"
}

fn_MenuBuildOutput60Hz()
{
    echo -e "\n*************************"
    echo -e "\nSelect the default display output option"

    echo -e "\t1) Force to output 60Hz"
    echo -e "\t2) Follow project id"
    read -n 1 optionOutputCmd

    case $optionOutputCmd in
    1)
        echo -e "\n(info) make command: ${MAKE_PARAMETERS_OUTPUT_60HZ}"
        ;;
    2)
        MAKE_PARAMETERS_OUTPUT_60HZ=""
        ;;
    *)
        echo "(error) Unknown option. ($optionOutputCmd). exit"
        exit 1
        ;;
    esac
}


fn_MenuBuildClean()
{
    echo -e "\n*************************"
    echo -e "\nSelect the make command which you would like to have"
    echo -e "\t1) build system"
    echo -e "\t2) clean system"
    echo -e "\t3) build system with ota package"
    echo -e "\t4) build system with flash writer"
    read -n 1 optionMakeCmd

    if [[ "$PLATFORM" == *"MT9617"* ]]; then
        case $optionMakeCmd in
            1)
                if [[ "$LUNCH_SYS" == *"Edinburgh"* ]]; then
                    fn_MenuBuildOutput60Hz
                fi
                ;;
            2)
                PLATFORM_MAKE_CMD=clean
                echo -e "\n(info) make command: ${PLATFORM_MAKE_CMD}"
                ;;
            3)
                PLATFORM_MAKE_CMD=dist
                echo -e "\n(info) make command: ${PLATFORM_MAKE_CMD}"
                ;;
            4)
                MAKE_PARAMETERS+=$MAKE_PARAMETERS_ENABLE_FLASHWRITER
                fn_MenuBuildOutput60Hz
                ;;
            *)
                echo "(error) Unknown option. ($optionMakeCmd). exit"
                exit 1
                ;;
        esac
    else
        case $optionMakeCmd in
            1)
                PLATFORM_MAKE_CMD=mtk_build
                ;;
            2)
                PLATFORM_MAKE_CMD=mtk_clean
                ;;
            3)
                PLATFORM_MAKE_CMD=mtk_build
                MAKE_PARAMETERS+=$MAKE_PARAMETERS_ENABLE_OTA
                ;;
            4)
                PLATFORM_MAKE_CMD=mtk_build
                MAKE_PARAMETERS+=$MAKE_PARAMETERS_ENABLE_FLASHWRITER
                ;;
            *)
                echo "(error) Unknown option. ($optionMakeCmd). exit"
                exit 1
                ;;
        esac

        echo -e "\n(info) make command: ${PLATFORM_MAKE_CMD}"
    fi
}

fn_BuildTargetSys()
{
    echo -e "\n*************************"
    echo -e "\nfn_BuildTargetSys"

    ### remove make log at first
    echo "(info) rm -f make_*.log"
    rm -f make_*.log

    if [ "$PLATFORM" == "MT5670" ]; then
        ### goto specific path android/p-base
        echo "(info)(${PLATFORM}) goto android/p-base. cd android/p-base"
        cd android/p-base
    fi

    ### Preparing a Compiler Cache
    echo "(info) Preparing a Compiler Cache"
    # if [ "${PLATFORM_MAKE_CMD}" == "mtk_clean" ] \
        # || [ ! -d "out" ]; then
        # echo "(info) Clean ccache at first"
        # echo "(info) prebuilts/misc/linux-x86/ccache/ccache -C"
        # prebuilts/misc/linux-x86/ccache/ccache -C
    # fi

    if [ -e "prebuilts/misc/linux-x86/ccache/ccache" ]; then
        echo "(info) export USE_CCACHE=1"
        export USE_CCACHE=1

        echo "(info) prebuilts/misc/linux-x86/ccache/ccache -M 30G"
        prebuilts/misc/linux-x86/ccache/ccache -M 30G
    fi

    ### Configuring Android Jack
    # echo "(info) Configuring Android Jack"
    # echo "(info) export ANDROID_JACK_VM_ARGS=\"-Xmx8g -Dfile.encoding=UTF-8 -XX:+TieredCompilation\""
    # export ANDROID_JACK_VM_ARGS="-Xmx8g -Dfile.encoding=UTF-8 -XX:+TieredCompilation"

    # MAKE_PARAMETERS=""
    if [ "$BUILD_TYPE" == "user" ]; then
        MAKE_PARAMETERS+=$MAKE_PARAMETERS_SIGN_IMG
        if [[ "$PLATFORM" == *"MT9652"* ]] \
            || [[ "$PLATFORM" == *"MT9950"* ]] \
            || [[ "$PLATFORM" == *"MT9612"* ]] \
            || [[ "$PLATFORM" == *"MT9216"* ]] \
            || [[ "$PLATFORM" == *"MT9617"* ]]; then
            MAKE_PARAMETERS+=$MAKE_PARAMETERS_GLOBAL_ENV
        else
            echo "(info) export variant=user"
            export variant=user
        fi
    else
        echo "(info) unset variant"
        unset variant
    fi

    if [[ "$PLATFORM" == *"MT9652"* ]] \
        || [[ "$PLATFORM" == *"MT9950"* ]] \
        || [[ "$PLATFORM" == *"MT9612"* ]]; then
        MAKE_PARAMETERS+=$MAKE_PARAMETERS_RLS_CUSTOM_BUILD
    elif [[ "$PLATFORM" == *"MT9216"* ]]; then
        MAKE_PARAMETERS+=$MAKE_PARAMETERS_WEEKLY_BUILD_TYPE
        MAKE_PARAMETERS+=$MAKE_PARAMETERS_COMPILE_SYNC_BSP
    elif [[ "$PLATFORM" == *"MT9617"* ]]; then
        MAKE_PARAMETERS+=$MAKE_PARAMETERS_WEEKLY_BUILD_TYPE
        if [[ "$LUNCH_SYS" == *"Edinburgh"* ]]; then
            MAKE_PARAMETERS+=$MAKE_PARAMETERS_CUS_BOARD_NAME
            MAKE_PARAMETERS+=$MAKE_PARAMETERS_OUTPUT_60HZ
        elif [[ "$LUNCH_SYS" == *"Geneva"* ]]; then
            MAKE_PARAMETERS+=$MAKE_PARAMETERS_COMPILE_SYNC_BSP
            MAKE_PARAMETERS+=$MAKE_PARAMETERS_BOARD_MMAP_SIZE
        fi
    fi

    if [[ "$PLATFORM" == *"MT9612"* ]]; then
        ### enable ga
        MAKE_PARAMETERS+=$MAKE_PARAMETERS_GA
        ### customized patch at first
        echo "(info) [$PLATFORM] customized patch at first"
        echo "(info) sh vendor/mediatek/proprietary_tv/apollo/linux_mts/build/mak/android/android_q_base_build_fusion.sh"
        sh vendor/mediatek/proprietary_tv/apollo/linux_mts/build/mak/android/android_q_base_build_fusion.sh
    elif [[ "$PLATFORM" == *"MT9216"* ]]; then
        ### customized patch at first
        echo "(info) [$PLATFORM] customized patch at first"
        echo "(info) sh vendor/mediatek/proprietary_tv/apollo/linux_mts/build/mak/android/android_r_base_build_fusion.sh"
        sh vendor/mediatek/proprietary_tv/apollo/linux_mts/build/mak/android/android_r_base_build_fusion.sh
    elif [[ "$PLATFORM" == *"MT9617"* ]]; then
        ### customized patch at first
        echo "(info) [$PLATFORM] customized patch at first"
        echo "(info) sh vendor/mediatek/tv/build/android/android_r_base_build_fusion.sh"
        sh vendor/mediatek/tv/build/android/android_r_base_build_fusion.sh
    fi

    if [ "${LUNCH_SYS:0:10}" == "OPPOCNM632" ]; then
        ### check if there is the system build
        if [ -d "device/oneplus/OPPOCNM632" ]; then
            echo "(info) system build - $LUNCH_SYS"
        else
            echo "(error) There is no system build - $LUNCH_SYS. exit 1"
            exit 1;
        fi
    elif [ "$LUNCH_SYS" == "OPPO_Cebu" ]; then
        ### check if there is the system build
        if [ -d "vendor/mediatek/proprietary_tv/apollo/mtk_obj/oneplus/OPPO_Cebu" ]; then
            echo "(info) system build - $LUNCH_SYS"
        else
            echo "(error) There is no system build - $LUNCH_SYS. exit 1"
            exit 1;
        fi
    fi

    ### build target system
    if [[ "$PLATFORM" == *"MT9216"* ]] || [[ "$PLATFORM" == *"MT9617"* ]]; then
        echo "(info) [$PLATFORM] use 'm' commond, Calling make directly is no longer supported"
        MAKE_COMMOND="m"
    fi

    echo "(info) source build/envsetup.sh;lunch ${LUNCH_SYS}-${BUILD_TYPE};time ${MAKE_COMMOND} -j32 ${MAKE_PARAMETERS} ${PLATFORM_MAKE_CMD} 2>&1 | tee make_${PLATFORM_MAKE_CMD}_`date +%y%m%d%H%M`.log" \
    | tee make_${PLATFORM_MAKE_CMD}_${LUNCH_SYS}-${BUILD_TYPE}_`date +%y%m%d%H%M`.log
    source build/envsetup.sh;\
    lunch $LUNCH_SYS-$BUILD_TYPE;\
    time $MAKE_COMMOND -j32 \
    $MAKE_PARAMETERS \
    $PLATFORM_MAKE_CMD \
    2>&1 | tee -a make_${PLATFORM_MAKE_CMD}_${LUNCH_SYS}-${BUILD_TYPE}_`date +%y%m%d%H%M`.log

    if [ "${PLATFORM_MAKE_CMD}" == *"clean"* ]; then
        if [[ "$PLATFORM" == *"MT9612"* ]] \
            || [[ "$PLATFORM" == *"MT9216"* ]] \
            || [[ "$PLATFORM" == *"MT9617"* ]]; then
            if [ -e "patched" ]; then
                echo "(info) rm -f patched"
                rm -f patched
            fi
        fi
        ### Ensure to remove the out/
        if [ -d out ]; then
            rm -rf out
        fi
    fi
}

# echo -e "\n*************************"
fn_DeterminePlatform
fn_MenuLunchSysByPlatform
fn_MenuBuildType
fn_MenuBuildClean
fn_BuildTargetSys
