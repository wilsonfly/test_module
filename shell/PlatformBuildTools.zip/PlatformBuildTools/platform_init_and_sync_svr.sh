#!/bin/bash
#
#   $1: branch name
#	$2: manifest snapshot xml
#	    Optional parameter
#		Put the manifest snapshot file into .repo/manifests/
#	    e.g.
#		manifest_2103270219.xml
#	
#	To have the latest ver. of platform (source code).
#	e.g.
#	./platform_init_and_sync_svr.sh aquarius-q-9612
#
#
#
#	Follow the below steps to sync to a specific ver. which is the same as the manifest snapshot.
#	Note.
#	You need to adjust the value of "WITHOUT_FULL_HISTORY" "--depth=20" if you want to sync to an older ver.
#	Such like "--depth=50". It's depend on your target.
#
#	1. To have the latest ver. platform (source code)
#		e.g.
#		./platform_init_and_sync_svr.sh aquarius-q-9612
#	2. To sync to a specific ver. via manifest snapshot xml
#		a) To have the manifest snapshot xml in the release server.
#			e.g.
#			\\daping.version.myoas.com\daping_dev
#		b) To put it into the path ".repo/manifests/"
#		c) To sync to the specific ver.
#			e.g.
#			./platform_init_and_sync_svr.sh aquarius-q-9612 manifest_2012290356.xml
#

# BRANCH_NAME=pre-mtk-capricorn-p-9652
BRANCH_NAME=$1
PROJ_MANIFEST=oneplus/manifests
SSH_URL=""
MANIFEST_FIXED=$2

if [ $# -eq 0 ]; then
    echo "(info) You should enter parameter (BRANCH_NAME) : "
	read BRANCH_NAME
	echo "(info) BRANCH_NAME: $BRANCH_NAME "
fi

# WITHOUT_FULL_HISTORY=""
WITHOUT_FULL_HISTORY="--depth=200"

GIT_LFS_REPO_MMPLAYER=mtk/fusion-an/device/mstar/common/libraries/media/mmplayer
GIT_LFS_REPO_MI=mtk/fusion-an/device/mstar/common/libraries/mi
GIT_LFS_REPO_LIB_MAXIM=mtk/fusion-an/platform/hardware/mstar/libopenglhw/maxim
GIT_LFS_REPO_MAXIM=mtk/fusion-an/platform/vendor/mstar/maxim
GIT_LFS_REPO_MTK_OBJ=mtk/lfs/mtk_obj

# REPO_URL="https://mirrors.tuna.tsinghua.edu.cn/git/git-repo"
REPO_URL="ssh://tvgerrit.oneplus.cn/oppo/git-repo"
# REPO_BRANCH=master
REPO_BRANCH=stable


### check if current ip in SZ or not
IP_CUR=`hostname -I | awk '{print $1}'`

fn_DetermineSshUrl()
{
	echo "(info) ##### fn_DetermineSshUrl #####"
	
	if [ "$BRANCH_NAME" == "" ]; then
		echo "(info) Unknown project branch name. ($BRANCH_NAME)"
		exit 1;
	fi
	
	echo "(info) Processing..."
	if [[ $IP_CUR == *"172.19"* ]] \
		|| [[ $IP_CUR == *"10.27.8"* ]]; then
        # echo "(info) SH IP. $IP_CUR"
        SSH_URL="ssh://tvgerrit2.oneplus.cn"
		REPO_URL="ssh://tvgerrit2.oneplus.cn/oppo/git-repo"
	else
        # echo "(info) Not SH IP. $IP_CUR"
        SSH_URL="ssh://tvgerrit.oneplus.cn"
	fi
	echo "(info) ssh url info $SSH_URL"
}

fn_RemoveLog()
{
	echo "(info) ##### fn_RemoveLog #####"
	### remove log at first
	echo "(info) rm -f *.log"
	rm -f *.log
}

fn_EnsureGitEnv()
{
	echo "(info) ##### fn_EnsureGitEnv #####"
	
	### check if git-lfs install or not
	GitConfigLfs=$(git config --list | grep "git-lfs smudge")
	if [ -z "$GitConfigLfs" ]; then
		### git lfs initial
		echo "(info) git lfs install"
		git lfs install
	else
		echo "(info) git-lfs is already initialized"
	fi

	GitConfigColor=$(git config --list | grep "color")
	if [ -z "$GitConfigColor" ]; then
		### git config color
		echo "(info) git config --global color.ui auto"
		git config --global color.ui auto
	fi
}

fn_InitAndSync()
{
	echo "(info) ##### fn_InitAndSync #####"
	
    echo "(info) export REPO_TRACE=1"
	export REPO_TRACE=1

	PATH_MIRROR=""
	PATH_REPO_MIRROR_BASE=""
	### Overwrite if necessary
	if [ -d "/data/mirror" ]; then
		PATH_REPO_MIRROR_BASE=/data/mirror
	elif [ -d "/work/mirror" ]; then
		PATH_REPO_MIRROR_BASE=/work/mirror
	fi

	if [[ "$BRANCH_NAME" == *"capricorn-p-9652"* ]]; then
		PATH_MIRROR=${PATH_REPO_MIRROR_BASE}/capricorn-p-9652
	elif [[ "$BRANCH_NAME" == *"sagittarius-p-9950"* ]]; then
		PATH_MIRROR=${PATH_REPO_MIRROR_BASE}/sagittarius-p-9950
	elif [[ "$BRANCH_NAME" == *"aquarius-q-9612"* ]]; then
		PATH_MIRROR=${PATH_REPO_MIRROR_BASE}/aquarius-q-9612
	elif [[ "$BRANCH_NAME" == *"pisces-r-9216"* ]]; then
		PATH_MIRROR=${PATH_REPO_MIRROR_BASE}/pisces-r-9216
	elif [[ "$BRANCH_NAME" == *"aries-r-9617"* ]]; then
		PATH_MIRROR=${PATH_REPO_MIRROR_BASE}/aries-r-9617
	else
		PATH_MIRROR=${PATH_REPO_MIRROR_BASE}/scorpio-p-5670
	fi
		
    if [ "$MANIFEST_FIXED" == "" ]; then
    	if [ -d "${PATH_MIRROR}/.repo" ]; then
			echo "(info) repo init $WITHOUT_FULL_HISTORY -u $SSH_URL/$PROJ_MANIFEST -b $BRANCH_NAME --reference=${PATH_MIRROR} --repo-url $REPO_URL --repo-branch $REPO_BRANCH --no-repo-verify"
			repo init \
			$WITHOUT_FULL_HISTORY \
			-u $SSH_URL/$PROJ_MANIFEST \
			-b $BRANCH_NAME \
			--reference=${PATH_MIRROR} \
			--repo-url $REPO_URL \
			--repo-branch $REPO_BRANCH \
			--no-repo-verify \
			|| { echo "(error) repo init $WITHOUT_FULL_HISTORY -u $SSH_URL/$PROJ_MANIFEST -b $BRANCH_NAME --reference=${PATH_MIRROR} fail!!!"; exit 1; }
	    else
			echo "(info) repo init $WITHOUT_FULL_HISTORY -u $SSH_URL/$PROJ_MANIFEST -b $BRANCH_NAME --repo-url $REPO_URL --repo-branch $REPO_BRANCH --no-repo-verify"
			repo init \
			$WITHOUT_FULL_HISTORY \
			-u $SSH_URL/$PROJ_MANIFEST \
			-b $BRANCH_NAME \
			--repo-url $REPO_URL \
			--repo-branch $REPO_BRANCH \
			--no-repo-verify \
			|| { echo "(error) repo init $WITHOUT_FULL_HISTORY -u $SSH_URL/$PROJ_MANIFEST -b $BRANCH_NAME fail!!!"; exit 1; }
	    fi
    else
		echo "(info) repo init -m $MANIFEST_FIXED --repo-url $REPO_URL --repo-branch $REPO_BRANCH --no-repo-verify"
        repo init \
		-m $MANIFEST_FIXED \
		--repo-url $REPO_URL \
		--repo-branch $REPO_BRANCH \
		--no-repo-verify \
		|| { echo "(error) repo init -m $MANIFEST_FIXED --repo-url $REPO_URL --repo-branch $REPO_BRANCH --no-repo-verify fail!!!"; exit 1; }
    fi

	if [ -e "repo_sync_${BRANCH_NAME}.log" ]; then
		echo "(info) remove previous repo sync log if there is any. rm -f repo_sync_${BRANCH_NAME}.log"
		rm -f repo_sync_${BRANCH_NAME}.log
	fi

	echo "(info) time repo sync -j8 --no-clone-bundle -c --no-repo-verify 2>&1 | tee repo_sync_${BRANCH_NAME}.log"
	time repo sync \
	-j8 \
	--no-clone-bundle \
	-c \
	--no-repo-verify \
	2>&1 | tee repo_sync_${BRANCH_NAME}.log

	### check if sync error or not
	grep "repo sync has finished successfully" repo_sync_${BRANCH_NAME}.log
	if [ $? -eq 0 ]; then
		echo -e "(info) repo sync successfully"
	else
		echo "(info) There has sync error. try again"
		if [ -e "repo_sync_${BRANCH_NAME}.log" ]; then
			echo "(info) remove previous repo sync log if there is any. rm -f repo_sync_${BRANCH_NAME}.log"
			rm -f repo_sync_$BRANCH_NAME.log
		fi
		
		echo "(info)(2 nd) time repo sync -j8 --no-clone-bundle -c --no-repo-verify 2>&1 | tee repo_sync_${BRANCH_NAME}.log"
		time repo sync \
		-j8 \
		--no-clone-bundle \
		-c \
		--no-repo-verify \
		2>&1 | tee repo_sync_${BRANCH_NAME}.log || { echo "(error)(2 nd) repo sync -j16 --no-clone-bundle -c --no-repo-verify fail!!!"; exit 1; }

		grep "repo sync has finished successfully" repo_sync_${BRANCH_NAME}.log
		if [ $? -eq 0 ]; then
			echo -e "(info) repo sync successfully"
		else
			echo -e "(info) There has sync error (2)"
			echo "(info) unset REPO_TRACE"
			unset REPO_TRACE
			exit 1
		fi
	fi
	
	if [[ "$BRANCH_NAME" == *"sagittarius-p-9950"* ]] \
        || [[ "$BRANCH_NAME" == *"capricorn-p-9652"* ]] \
		|| [[ "$BRANCH_NAME" == *"pisces-r-9216"* ]] \
		|| [[ "$BRANCH_NAME" == *"aries-r-9617"* ]] \
        || [[ "$BRANCH_NAME" == *"aquarius-q-9612"* ]]; then
		fn_GitLfsPull
	fi

	echo "(info) unset REPO_TRACE"
	unset REPO_TRACE
}

fn_GitLfsPull()
{
    ### check if mtk/lfs/mtk_obj exists or not
    unset REPO_TRACE
    RESULT=$(repo forall ${GIT_LFS_REPO_MTK_OBJ} -c 'echo "$REPO_PROJECT"')
    echo "(info) ${BRANCH_NAME} repo forall ${GIT_LFS_REPO_MTK_OBJ} RESULT: ${RESULT}"
    export REPO_TRACE=1
    
    ### setup project list (forall)
    REPO_FORALL_LIST=""
    if [[ "$BRANCH_NAME" == *"capricorn-p-9652"* ]]; then
        REPO_FORALL_LIST=${GIT_LFS_REPO_MMPLAYER}" "${GIT_LFS_REPO_MI}" "${GIT_LFS_REPO_LIB_MAXIM}" "${GIT_LFS_REPO_MAXIM}
        if [ "$RESULT" == "$GIT_LFS_REPO_MTK_OBJ" ]; then
            REPO_FORALL_LIST+=" "${GIT_LFS_REPO_MTK_OBJ}
        fi
    elif [[ "$BRANCH_NAME" == *"sagittarius-p-9950"* ]]; then
        REPO_FORALL_LIST=${GIT_LFS_REPO_MMPLAYER}" "${GIT_LFS_REPO_MI}
        if [ "$RESULT" == "$GIT_LFS_REPO_MTK_OBJ" ]; then
            REPO_FORALL_LIST+=" "${GIT_LFS_REPO_MTK_OBJ}
        fi
    elif [[ "$BRANCH_NAME" == *"aquarius-q-9612"* ]]; then
        if [ "$RESULT" == "$GIT_LFS_REPO_MTK_OBJ" ]; then
            REPO_FORALL_LIST+=${GIT_LFS_REPO_MTK_OBJ}
        fi
	elif [[ "$BRANCH_NAME" == *"pisces-r-9216"* ]]; then
        if [ "$RESULT" == "$GIT_LFS_REPO_MTK_OBJ" ]; then
            REPO_FORALL_LIST+=${GIT_LFS_REPO_MTK_OBJ}
        fi
	elif [[ "$BRANCH_NAME" == *"aries-r-9617"* ]]; then
        if [ "$RESULT" == "$GIT_LFS_REPO_MTK_OBJ" ]; then
            REPO_FORALL_LIST+=${GIT_LFS_REPO_MTK_OBJ}
        fi
    else
        echo -e "(warning) Unkonwn branch ($BRANCH_NAME)."
    fi
    
    echo -e "(info) REPO_FORALL_LIST: $REPO_FORALL_LIST"
    ### change the url if the repository is lfs
    ### lfs url is only avaiable in SZ
    echo -e "(info) To change the remote url in the lfs repository due to lfs url only avaible in host gerrit server"
    echo -e "(info) export GIT_TRACE=1"
    export GIT_TRACE=1

    time repo forall ${REPO_FORALL_LIST} \
    -c 'echo "$REPO_PROJECT" && git remote set-url oneplus.tv ssh://tvgerrit.oneplus.cn/${REPO_PROJECT}' \
    2>&1 | tee repo_forall_git_remote_set_url.log
    
    ### git lfs pull in each lfs repsoitories
    echo "(info) git lfs pull in each lfs repsoitories"
    time repo forall ${REPO_FORALL_LIST} \
    -c 'echo "$REPO_PROJECT" && git lfs pull oneplus.tv' \
    2>&1 | tee repo_forall_git_lfs_pull.log
    
    ### check if git lfs pull error or not
    grep "error: " repo_forall_git_lfs_pull.log
    if [ $? -ne 0 ]; then
        echo -e "(info) git lfs pull successfully"
    else
        echo -e "(error) git lfs pull error. Try again"
        echo -e "(info) remove repo_forall_git_lfs_pull.log at first"
        echo -e "(info) rm -f repo_forall_git_lfs_pull.log"
        rm -f repo_forall_git_lfs_pull.log
        
        ### git lfs pull in each lfs repsoitories
        echo -e "(info) git lfs pull in each lfs repsoitories"
        
        time repo forall ${REPO_FORALL_LIST} \
        -c 'echo "$REPO_PROJECT" && git lfs pull oneplus.tv' \
        2>&1 | tee repo_forall_git_lfs_pull.log
    
        ### check if git lfs pull error or not
        grep "error: " repo_forall_git_lfs_pull.log
        if [ $? -ne 0 ]; then
            echo -e "(info) git lfs pull successfully"
        else
            echo -e "(info) unset REPO_TRACE"
            unset REPO_TRACE
            echo -e "(info) unset GIT_TRACE"
            unset GIT_TRACE
        
            echo -e "(error) git lfs pull error"
            exit 1
        fi      
    fi
    
    echo -e "(info) unset GIT_TRACE"
    unset GIT_TRACE
}

echo "##############################"

fn_DetermineSshUrl
fn_RemoveLog
fn_EnsureGitEnv
fn_InitAndSync

